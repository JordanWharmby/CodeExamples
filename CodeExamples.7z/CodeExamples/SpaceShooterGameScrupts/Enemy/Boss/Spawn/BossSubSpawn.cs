﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossSubSpawn : MonoBehaviour, BaseEnemy {
    [Header("Enemy Stats")]
    public EnemyStats Stats;

    [Header("Sub Enemy")]
    public GameObject SubEnemy;
    
    //Private fields
    private float radius;
    private Vector3 ScreenSize;
    private float fireDelta;
    private bool spin = false;

    //Curent helth
    private float curentHelth;

    //Animation veriables
    private bool animationFlag = false;

    // Use this for initialization
    void Start() {
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;

        //Sets the curent helth to be the max helth
        curentHelth = Stats.Helth;

        ScreenSize = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, 0));
    }

    //Sets the balls to spin
    public void SetSpin() { spin = true; }

    private Vector3 RandomCircle(Vector3 center, float radius, int a) {
        float ang = a;
        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.y = center.y + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        pos.z = center.z;
        return pos;
    }

    // Update is called once per frame
    void Update() {
        SetNewPosition();
    }

    private void SetNewPosition() {
        if (spin) {
            transform.RotateAround(transform.parent.localPosition, Vector3.back, 100 * Time.deltaTime);
        }
    }


    public void KillEnemy() {
        //Removes all of the helth
        _TakeDamage(curentHelth + 1);
    }

    //Damages the enemy
    public void _TakeDamage(float damage) {
        //Takes damage
        curentHelth -= damage;
        //If the enemy has no helth left
        if (curentHelth <= 0) {
            destroyEnemy();
        }
    }

    //Destroy enemy
    private void destroyEnemy() {
        //Adds a basic enemy
        Instantiate(SubEnemy, transform.position, Quaternion.identity);
        //Removes the enemy
        Destroy(gameObject);
    }
}
