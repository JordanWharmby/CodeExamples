﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossSpawn : MonoBehaviour, BaseEnemy {
    [Header("Enemy Stats")]
    public EnemyStats Stats;

    [Header("Sub Enemy")]
    public GameObject SubEnemy;
    public int NumberOfSubEnemeys = 10;
    private List<BossSubSpawn> Subs = new List<BossSubSpawn>();
    
    //New position
    private Vector3 targetPosition;
    private int stage = 0;

    //Private fields
    private float radius;
    private float fireDelta;

    //Curent helth
    private float curentHelth;

    //Animation veriables
    private bool animationFlag = false;

    // Use this for initialization
    void Start() {
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;

        //Sets the curent helth to be the max helth
        curentHelth = Stats.Helth;

        //Sets the position
        transform.position = new Vector3(GameManager.GM.ScreenSize.x + radius, 0, 0);
        targetPosition = new Vector3(0, 0, 0);

        //Start animation
        StartCoroutine(startAnimation());
    }

    //Start animation
    private IEnumerator startAnimation() {
        //If the animation has not started
        //Start the animation
        if (!animationFlag) {
            animationFlag = true;

            //If the enemy is moving onto the screen
            while (!moveToNewPosition(targetPosition)) {
                yield return null;
            }

            //growing balls
            while (true) {
                for (int i = 0; i < NumberOfSubEnemeys; i++) {
                    int a = i * (360 / NumberOfSubEnemeys);
                    Vector3 pos = RandomCircle(transform.position, radius * 1.5f, a);
                    GameObject temp = Instantiate(SubEnemy, pos, Quaternion.identity, transform);
                    temp.transform.localScale = new Vector3(1, 1, 0);
                    Subs.Add(temp.GetComponent<BossSubSpawn>());
                    yield return new WaitForSeconds(0.1f);
                }
                break;
            }
            //Sets the stage
            stage = 1;
            //Sets a new target position
            targetPosition = NewTargetPosition();
            //Sets animation flag
            WaveManager.WM.BossIsReady = true;
            while (!WaveManager.WM.InBossAnimation) yield return null;
            //Sets the animation
            animationFlag = false;
            //Sets all of the balls to spin
            foreach (BossSubSpawn BSS in Subs) BSS.SetSpin();
        }
    }

    //Moves the enemy to a new position
    private bool moveToNewPosition(Vector3 newPos) {
        //If the enemy is at the right position
        if (Vector3.Distance(transform.position, newPos) < 0.1) {
            //Sets the position and returns true
            transform.position = newPos;
            return true;
        }
        //Moves the enemy
        transform.localPosition = Vector3.MoveTowards(transform.position, newPos, (Stats.Speed / 2) * Time.deltaTime);
        //Returns fals
        return false;
    }

    private Vector3 RandomCircle(Vector3 center, float radius, int a) {
        float ang = a;
        Vector3 pos;
        pos.x = center.x + radius * Mathf.Sin(ang * Mathf.Deg2Rad);
        pos.y = center.y + radius * Mathf.Cos(ang * Mathf.Deg2Rad);
        pos.z = center.z;
        return pos;
    }

    // Update is called once per frame
    void Update() {
        SetNewPosition();
    }

    private void SetNewPosition() {
        //if the stare animation is still going on
        if (stage == 0) return;
        //Checks if the enemy is at the new position
        if (moveToNewPosition(targetPosition)) {
            //Sets a new target position
            targetPosition = NewTargetPosition();
        }
    }

    private Vector3 NewTargetPosition() {
        Vector3 tempPos = Vector3.zero;
        float x, y;
        //While a position is being decided
        while (true) {
            //Selcts ether -1, 0 or 1
            int i = Mathf.RoundToInt(Random.Range(-1, 2));
            //Calculates x position
            x = (i * GameManager.GM.ScreenSize.x) + (radius * (2 * -i));
            //Selcts ether -1, 0 or 1
            i = Mathf.RoundToInt(Random.Range(-1, 2));
            //Calculates y position
            y = (i * GameManager.GM.ScreenSize.y) + (radius * (2 * -i));
            //Inputs vector ppositions
            tempPos = new Vector3(x, y, 0);
            //If they are diferent, break;
            if (tempPos != targetPosition) break;
        }
        //Reunrns the position
        return tempPos;
    }

    //Damages the enemy
    public void _TakeDamage(float damage) {
        //Takes damage
        curentHelth -= damage;
        //If the enemy has no helth left
        if (curentHelth <= 0) {
            destroyEnemy();
        }
    }

    //Destroy enemy
    private void destroyEnemy() {
        //Kills all of the sub enemys that are still alive
        foreach (BossSubSpawn BSS in Subs) if(BSS != null) BSS.KillEnemy();
        //Clears the list
        Subs.Clear();
        //Removes the enemy
        Destroy(gameObject);
    }
}

