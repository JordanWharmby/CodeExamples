﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossFinalMain : MonoBehaviour, BaseEnemy {
    [Header("Enemy Stats")]
    public EnemyStats Stats;

    [Header("Sub Uniets")]
    public Transform TuretPerent;
    public Transform SpawnerPerent;
    //List of sub unets
    private List<BossFinalTuret> turets = new List<BossFinalTuret>();
    private List<BossFinalSpawner> spawner = new List<BossFinalSpawner>();

    //Private fields
    private Rigidbody2D rigi;
    private float radius;
    private float fireDelta;

    //New position
    private Vector3 targetPosition;
    bool positionFlag = false;

    //Curent helth
    private float curentHelth;

    //Animation veriables
    private bool animationFlag = false;

    // Use this for initialization
    void Start() {
        //Gets the compontes
        rigi = GetComponent<Rigidbody2D>();
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        //Sets the curent helth to be the max helth
        curentHelth = Stats.Helth;

        //Fills the list with turtes and spawners
        turets.AddRange(TuretPerent.GetComponentsInChildren<BossFinalTuret>());
        spawner.AddRange(SpawnerPerent.GetComponentsInChildren<BossFinalSpawner>());

        //Sets bulet stats
        Stats.CanShoot = false;
        Stats.FierDelta = 0;

        //Sets the position
        transform.position = new Vector3(0, -GameManager.GM.ScreenSize.y - radius, 0);
        //Start animation
        StartCoroutine(startAnimation());
    }

    //Start animation
    private IEnumerator startAnimation() {
        //If the animation has not started
        //Start the animation
        if (!animationFlag) {
            animationFlag = true;
            //Sets the position to the center of the screen
            targetPosition = Vector3.zero;
            //Moves the enemy into the start position
            while (!moveToNewPosition(targetPosition)) {
                yield return null;
            }
            //Sets the next target position
            targetPosition = new Vector3(GameManager.GM.ScreenSize.x - radius, transform.position.y, 0);
            //Sets animation flag
            WaveManager.WM.BossIsReady = true;
            while (!WaveManager.WM.InBossAnimation) yield return null;
            //Sets the animation
            animationFlag = false;
            //Sets turets to fier and spawners to spawn
            foreach (BossFinalTuret t in turets) t.SetStart();
            foreach (BossFinalSpawner s in spawner) s.SetStart();
        }
    }

    //Moves the enemy to a new position
    private bool moveToNewPosition(Vector3 newPos) {
        //If the enemy is at the right position
        if (Vector3.Distance(transform.position, newPos) < 0.1) {
            //Sets the position and returns true
            transform.position = newPos;
            return true;
        }
        //Moves the enemy
        transform.localPosition = Vector3.MoveTowards(transform.position, newPos, (Stats.Speed / 2) * Time.deltaTime);
        //Returns fals
        return false;
    }


    // Update is called once per frame
    void Update() {

    }

    //Damages the enemy
    public void _TakeDamage(float damage) {
        //Takes damage
        curentHelth -= damage;
        //If the enemy has no helth left
        if (curentHelth <= 0) {
            destroyEnemy();
        }
    }

    //Destroy enemy
    private void destroyEnemy() {
        //Removes the enemy
        Destroy(gameObject);
    }
}
