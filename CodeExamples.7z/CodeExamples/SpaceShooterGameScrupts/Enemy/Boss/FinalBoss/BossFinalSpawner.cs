﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossFinalSpawner : MonoBehaviour,  BaseEnemy {
    [Header("Enemy Stats")]
    public EnemyStats Stats;

    //Private fields
    private Rigidbody2D rigi;
    private float radius;
    private Vector3 ScreenSize;
    private float fireDelta;

    //Start flags
    private bool startFlag = false;

    //Curent helth
    private float curentHelth;

    //Animation veriables
    private bool animationFlag = false;

    // Use this for initialization
    void Start() {
        //Gets the compontes
        rigi = GetComponent<Rigidbody2D>();
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        //Sets the curent helth to be the max helth
        curentHelth = Stats.Helth;

        ScreenSize = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height, 0));
    }

    //Moves the enemy to a new position
    private bool moveToNewPosition(Vector3 newPos) {
        //If the enemy is at the right position
        if (Vector3.Distance(transform.position, newPos) < 0.1) {
            //Sets the position and returns true
            transform.position = newPos;
            return true;
        }
        //Moves the enemy
        transform.localPosition = Vector3.MoveTowards(transform.position, newPos, (Stats.Speed / 2) * Time.deltaTime);
        //Returns fals
        return false;
    }

    public void SetStart() { startFlag = true; }

    // Update is called once per frame
    void Update() {
        //If the start animation is still on going
        if (!startFlag) return;
        //Fiers bulets
        fireBulet();
    }

    //Damages the enemy
    public void _TakeDamage(float damage) {
        //Takes damage
        curentHelth -= damage;
        //If the enemy has no helth left
        if (curentHelth <= 0) {
            destroyEnemy();
        }
    }

    //Destroy enemy
    private void destroyEnemy() {
        //Removes the enemy
        Destroy(gameObject);
    }

    public void fireBulet() {
        //if the player can not fire
        if (!Stats.CanShoot) {
            //Incriments timer
            Stats.FierDelta += Time.deltaTime;
            //Sets can fire to true if enought time has pased
            if (Stats.FierDelta >= Stats.FierDelay) {
                Stats.CanShoot = true;
            }
        }
        //If the player clicks the left mouse button and they can fier a bulet
        if (Stats.CanShoot) {
            //Spawns an enemy
            Instantiate(Stats.Bulet, Stats.FirePoint.position, Quaternion.identity);
            //Resets shooting peramiters
            Stats.CanShoot = false;
            Stats.FierDelta = 0;
        }
    }
}