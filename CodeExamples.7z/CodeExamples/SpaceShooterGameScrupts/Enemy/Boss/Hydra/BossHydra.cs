﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossHydra : MonoBehaviour, BaseEnemy {
    [Header("Enemy Stats")]
    public EnemyStats Stats;

    [Header("Sub Enemy")]
    public GameObject SubEnemy;

    //Private fields
    private float radius;
    private float fireDelta;
    private float scale = 0;
    private float maxScale;

    //Curent helth
    private float curentHelth;

    //Animation veriables
    private bool animationFlag = false;

    private bool dropFlag = false;
    private bool dethFlag = false;

    // Use this for initialization
    void Start() {
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        //Sets the scale
        maxScale = transform.localScale.x;
        //Sets the scale
        transform.localScale = new Vector3(scale, scale, scale);

        //Sets the curent helth to be the max helth
        curentHelth = Stats.Helth;

        //Sets bulet stats
        Stats.CanShoot = false;
        Stats.FierDelta = 0;

        //Sets the position
        transform.position = new Vector3(0, 0, 0);

        //Start animation
        StartCoroutine(startAnimation());
    }

    //Start animation
    private IEnumerator startAnimation() {
        //If the animation has not started
        //Start the animation
        if (!animationFlag) {
            animationFlag = true;
            while (true) {
                scale += 0.1f;
                transform.localScale = new Vector3(scale, scale, scale);
                if (scale >= maxScale) {
                    scale = maxScale;
                    break;
                }
                yield return null;
            }
            //Sets the final scale
            transform.localScale = new Vector3(scale, scale, scale);
            //Sets animation flag
            WaveManager.WM.BossIsReady = true;
            while (!WaveManager.WM.InBossAnimation) yield return null;
            //Sets the animation
            animationFlag = false;
        }
    }

    // Update is called once per frame
    void Update() {
        //fireBulet();
    }

    //Damages the enemy
    public void _TakeDamage(float damage) {
        //Takes damage
        curentHelth -= damage;
        //If the enemy has no helth left
        if (curentHelth <= 0) {
            //Disables collision
            GetComponent<CircleCollider2D>().enabled = false;
            //Adds Score
            ScoreManager.SM.SetScoreText(Stats.Score);
            //Hieds sprite
            //Creates expereance orbs
            StartCoroutine(CreateExperance());
        }
    }

    private IEnumerator CreateExperance() {
        //Drop flag
        if (!dropFlag) {
            dropFlag = true;
            //Amount droped
            float total = 0;
            //Loops through for drop
            for (float f = 0; f <= Stats.ExperianceDrop - 2; f += Stats.ExperianceDrop / 10) {
                //Adds to the total
                total += 2;
                Instantiate(Stats.ExpereanceObject, transform.position, Quaternion.identity).GetComponent<UpgradeParticle>().SetValues(Stats.ExperianceDrop / 10);
                yield return new WaitForSeconds(0.05f);
            }
            //If there is still some left over
            if (total < Stats.ExperianceDrop) {
                Instantiate(Stats.ExpereanceObject, transform.position, Quaternion.identity).GetComponent<UpgradeParticle>().SetValues(Stats.ExperianceDrop - total);
            }
            dropFlag = true;
            StartCoroutine(dethAnimation());
        }
    }

    private IEnumerator dethAnimation() {
        //Sets flag
        if (!dethFlag) {
            dethFlag = true;
            //spawns particcles
            Instantiate(Stats.DethEffect, Stats.ParticlePos(transform.position, radius, 0.5f, 0.5f), Quaternion.identity);
            Instantiate(Stats.DethEffect, Stats.ParticlePos(transform.position, radius, -0.5f, -0.5f), Quaternion.identity);
            //waits
            yield return new WaitForSeconds(2);
            //spawns particcles
            Instantiate(Stats.DethEffect, Stats.ParticlePos(transform.position, radius, -0.5f, 0.5f), Quaternion.identity);
            Instantiate(Stats.DethEffect, Stats.ParticlePos(transform.position, radius, 0.5f, -0.5f), Quaternion.identity);
            //Waits
            yield return new WaitForSeconds(2);
            //Sets flag
            dethFlag = false;
        }
        //Removes enemy
        destroyEnemy();
    }

    //Destroy enemy
    private void destroyEnemy() {
        //Creates 2 new enemys
        GameObject temp = Instantiate(SubEnemy, transform.position, Quaternion.identity);
        temp.GetComponent<BossSubHydra>().SetMoving(true);
        WaveManager.WM.AddEnemyToList(temp);
        temp = Instantiate(SubEnemy, transform.position, Quaternion.identity);
        temp.GetComponent<BossSubHydra>().SetMoving(false);
        WaveManager.WM.AddEnemyToList(temp);
        //Removes the enemy from the list
        WaveManager.WM.RemoveEnemyFromList(gameObject);
        //Removes the enemy
        Destroy(gameObject);
    }

    public void fireBulet() {
        //if the player can not fire
        if (!Stats.CanShoot) {
            //Incriments timer
            Stats.FierDelta += Time.deltaTime;
            //Sets can fire to true if enought time has pased
            if (Stats.FierDelta >= Stats.FierDelay) {
                Stats.CanShoot = true;
            }
        }
        //If the player clicks the left mouse button and they can fier a bulet
        if (Stats.CanShoot) {
            //Fiers a volly
            StartCoroutine(fireVolly());
            //Resets shooting peramiters
            Stats.CanShoot = false;
            Stats.FierDelta = 0;
        }
    }

    //Fiers bulets
    private IEnumerator fireVolly() {
        //If the animation has not started
        if (!animationFlag) {
            //Start the animation
            animationFlag = !animationFlag;
            //fiers 3 bulets
            for (int i = 0; i < 3; i++) {
                //Fiers a bulet
                GameObject tempBulet = Instantiate(Stats.Bulet, Stats.FirePoint.position, Quaternion.identity);
                //Sets the rotation
                tempBulet.transform.up = Stats.FirePoint.position - transform.position;
                //Sets the stast
                tempBulet.GetComponent<Bulet>().SetStatat(50, false, Stats.BuletSpeed + Stats.Speed);
                //Waits
                yield return new WaitForSeconds(0.25f);
            }
            //Sets animation flag
            animationFlag = !animationFlag;
        }
    }

}
