﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class EnemyStats {

    [Header("Base Stats")]
    public string Name;
    public float Helth;
    public float Speed;
    [Header("Shooting Stats")]
    public Transform FirePoint;
    public float FierDelay;
    [HideInInspector]
    public float FierDelta;
    [HideInInspector]
    public bool CanShoot;
    public GameObject Bulet;
    public float BuletSpeed;
    [Header("Effects")]
    public ParticleSystem DethEffect;
    [Header("Drops")]
    public float Score;
    public float ExperianceDrop;
    public GameObject ExpereanceObject;

    //Returns a position for a particle
    public Vector3 ParticlePos(Vector3 pos, float r, float posX, float posY) {
        //Takes the position of the enemy
        Vector3 returnPos = Vector3.zero;
        //Calculates where to spawn the particle
        returnPos = new Vector3(pos.x + (r * posX), pos.y + (r * posY), 0);
        //returns the position
        return returnPos;
    }

}
