﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface BaseEnemy {
    
    void _TakeDamage(float Damage);

}
