﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BasicEnemy : MonoBehaviour , BaseEnemy {
    [Header ("Enemy Stats")]
    public EnemyStats Stats;

    //Private fields
    private Rigidbody2D rigi;
    private float radius;

    //Curent helth
    private float curentHelth;

    //DropFlag
    private bool dropFlag = false;

    // Use this for initialization
    void Start () {
        //Gets the compontes
        rigi = GetComponent<Rigidbody2D>();
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        //Sets a random angle
        var euler = transform.eulerAngles;
        euler.z = Random.Range(0.0f, 360.0f);
        transform.eulerAngles = euler;
        //Sets the speed
        rigi.velocity = transform.up * (Stats.Speed * Time.deltaTime);
        //Sets the curent helth to be the max helth
        curentHelth = Stats.Helth;
    }
	
    // Update is called once per frame
    void Update () {
        //Moves the enemy
        ChangeSpeed();
    }

    private void ChangeSpeed() {
        //New velosoty
        Vector2 newVelosoty = rigi.velocity;
        //flag
        bool flag = false;
        //Sides of the screen
        if(transform.position.x > GameManager.GM.ScreenSize.x - (radius * 1.15f) || transform.position.x < -GameManager.GM.ScreenSize.x + (radius * 1.15f)) {
            newVelosoty.x *= -1;
            flag = true;
        }
        //Top and bottom
        if (transform.position.y > GameManager.GM.ScreenSize.y - (radius * 1.15f) || transform.position.y < -GameManager.GM.ScreenSize.y + (radius * 1.15f)) {
            newVelosoty.y *= -1;
            flag = true;
        }
        //Sets the new Speed and rotation
        if (flag) {
            rigi.velocity = newVelosoty;
            transform.up = new Vector3(transform.position.x + newVelosoty.x, transform.position.y + newVelosoty.y, 0) - transform.position;
        }
    }

    //Damages the enemy
    public void _TakeDamage(float damage) {
        //Takes damage
        curentHelth -= damage;
        //If the enemy has no helth left
        if (curentHelth <= 0) {
            //Creates particle effect
            Instantiate(Stats.DethEffect, transform.position, Quaternion.identity);
            //Disables colision
            GetComponent<CircleCollider2D>().enabled = false;
            //Adds Score
            ScoreManager.SM.SetScoreText(Stats.Score);
            //Hieds sprite
            GetComponent<SpriteRenderer>().enabled = false;
            //stops the enemy
            rigi.velocity = Vector2.zero;
            //Creates expereance orbs
            StartCoroutine(CreateExperance());
        }
    }

    private IEnumerator CreateExperance() {
        //Drop flag
        if (!dropFlag) {
            dropFlag = true;
            //Amount droped
            float total = 0;
            //Loops through for drop
            for (float f = 0; f <= Stats.ExperianceDrop - 2; f += 2) {
                //Adds to the total
                total += 2;
                Instantiate(Stats.ExpereanceObject, transform.position, Quaternion.identity).GetComponent<UpgradeParticle>().SetValues(2);
                yield return new WaitForSeconds(0.05f);
            }
            //If there is still some left over
            if (total < Stats.ExperianceDrop) {
                Instantiate(Stats.ExpereanceObject, transform.position, Quaternion.identity).GetComponent<UpgradeParticle>().SetValues(Stats.ExperianceDrop - total);
            }
            dropFlag = true;
            destroyEnemy();
        }
    }

    //Destroy enemy
    private void destroyEnemy() {
        //Removes the enemy from the list
        WaveManager.WM.RemoveEnemyFromList(gameObject);
        //Removes the enemy
        Destroy(gameObject);
    }

}
