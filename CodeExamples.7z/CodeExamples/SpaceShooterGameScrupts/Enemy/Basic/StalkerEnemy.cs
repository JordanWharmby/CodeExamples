﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StalkerEnemy : MonoBehaviour, BaseEnemy {

    [Header("Enemy Stats")]
    public EnemyStats Stats;

    //Private fields
    private Rigidbody2D rigi;
    private float radius;

    //Curent helth
    private float curentHelth;
    private bool dropFlag;

    // Use this for initialization
    void Start() {
        //Gets the compontes
        rigi = GetComponent<Rigidbody2D>();
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        //Sets a random angle
        var euler = transform.eulerAngles;
        euler.z = Random.Range(0.0f, 360.0f);
        transform.eulerAngles = euler;
        //Sets the speed
        rigi.velocity = transform.up * (Stats.Speed * Time.deltaTime);
        //Sets the curent helth to be the max helth
        curentHelth = Stats.Helth;
    }

    // Update is called once per frame
    void Update() {
        //Moves the enemy
        ChangeSpeed();
    }

    private void ChangeSpeed() {
        //Find the player
        PlayerControler pc = FindObjectOfType<PlayerControler>();
        //If one egsists
        if(pc != null) {
            if ((transform.position.x < GameManager.GM.ScreenSize.x + radius && transform.position.x > -GameManager.GM.ScreenSize.x - radius) && 
                (transform.position.y < GameManager.GM.ScreenSize.y + radius && transform.position.y > -GameManager.GM.ScreenSize.y - radius)) {
                //Target position
                Vector3 targetPos = pc.transform.position;
                //Sets the rotation
                transform.up = targetPos - transform.position;
                //Sets the speed
                rigi.velocity = transform.up * (Stats.Speed * Time.deltaTime);
            }
        }
    }

    //Damages the enemy
    public void _TakeDamage(float damage) {
        //Takes damage
        curentHelth -= damage;
        //If the enemy has no helth left
        if (curentHelth <= 0) {
            //Disables colision
            GetComponent<CircleCollider2D>().enabled = false;
            //Creates particle effect
            Instantiate(Stats.DethEffect, transform.position, Quaternion.identity);
            //Adds Score
            ScoreManager.SM.SetScoreText(Stats.Score);
            //Hieds sprite
            GetComponent<SpriteRenderer>().enabled = false;
            //stops the enemy
            rigi.velocity = Vector2.zero;
            //Creates expereance orbs
            StartCoroutine(CreateExperance());
        }
    }

    private IEnumerator CreateExperance() {
        //Drop flag
        if (!dropFlag) {
            dropFlag = true;
            //Amount droped
            float total = 0;
            //Loops through for drop
            for (float f = 0; f <= Stats.ExperianceDrop - 2; f += 2) {
                //Adds to the total
                total += 2;
                Instantiate(Stats.ExpereanceObject, transform.position, Quaternion.identity).GetComponent<UpgradeParticle>().SetValues(2);
                yield return new WaitForSeconds(0.05f);
            }
            //If there is still some left over
            if (total < Stats.ExperianceDrop) {
                Instantiate(Stats.ExpereanceObject, transform.position, Quaternion.identity).GetComponent<UpgradeParticle>().SetValues(Stats.ExperianceDrop - total);
            }
            dropFlag = true;
            destroyEnemy();
        }
    }

    //Destroy enemy
    private void destroyEnemy() {
        //Removes the enemy from the list
        WaveManager.WM.RemoveEnemyFromList(gameObject);
        //Removes the enemy
        Destroy(gameObject);
    }
}
