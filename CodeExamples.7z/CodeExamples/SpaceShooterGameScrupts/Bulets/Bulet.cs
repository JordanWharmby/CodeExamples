﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bulet : MonoBehaviour {
    // Radious
    private float radius;
    //Damage
    private float damage;
    //If it was fiered by the player
    private bool isPlayer;

	// Use this for initialization
	void Start () {
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
    }
	
	// Update is called once per frame
	void Update () {
        if (OffScreen()) Destroy(gameObject);
	}

    //Sets the stats of the bulet
    public void SetStatat(float dam, bool player, float speed) {
        //Sets the damagw
        damage = dam;
        //Sets if it is the player
        isPlayer = player;
        //Sits the speed
        GetComponent<Rigidbody2D>().velocity = (transform.up * (speed * Time.deltaTime));
    }

    private bool OffScreen() {
        //If it goes of the left or right sude
        if (transform.position.x > GameManager.GM.ScreenSize.x || transform.position.x < -GameManager.GM.ScreenSize.x - radius) {
            return true;
        }
        //If it goes of the top or bottom
        if (transform.position.y > GameManager.GM.ScreenSize.y + radius || transform.position.y < -GameManager.GM.ScreenSize.y - radius) {
            return true;
        }
        //Still on screen
        return false;
    }

    //If the buleet hits an ememy
    void OnTriggerEnter2D(Collider2D other) {
        BaseEnemy baseCol = other.GetComponent<BaseEnemy>();
        //if the object is an enemy
        if(baseCol != null && isPlayer) {
            baseCol._TakeDamage(damage);
            Destroy(gameObject);
            return;
        }
        PlayerControler pc = other.GetComponent<PlayerControler>();
        if(pc != null) {
            pc.TakeDamage(damage);
            Destroy(gameObject);
            return;
        }
    }

}
