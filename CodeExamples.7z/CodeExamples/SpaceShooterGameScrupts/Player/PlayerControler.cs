﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControler : MonoBehaviour {
    
    private PlayerStats stats;

    private float radius;

    [Header("Bulet Veriables")]
    public Transform FirePoint;
    public GameObject Bulet;

    [Header("Helth Bar")]
    public GameObject PlayerHelthBar;
    private GameObject tempHelthBar;

    private float currentHelth;
    private bool dethFlag = false;

    [Header("Effects")]
    public GameObject DethEffect;
    public GameObject SpawnEffect;

    private float fireDelta = 0;
    private bool canFire;
    private bool inAnimation = false;

    //Requiered fields
    private Rigidbody2D playerRigidBody;

    //Plays on awake
    private void Awake() {
        stats = new PlayerStats();
        stats.UpdateStats();
        currentHelth = stats.Helth;
    }

    // Use this for initialization
    void Start () {
        //Gets the rigidbody
        playerRigidBody = GetComponent<Rigidbody2D>();
        //Sets the radious
        radius = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        //Sets fire veriables
        canFire = true;
        //Sets flag
        inAnimation = false;
        //Creates the heelth bar
        createHelthBar();
        //Spawns effect
        Instantiate(SpawnEffect, transform.position, Quaternion.identity);
    }

    //Sets the helth bar
    private void createHelthBar() {
        //Creates a helth bar
        tempHelthBar = Instantiate(PlayerHelthBar, GameObject.Find("PlayerHelthBarHolder").transform);
        //Sets the bar values
        tempHelthBar.GetComponent<PlayerHelthBar>().SetValues(stats.Helth, GameManager.GM.ExperanceForNextLevel(), GameManager.GM.GetCurrentExpereance());
    }

    //Update
    void Update() {
        if (WaveManager.WM.InBossAnimation && !WaveManager.WM.PlayerInPosition) {
            StartCoroutine(MoveToNewPosition());
        }
        else if (!WaveManager.WM.InBossAnimation) {
            //Moves the player
            MovePlayer();
            //Rotates the player
            rotatePlayer();
            //Fiers a bulet
            fireBulet();
        }
    }

    //Gers XP
    public void ColectXP(float f) {
        //Adds experiance
        tempHelthBar.GetComponent<PlayerHelthBar>().AddExpereance(f);
    }

    //if the player colides with an enemy
    void OnTriggerEnter2D(Collider2D other) {
        BaseEnemy baseCol = other.GetComponent<BaseEnemy>();
        if(baseCol != null) {
            TakeDamage(currentHelth + 1);
        }
    }

    //Takes damage
    public void TakeDamage(float f) {
        //Takes helth away
        currentHelth -= f;
        //Changes bar length
        tempHelthBar.GetComponent<PlayerHelthBar>().ChangeHelth(currentHelth);
        //if the player has no helth
        if(currentHelth <= 0) StartCoroutine(playerDies());
    }

    //If the payer dies
    private IEnumerator playerDies() {
        if (!dethFlag) {
            dethFlag = true;
            //Spawns effect
            Instantiate(DethEffect, transform.position, Quaternion.identity);
            //Stops player
            playerRigidBody.velocity = Vector2.zero;
            //Disbles collision
            GetComponent<CircleCollider2D>().enabled = false;
            //Desables player
            GetComponent<SpriteRenderer>().enabled = false;
            //Sets helth and helth bar
            currentHelth = stats.Helth;
            tempHelthBar.GetComponent<PlayerHelthBar>().ChangeHelth(currentHelth);
            //Wiats about 1 second
            yield return new WaitForSeconds(1);
            //Moves to the center
            transform.position = Vector3.zero;
            //Spawns effect
            Instantiate(SpawnEffect, transform.position, Quaternion.identity);
            //Enables player
            GetComponent<SpriteRenderer>().enabled = true;
            //Wiats about 1 seconds
            yield return new WaitForSeconds(1);
            dethFlag = false;
            //Enables collision
            GetComponent<CircleCollider2D>().enabled = true;
            //Sets flag
            dethFlag = false;
        }
    }

    public IEnumerator MoveToNewPosition() {
        if (!inAnimation) {
            //Sets animation flag
            inAnimation = true;
            //Stops the player
            playerRigidBody.velocity = Vector2.zero;
            //Stores veriable localy
            Vector2 pos = WaveManager.WM.PlayerPosition;
            //Calculates the new position
            Vector3 targetPos = new Vector3((GameManager.GM.ScreenSize.x * pos.x) + (radius * -pos.x), (GameManager.GM.ScreenSize.y * pos.y) + (radius * -pos.y), 0);
            //Sets the postion to look at
            transform.up = targetPos - transform.position;
            //If the player is moving
            while (!moveToNewPosition(targetPos)) {
                yield return null;
            }
            //Sets flag on the wave manage
            WaveManager.WM.PlayerInPosition = true;
            //Whilst the animation is on gooing
            while (WaveManager.WM.InBossAnimation) {
                Vector3 lookPos = Vector3.zero;
                //if an enemt egsists
                if(WaveManager.WM.GetEnemyPos(ref lookPos)) {
                    //looks at the enemy
                    transform.up = lookPos - transform.position;
                }
                yield return null;
            }
            //Switches flag
            inAnimation = false;
        }
    }

    //Moves the enemy to a new position
    private bool moveToNewPosition(Vector3 newPos) {
        //If the enemy is at the right position
        if (Vector3.Distance(transform.position, newPos) < 0.1) {
            //Sets the position and returns true
            transform.position = newPos;
            return true;
        }
        //Moves the enemy
        transform.localPosition = Vector3.MoveTowards(transform.position, newPos, (stats.MoveSpeed / 100) * Time.deltaTime);
        //Returns fals
        return false;
    }

    //Function that moves the player
    private void MovePlayer() {
        //Stops the player
        playerRigidBody.velocity = Vector2.zero;
        //moving falwerd and backwords
        if (Input.GetButton("Vertical")) {
            //Gets the user input
            float InputSpeed = Input.GetAxis("Vertical");
            //If the player is going falwerd
            if (InputSpeed > 0) InputSpeed = 1;
            //If the player is going Backwords
            else InputSpeed = -1;
            //Calculates the player speed
            Vector2 NewVelosoty = (transform.up * ((stats.MoveSpeed * InputSpeed) * Time.deltaTime));
            //Sets the velosoty
            playerRigidBody.velocity = NewVelosoty;
            //If the player goes off screen
            offScreen();
        }
    }

    //If the player goes off screen
    private void offScreen() {
        float newX = transform.position.x, newY = transform.position.y;
        //Flag to change the position
        bool changePos = false;
        //changes the position on the x
        if(transform.position.x > GameManager.GM.ScreenSize.x || transform.position.x < -GameManager.GM.ScreenSize.x - radius) {
            //Changes the position
            if (transform.position.x > 0) newX = (transform.position.x * -1) + radius;
            else newX = (transform.position.x * -1) - radius;
            //Flag
            changePos = true;
        }
        //changes the position on the y
        if (transform.position.y > GameManager.GM.ScreenSize.y + radius || transform.position.y < -GameManager.GM.ScreenSize.y - radius) {
            //Changes the position
            if (transform.position.y > 0) newY = (transform.position.y * -1) + radius;
            else newY = (transform.position.y * -1) - radius;
            //Flag
            changePos = true;
        }
        //If the flag has been fliped, changePos ethe position
        if (changePos) {
            transform.position = new Vector3(newX, newY, 0);
        }
    }

    //Rotates the player
    private void rotatePlayer() {
        //Gets the player input
        if (Input.GetButton("Horizontal")) {
            float InputSpeed = Input.GetAxis("Horizontal");
            //If the player is going falwerd
            if (InputSpeed > 0) InputSpeed = -1;
            //If the player is going Backwords
            else InputSpeed = 1;
            //Rotates the player
            transform.Rotate(InputSpeed * (Vector3.forward * stats.TurnSpeed) * Time.deltaTime);
        }
    }

    //Fiering a bulet
    public void fireBulet() {
        //if the player can not fire
        if (!canFire) {
            //Incriments timer
            fireDelta += Time.deltaTime;
            //Sets can fire to true if enought time has pased
            if(fireDelta >= stats.FireRate) {
                canFire = true;
            }
        }
        //If the player clicks the left mouse button and they can fier a bulet
        if(Input.GetButton("Fire1") && canFire){
            GameObject tempBulet = Instantiate(Bulet,FirePoint.position,Quaternion.identity);
            //Sets the rotation
            tempBulet.transform.up = FirePoint.position - transform.position;
            //Sets the stast
            tempBulet.GetComponent<Bulet>().SetStatat(stats.Damage, true, stats.BuletSpeed + stats.MoveSpeed);
            //Resets shooting peramiters
            canFire = false;
            fireDelta = 0;
        }
    }

}
