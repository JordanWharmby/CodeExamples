﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerStats {

    //Peramiters
    private float moveSpeed, playerHelth, turnSpeed, fireRate, damage, buletSpeed;

    //Sets the peramiters
    public void UpdateStats() {
        PlayerSaveDataClass PSD = GameManager.GM.SaveData().PSD;
        playerHelth = PSD.PlayerHelth;
        moveSpeed = PSD.PlayerMoveSpeed;
        turnSpeed = PSD.PlayerTurnSpeed;
        fireRate = PSD.FireRate;
        damage = PSD.Damage;
        buletSpeed = PSD.BuletSpeed;
    }

    //Getters
    public float MoveSpeed { get { return moveSpeed; } }
    public float Helth { get { return playerHelth; } }
    public float TurnSpeed { get { return turnSpeed; } }
    public float FireRate { get { return fireRate; } }
    public float Damage { get { return damage; } }
    public float BuletSpeed { get { return buletSpeed; } }

}
