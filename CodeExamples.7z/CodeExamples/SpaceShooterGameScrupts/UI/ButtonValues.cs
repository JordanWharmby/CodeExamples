﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class ButtonValues : MonoBehaviour {

    [Header("Title")]
    public Text SaveTitle;

    //The save number
    private int saveNumber;

    //Sets data 
	public void SetSaveData(int i) {
        saveNumber = i;
        SaveTitle.text = "Save " + i;
    }

    //Sets save number
    public void SetSaveNumber() {
        //Sets the save number
        GameManager.GM.CurentSave = saveNumber - 1;
        GameManager.GM.SetSceen(1);
    }

}
