﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class ScoreManager : MonoBehaviour {

    //Static veriable
    public static ScoreManager SM;

    //Text for the score
    public Text ScoreText;
    
    //Score
    private float score = 0;

    private void Awake() {
        //Singlton
        if (SM == null) SM = this;
        else if (SM != this) Destroy(gameObject);
        //Sets the score text
        SetScoreText(0);
    }

    //Modifiys the score text
    public void SetScoreText(float s) {
        //Sets the score
        score += s;
        //Changes the text
        ScoreText.text = "Score: " + score;
    }

}
