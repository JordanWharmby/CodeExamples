﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenu : MonoBehaviour {

    //Pages
    public GameObject[] Pages;
    //Save Prefab
    public GameObject SavePrefad;
    //Save Positions
    public Transform[] SavePerents;

    //Private fields
    private int curentPage = 0;

	// Use this for initialization
	void Start () {
        //Sets the curent page
        curentPage = 0;
        //Sets the page to be visible
        SetCurentPage(curentPage);
        //Creates the save slots
        createSaveSlots();
    }
	
    //Cretaes the save slots
    private void createSaveSlots() {
        int i = 1;
        foreach(Transform t in SavePerents) {
            //Cretaes a save tab and sets its position
            GameObject temp = Instantiate(SavePrefad, t);
            temp.GetComponent<ButtonValues>().SetSaveData(i);
            i++;
        }
    }

    public void SetCurentPage(int page) {
        //Sets the curent page
        curentPage = page;
        //Loops throught the pages
        for(int i = 0; i < Pages.Length; i++) {
            //Seat the activnes of the page
            Pages[i].SetActive(i == curentPage);
        }
    }

	// Update is called once per frame
	void Update () {
        //If the uset is on the first page
        if (curentPage == 0 && Input.anyKey) SetCurentPage(1);
	}
}
