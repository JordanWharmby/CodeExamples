﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackToGameButton : MonoBehaviour {
    //Goes back to the game
	public void BackToGame() { GameManager.GM.SetSceen(1); }

}
