﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerHelthBar : MonoBehaviour {

    [Header("Bars")]
    public GameObject HelthBar;
    public GameObject ExperianceBar;

    //Private veriables
    private float maxHelthValue, curentHelthValue;
    private float maxExperianceValue, curentExperianceValue;

    //Sets the values 
    public void SetValues(float helth, float maxEperiance, float currentExperiance) {
        //If thier is more than 0 Experiance
        curentExperianceValue = GameManager.GM.AddExpereance(0);
        maxExperianceValue = GameManager.GM.ExperanceForNextLevel();
        ////Changes the bar values
        if (curentExperianceValue > 0 && maxExperianceValue > 0) {
            //Sets the bar length
            ExperianceBar.transform.localScale = new Vector3(1, curentExperianceValue / maxExperianceValue, 1);
        }
        else {
            ExperianceBar.transform.localScale = new Vector3(1, 0, 1);
        }
        //If there is more that 0 helth
        if (helth > 0) {
            maxHelthValue = helth;
            //Calculates helth to add
            float helthToAdd = maxHelthValue / 200;
            //Adds helth to the bar
            while (true) {
                //Adds to the current total
                curentHelthValue += helthToAdd;
                //Changes the bar length
                HelthBar.transform.localScale = new Vector3(1, curentHelthValue / maxHelthValue, 1);
                //if the maxamum falue has been exseeded
                if (curentHelthValue >= maxHelthValue) {
                    //Set the value
                    curentHelthValue = maxHelthValue;
                    //Change the bar length
                    HelthBar.transform.localScale = new Vector3(1, curentHelthValue / maxHelthValue, 1);
                    break;
                }
            }
        }
        else {
            HelthBar.transform.localScale = new Vector3(1, 0, 1);
        }
    }

    public void ChangeHelth(float f) {
        //Chages he;lth value
        curentHelthValue = f;
        //if helth is <= 0
        if(curentHelthValue <= 0) {
            //Sets value
            curentHelthValue = 0;
            //Changes bar length
            HelthBar.transform.localScale = new Vector3(1, 0, 1);
        }
        //if the player still has helth left
        else {
            //if the player gets to much helth
            if (curentHelthValue >= maxHelthValue) curentHelthValue = maxHelthValue;
            //changes bar length
            HelthBar.transform.localScale = new Vector3(1, curentHelthValue / maxHelthValue, 1);
        }
    }
    //Adds experiance
    public void AddExpereance(float f) {
        //Adds the curent experence
        curentExperianceValue = GameManager.GM.AddExpereance(f);
        maxExperianceValue = GameManager.GM.ExperanceForNextLevel();
        ////Changes the bar values
        if (curentExperianceValue > 0 && maxExperianceValue > 0) {
            //Sets the bar length
            ExperianceBar.transform.localScale = new Vector3(1, curentExperianceValue / maxExperianceValue, 1);
        }
        else {
            ExperianceBar.transform.localScale = new Vector3(1, 0, 1);
        }
    }
}
