﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class UpgradeButton : MonoBehaviour {

    //Text
    public Text ButtonText;

    public Image UpgradeBar;

    //Value to upgrade
    private int valueToUpgrade;

    //Sets the value to upgrade
    public void SetUpgradeValue(int i, string s, int curentVal, int maxValue) {
        //Sets the value to upgrade
        valueToUpgrade = i;
        //Sets the text
        ButtonText.text = s + " : " + curentVal + "/" + maxValue;
        //Sets the bar length
        if (curentVal == 0) {
            UpgradeBar.fillAmount = 0;
        }
        else {
            float newVal = ((float)curentVal / (float)maxValue);
            UpgradeBar.fillAmount = newVal;
        }
    }

    //If the button is clicked
    public void ButtonClicked() {
        UpgradeManager.UM.UpgradePlayerStats(valueToUpgrade);
    }

}
