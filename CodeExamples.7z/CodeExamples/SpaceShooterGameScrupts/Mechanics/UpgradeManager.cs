﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UpgradeManager : MonoBehaviour {

    //Static Instance
    public static UpgradeManager UM;

    [Header("Button Holder")]
    public Transform ButtonHolder;
    [Header("Button")]
    public GameObject Button;
    [Header("Text for the poits avalible")]
    public Text PointsTex;

    //List of buttons
    List<GameObject> butonList = new List<GameObject>();

    //Holds the save data
    private SaveData sd;

    //Plays on awake
    private void Awake() {
        //Sets the static veriable
        UM = this;
        //Gets the save data
        sd = GameManager.GM.SaveData();
        //Sets the points text
        PointsTex.text = "Points: " + sd.PSD.UpgradePoints;
    }

    // Use this for initialization
    void Start () {
        PlayerUpgradeClass PUS = sd.PUD;
        //Creates all of the buttons
        for(int i = 0; i < PUS.US.Count; i++) {
            GameObject temp = Instantiate(Button, ButtonHolder);
            temp.GetComponent<UpgradeButton>().SetUpgradeValue(i, PUS.US[i].Name, PUS.US[i].CurrentLevel, PUS.US[i].MaxLevel);
            butonList.Add(temp);
        }
	}

    public void UpgradePlayerStats(int i) {
        //if the player can upgrade
        if(sd.PSD.CanUpgrade() && sd.PUD.US[i].AtMax()) {
            //stores the value
            float value = sd.PUD.US[i].UpgradeValue;
            //Adds point to value
            sd.PUD.US[i].AddPoint();
            //Adds value to player stats
            sd.PSD.AddValue(i, value, true);
            //Changes the points text
            PointsTex.text = "Points: " + sd.PSD.UpgradePoints;
            //Overides save
            OverideSave();
            //Upgrade class
            PlayerUpgradeClass PUS = sd.PUD;
            //Changes all values
            for (int j = 0; j < butonList.Count; j++) {
                butonList[j].GetComponent<UpgradeButton>().SetUpgradeValue(j, PUS.US[j].Name, PUS.US[j].CurrentLevel, PUS.US[j].MaxLevel);
            }
        }
    }

    //Cahnges the save data
    public void OverideSave() { GameManager.GM.Save(sd); }
	
}
