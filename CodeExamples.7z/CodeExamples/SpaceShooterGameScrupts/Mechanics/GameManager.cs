﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine.SceneManagement;
using UnityEngine;

public class GameManager : MonoBehaviour {

    //Static singlton
    public static GameManager GM;

    //Player
    public GameObject PlayerObject;
    private GameObject curentPlayer;

    //Screen dimentions
    private Vector3 screenSize;

    //Array of save data
    private SaveData[] saveData;
    private int currentSave = 0;

    //Plays on awake
    private void Awake() {
        //If there is no Game manager
        if (GM == null) GM = this;
        //if the instanceis not this one
        else if (GM != this) Destroy(gameObject);
        //Object is caryed to other sceens
        DontDestroyOnLoad(gameObject);
        //Sets the save data array
        saveData = new SaveData[4];
        //Crattes the save data
        CreateSaveData();
    }

    //Sets the curent sceen
    public void SetSceen(int i) {
        SceneManager.LoadScene(i);
    }

    // Use this for initialization
    void Start() {
        //Sets the screen size
        SetScreeSize(1,1);
    }

    public void SpawnPlayer() {
        curentPlayer = Instantiate(PlayerObject, Vector3.zero, Quaternion.identity);
    }

    //Gets the players current position
    public Vector3 PlayerPos { get { return curentPlayer.transform.position; } }

    //If the object colides with the player
    private void OnTriggerEnter2D(Collider2D collision) {
        PlayerControler pc = collision.GetComponent<PlayerControler>();
        if(pc != null) { }
    }

    public void SetScreeSize(float x, float y) {
        screenSize = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width * x, Screen.height * y, 0));
    }

    //Returns the screen size
    public Vector3 ScreenSize { get { return screenSize; } }

    public void ResetData() {
        for (int i = 0; i < saveData.Length; i++) {
            File.Delete(Application.persistentDataPath + "/PlayerInfo" + i + ".dat");
        }
    }

    //Getter and setter for the curent save
    public int CurentSave {
        get { return currentSave; }
        set { currentSave = value; }
    }

    public SaveData SaveData() {
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Open(Application.persistentDataPath + "/PlayerInfo" + currentSave + ".dat", FileMode.Open);
        SaveData data = (SaveData)bf.Deserialize(file);
        file.Close();
        return data;
    }

    public float AddExpereance(float f) {
        //Gets the save data
        SaveData sd = SaveData();
        float temp = sd.PSD.AddExperiance(f);
        Save(sd);
        return temp;
    }

    public float GetCurrentExpereance() {
        SaveData sd = SaveData();
        return sd.PSD.CurentExperiance;
    }

    //Gets experance for next level
    public float ExperanceForNextLevel() {
        SaveData sd = SaveData();
        return sd.PSD.ExperianceForNextLevel;
    }

    public void Save() {
        File.Delete(Application.persistentDataPath + "/PlayerInfo" + currentSave + ".dat");
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/PlayerInfo" + currentSave + ".dat");
        SaveData data = SaveData();
        bf.Serialize(file, data);
        file.Close();
    }

    //Saves New Data
    public void Save(SaveData sd) {
        File.Delete(Application.persistentDataPath + "/PlayerInfo" + currentSave + ".dat");
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/PlayerInfo" + currentSave + ".dat");
        SaveData data = sd;
        bf.Serialize(file, data);
        file.Close();
    }

    //Creates the save sata
    public void CreateSaveData() {
        SaveData data = new SaveData();
        BinaryFormatter bf = new BinaryFormatter();
        //loops through the data
        for(int i = 0; i < saveData.Length; i++) {
            if (File.Exists(Application.persistentDataPath + "/PlayerInfo" + i + ".dat")) {
                FileStream file = File.Open(Application.persistentDataPath + "/PlayerInfo" + i + ".dat", FileMode.Open);
                data = (SaveData)bf.Deserialize(file);
                saveData[i] = data;
                file.Close();
            }
            //creates a file
            else {
                FileStream file = File.Create(Application.persistentDataPath + "/PlayerInfo" + i + ".dat");
                data.NewSave();
                bf.Serialize(file, data);
                saveData[i] = data;
                file.Close();
            }
        }
    }

}