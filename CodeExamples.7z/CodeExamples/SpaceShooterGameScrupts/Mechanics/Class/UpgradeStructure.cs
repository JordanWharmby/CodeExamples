﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class UpgradeStructure {

    //Peramiters
    private string data_Name;
    private int data_CurrentLevel;
    private int data_MaxLevel;
    private float data_UpgradeValue;
	
    public UpgradeStructure values(string name, int currentLevel, int maxLevel, float upgradeValue) {
        //Sets values
        data_Name = name;
        data_CurrentLevel = currentLevel;
        data_MaxLevel = maxLevel;
        data_UpgradeValue = upgradeValue;
        //Teturns struct
        return this;
    }

    //Is the level at max
    public bool AtMax() { return data_CurrentLevel < data_MaxLevel; }

    //Adds a point to the list
    public void AddPoint() { data_CurrentLevel++; }

    //Getters and setters
    public string Name {
        get { return data_Name; }
    }

    public int CurrentLevel {
        get { return data_CurrentLevel; }
        set { data_CurrentLevel = value; }
    }

    public int MaxLevel {
        get { return data_MaxLevel; }
        set { data_MaxLevel = value; }
    }

    public float UpgradeValue {
        get { return data_UpgradeValue; }
    }

}
