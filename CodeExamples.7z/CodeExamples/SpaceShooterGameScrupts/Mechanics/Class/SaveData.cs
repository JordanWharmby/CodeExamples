﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveData {

    //Player statisitcs
    public PlayerSaveDataClass PSD;
    //Upgrade Statitics
    public PlayerUpgradeClass PUD;

    public SaveData NewSave() {
        PSD = new PlayerSaveDataClass().NewSave();
        PUD = new PlayerUpgradeClass().NewSave();
        return this;
    }
	
}
