﻿using UnityEngine;

[System.Serializable]
public class EnemyIndex {
    [Header("Object")]
    public GameObject EnemyObjest;
    [Header("Index")]
    public char Index;
}
