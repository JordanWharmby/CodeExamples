﻿using UnityEngine;

[System.Serializable]
public class WaveClass {
    public enum e_WaveType {
        NORMAL,
        BOSS
    };
    [Header("WaveType")]
    public e_WaveType WaveType;
    [Header("Enemys To Spawn")]
    public string EnemysToSpawn;
    [Header("Delay Betwean Rounds")]
    public float Delay;
    [Header("Player Start point")]
    [Range(-1, 1)]
    public float PosX;
    [Range(-1, 1)]
    public float PosY;
}
