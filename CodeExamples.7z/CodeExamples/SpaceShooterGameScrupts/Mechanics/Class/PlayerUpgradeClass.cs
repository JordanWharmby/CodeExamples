﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerUpgradeClass {

    public List<UpgradeStructure> US = new List<UpgradeStructure>();

    public PlayerUpgradeClass NewSave() {
        //Adds all of the values
        US.Add(new UpgradeStructure().values("Helth", 0, 10, 25));
        US.Add(new UpgradeStructure().values("Speed", 0, 10, 5));
        US.Add(new UpgradeStructure().values("Damage", 0, 10, 5));
        US.Add(new UpgradeStructure().values("Fire Rate", 0, 10, 0.1f));
        US.Add(new UpgradeStructure().values("Bulet Speed", 0, 10, 50));
        //returns value
        return this;
    }

    public UpgradeStructure GetData(int i) { return US[i]; }

}
