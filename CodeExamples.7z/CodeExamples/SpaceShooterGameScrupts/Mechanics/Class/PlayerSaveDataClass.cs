﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class PlayerSaveDataClass {
    //Veriable for the player
    private float data_MoveSpeed, data_Helth, data_TurnSpeed, data_FireRate, data_Damage, data_BuletSpeed;
    private bool newSave;

    //UpgradeVeriables
    private int data_Level, data_curentUpgradePoints;
    private float data_CurentExperence, data_ExperianceForNextLevel;

    //Creates a new save
    public PlayerSaveDataClass NewSave() {
        //Setds the new save flag to false
        newSave = true;
        data_MoveSpeed = 500;
        data_Helth = 100;
        data_TurnSpeed = 250;
        data_FireRate = 0.25f;
        data_Damage = 50;
        data_BuletSpeed = 100;
        data_CurentExperence = 0;
        data_ExperianceForNextLevel = 100;
        data_curentUpgradePoints = 0;
        //Returns this veriante
        return this;
    }

    //Adds onto a veriable
    public void AddValue(int i, float f, bool b) {
        switch (i) {
            //Adds to helth
            case (0):
                data_Helth += f;
                break;
            //Adds to the move speed
            case (1):
                data_MoveSpeed += f;
                data_TurnSpeed += (f / 2);
                break;
                //Adds to damage
            case (2):
                data_Damage += f;
                break;
                //Adds to fire rate
            case (3):
                data_FireRate += f;
                break;
                //Adds to bulet speed
            case (4):
                data_BuletSpeed += f;
                break;
            default:
                break;
        }
        if (b) {
            data_curentUpgradePoints--;
        }
    }

    //Adds expereance
    public float AddExperiance(float f) {
        //Adds experi
        data_CurentExperence += f;
        //Temp float
        float temp = data_CurentExperence;
        if(data_CurentExperence >= data_ExperianceForNextLevel) {
            temp = data_CurentExperence - data_ExperianceForNextLevel;
            AddLevel();
            //returns the remander
            return temp;
        }
        //returns total
        return data_CurentExperence;
    }

    //Adds to the level
    public void AddLevel() {
        data_curentUpgradePoints++;
        data_Level++;
        data_ExperianceForNextLevel *= 1.5f;
        data_CurentExperence = 0;
    }

    //If the player can upgrade
    public bool CanUpgrade() { return data_curentUpgradePoints > 0; }

    //Getter and setter for move speed
    public float PlayerMoveSpeed {
        get { return data_MoveSpeed; }
        set { data_MoveSpeed = value; }
    }

    //Getter and setter for Helth
    public float PlayerHelth {
        get { return data_Helth; }
        set { data_Helth = value; }
    }

    //Getter and setter for turn speed
    public float PlayerTurnSpeed {
        get { return data_TurnSpeed; }
        set { data_TurnSpeed = value; }
    }

    //Getter and setter for fire rate
    public float FireRate {
        get { return data_FireRate; }
        set { data_FireRate = value; }
    }

    //Getter and setter for fire rate
    public float Damage {
        get { return data_Damage; }
        set { data_FireRate = value; }
    }

    //getter and setter for the bulet speed
    public float BuletSpeed {
        get { return data_BuletSpeed; }
        set { data_BuletSpeed = value; }
    }

    //Geter and setter for the new save
    public bool IsNewSave {
        get { return newSave; }
        set { newSave = value; }
    }

    //Getter and setter for the curent experiance level
    public float CurentExperiance {
        get { return data_CurentExperence; }
        set { data_CurentExperence = value; }
    }

    //Getter and setter for the curent experiance level
    public float ExperianceForNextLevel {
        get { return data_ExperianceForNextLevel; }
        set { data_ExperianceForNextLevel = value; }
    }

    //Getter and setter for the level
    public int Level {
        get { return data_Level; }
        set { data_Level = value; }
    }

    public int UpgradePoints {
        get { return data_curentUpgradePoints; }
        set { data_curentUpgradePoints = value; }
    }

}
