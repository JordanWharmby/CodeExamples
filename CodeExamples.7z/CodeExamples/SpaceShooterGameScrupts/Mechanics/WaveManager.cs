﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaveManager : MonoBehaviour {

    //Static Veriabes
    public static WaveManager WM;

    [Header("Enemys That Can Be Spawned")]
    public EnemyIndex[] EnemyList;
    public EnemyIndex[] BossList;
    [Space()]
    [Header("Wave List")]
    public WaveClass[] Waves;
    [Space]
    [Header("End of the level")]
    public GameObject EndGameText;
    public ParticleSystem EndGameEffect;

    //State
    private enum e_State {
        SPAWN,
        WAITING,
        COOLDOWN,
        END_GAME
    };
    private e_State curentState;

    //Privat veriables
    private int currentWave;
    private List<GameObject> enemysInGame = new List<GameObject>();
    //Cooldown
    private float spawnDelta;

    //PlayerPosition
    private Vector2 playerPos;

    //Boss wave veriables
    private bool bossAnimationFlag, playerInPosition, enemyInPosition;

    //Runs on awake
    void Awake() {
        //If there is no wave manager
        if (WM == null) WM = this;
        //If the wave manger is not this one
        else if (WM != this) Destroy(gameObject);
        GameManager.GM.SetScreeSize(0.85f, 1);
        //Spawns the player
        GameManager.GM.SpawnPlayer();
    }

	// Use this for initialization
	void Start () {
        currentWave = 0;

        //Spawn delta
        spawnDelta = 0;

        //Sets the state
        curentState = e_State.COOLDOWN;

        //Sets the boss fight flags
        resetBossFightFlags();
    }
	
    private void resetBossFightFlags() {
        bossAnimationFlag = false;
        playerInPosition = false;
        enemyInPosition = false;
    }

	// Update is called once per frame
	void Update () {
        //Switch based on the current state
        switch (curentState) {
            //Cooldown betwen the rounds
            case (e_State.COOLDOWN):
                //If there are no more waves
                if(currentWave >= Waves.Length) {
                    curentState = e_State.END_GAME;
                }
                else {
                    //Adds time to the cooldown time
                    spawnDelta += Time.deltaTime;
                    //if enough time has passed
                    //Start a new wave
                    if (spawnDelta >= Waves[currentWave].Delay) {
                        //Resets timer
                        spawnDelta = 0;
                        //Sets new stage
                        curentState = e_State.SPAWN;
                    }
                }
                break;
            case (e_State.SPAWN):
                //If there are waves still left in the game
                 nextWave();
                //Sets the state to idle
                curentState = e_State.WAITING;
                break;
                //Idle state
            case (e_State.WAITING):
                break;
            case (e_State.END_GAME):
                //Sets to waiting state
                curentState = e_State.WAITING;
                //Starts end game function
                StartCoroutine(endGame());
                break;
            default:
                break;
        }
	}

    //Adds an enemy to the list of enemys
    public void AddEnemyToList(GameObject g) {
        enemysInGame.Add(g);
    }

    //returns the location of the first enemy
    public bool GetEnemyPos(ref Vector3 pos) {
        //if there are no enemys
        if (enemysInGame.Count <= 0) return false;
        //if there is an enemy
        pos =  enemysInGame[0].transform.position;
        return true;
    }

    //Alows an enemy to remve itself from the list
    public void RemoveEnemyFromList(GameObject g) {
        //Removes the enemy from the list
        enemysInGame.Remove(g);
        //If the state is curently idle and there are no enemy left in the game
        //Incriment round
        //switch to the cooldown state
        if (curentState == e_State.WAITING && enemysInGame.Count <= 0) {
            currentWave++;
            curentState = e_State.COOLDOWN;
        } 
    }

    private void nextWave() {
        switch (Waves[currentWave].WaveType) {
            //Normal wave
            case (WaveClass.e_WaveType.NORMAL):
                normalWave();
                break;
            //Boss wave
            case (WaveClass.e_WaveType.BOSS):
                StartCoroutine(bossWave());
                break;
            //Default
            default:
                break;
        }
    }

    //Spwans a regyular wave of enemys
    private void normalWave() {
        //Creates a char array of all of the enemys
        char[] index = Waves[currentWave].EnemysToSpawn.ToCharArray();
        //Loops through the array and spawns enemys
        foreach(char c in index) {
            //Temp gameobject
            GameObject temp = null;
            //Finds the enemy
            foreach(EnemyIndex EI in EnemyList) {
                //if it is the right index
                if(EI.Index == c) {
                    //Sets the enmy to spawn
                    temp = EI.EnemyObjest;
                    break;
                }
            }
            //If the enemy exists
            if (temp != null) {
                Vector3 spawnPos = Vector3.zero;
                //Calculates a valid position
                while (true) { if (newPosition(ref spawnPos,temp)) break; }
                //Spawns the enemy 
                //Adds enemy to the list of enemys
                enemysInGame.Add(Instantiate(temp, spawnPos,Quaternion.identity));
            }
        }
    }

    //If it is a boss round
    private IEnumerator bossWave() {
        if (!bossAnimationFlag) {
            playerPos = new Vector2(Waves[currentWave].PosX, Waves[currentWave].PosY);
            bossAnimationFlag = true;
            //While the player is not in the right position
            while (!playerInPosition) yield return null;
            //Spawns the enemy
            //Creates a char array of all of the enemys
            char[] index = Waves[currentWave].EnemysToSpawn.ToCharArray();
            //Loops through the array and spawns enemys
            foreach (char c in index) {
                //Temp gameobject
                GameObject temp = null;
                //Finds the enemy
                foreach (EnemyIndex EI in BossList) {
                    //if it is the right index
                    if (EI.Index == c) {
                        //Sets the enmy to spawn
                        temp = EI.EnemyObjest;
                        break;
                    }
                }
                //If the enemy exists
                if (temp != null) {
                    Vector3 spawnPos = Vector3.zero;
                    //Calculates a valid position
                    while (true) { if (newPosition(ref spawnPos, temp)) break; }
                    //Spawns the enemy 
                    //Adds enemy to the list of enemys
                    enemysInGame.Add(Instantiate(temp, spawnPos, Quaternion.identity));
                }
            }
            //While the boss is not ready
            while (!enemyInPosition) yield return null;
            //Resets andimation flags
            bossAnimationFlag = false;
            resetBossFightFlags();
        }
    }

    public Vector2 PlayerPosition {
        get { return playerPos; }
    }

    public bool InBossAnimation {
        get { return bossAnimationFlag; }
    }

    public bool PlayerInPosition {
        set { playerInPosition = value; }
        get { return playerInPosition; }
    }

    public bool BossIsReady {
        set { enemyInPosition = value; }
    }
    
    //Calculates a new position
    private bool newPosition(ref Vector3 pos, GameObject temp) {
        //Calculates the radius
        float radius = temp.GetComponent<CircleCollider2D>().radius * temp.transform.localScale.x;
        //Calculates the X and Y position
        float posX = Random.Range(-GameManager.GM.ScreenSize.x + radius, GameManager.GM.ScreenSize.x - radius);
        float posY = Random.Range(-GameManager.GM.ScreenSize.y + radius, GameManager.GM.ScreenSize.y - radius);
        //Sets the position
        pos = new Vector3(posX, posY, 0);
        Vector3 pPos = FindObjectOfType<PlayerControler>().transform.position;
        float pRadious = FindObjectOfType<PlayerControler>().transform.GetComponent<CircleCollider2D>().radius * FindObjectOfType<PlayerControler>().transform.localScale.x;
        //Returns if it is a validposition
        return (Vector3.Distance(pPos, pos) > (radius + pRadious) * 1.5f);
    }

    //Plays at the end of the level
    private IEnumerator endGame() {
        //Waits
        yield return new WaitForSeconds(2);
        //Holds position
        Vector3 pos = GameManager.GM.ScreenSize;
        //Spwnas in text
        Instantiate(EndGameText);
        //Creates effects
        Instantiate(EndGameEffect, new Vector3(pos.x * 0.8f, pos.y * 0.8f, 0), Quaternion.identity);
        Instantiate(EndGameEffect, new Vector3(-pos.x * 0.8f, pos.y * 0.8f, 0), Quaternion.identity);
        Instantiate(EndGameEffect, new Vector3(-pos.x * 0.8f, -pos.y * 0.8f, 0), Quaternion.identity);
        Instantiate(EndGameEffect, new Vector3(pos.x * 0.8f, -pos.y * 0.8f, 0), Quaternion.identity);
        //Waits
        yield return new WaitForSeconds(2);
        //Channges level
        GameManager.GM.SetSceen(2);
    }
}
