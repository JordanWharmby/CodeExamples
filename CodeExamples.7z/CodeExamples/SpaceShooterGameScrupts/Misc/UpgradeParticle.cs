﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UpgradeParticle : MonoBehaviour {

    //Veriables
    private float expereanceValue;
    //Flag
    bool b = false;
    
    //Sets the values
	public void SetValues(float f) {
        //Sets the experiance
        expereanceValue = f;
        //Sets flag
        b = true;
    }
	
	// Update is called once per frame
	void Update () {
        //If the flag has been called
        if (b) {
            transform.position = Vector3.MoveTowards(transform.position, GameManager.GM.PlayerPos, (Vector3.Distance(transform.position, GameManager.GM.PlayerPos) * 3) * Time.deltaTime);
        }
	}

    private void OnTriggerEnter2D(Collider2D collision) {
        //Gets if thier is a player controler
        PlayerControler pc = collision.transform.GetComponent<PlayerControler>();
        //if it is a player
        if (pc != null) {
            //Adds experiance
            pc.ColectXP(expereanceValue);
            //Removes game object
            Destroy(gameObject);
        }
    }
}
