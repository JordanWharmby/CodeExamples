﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectDestructor : MonoBehaviour {
    
	void Start () { Destroy(gameObject, 5); }
	
}
