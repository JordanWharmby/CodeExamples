﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class PlayerHelth_CS : MonoBehaviour {

    public GameObject HelthBar;
    public Text HelthText;

    private float helthValue, helthMax;

	public void Init(float MaxHelth) {
        //sets the initial values
        helthValue = MaxHelth;
        helthMax = MaxHelth;
        //sets the length of the helth bar
        SetBarLenght(helthValue);
    }
	
    public void SetBarLenght(float f) {
        //sets the new helth
        helthValue = f;
        //sets the helth text
        HelthText.text = "" + helthValue;
        //calculates the percentige of helth
        float tempX = helthValue / helthMax;
        //sets the bars length
        HelthBar.transform.localScale = new Vector3(tempX, 1, 1);
    }

}
