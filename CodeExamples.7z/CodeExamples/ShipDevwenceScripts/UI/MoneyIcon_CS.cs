﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class MoneyIcon_CS : MonoBehaviour {

    public GameObject MoneyText;

    public void SetText(float f) {
        MoneyText.GetComponent<TextMeshProUGUI>().text = "£" + f;
        Destroy(gameObject, 1f);
    }

}
