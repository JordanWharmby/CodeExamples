﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class SaveTab_CS : MonoBehaviour {

    public Text SaveTabText;

    private int saveNumber;

    void Start() {
        GetComponent<Button>().onClick.AddListener(SaveSelcet);
    }

    public void SetSaveNumber(int i) {
        saveNumber = i;
        SaveTabText.text = "Save Slot: " + (saveNumber + 1);
    }

    public void SaveSelcet() {
        GameManager_CS.GM.CurrentSave = saveNumber;
        FindObjectOfType<MainMenu_CS>().SetPageVisable(3);
    }
    
}
