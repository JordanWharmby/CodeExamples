﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class UpgradeButton_CS : MonoBehaviour {
    [Header("Text")]
    public Text UpgradeTitle;
    public Text UpgradeAmountText;
    public Text PriceText;
    [Header("Other Veriables")]
    public string Title;
    public int UpgradeIndex;

    //private veriables
    private float upgradePrice;
    private Upgrade_Class upgradeBase;

    void Start () {
        //gest upgrade eliment
        upgradeBase = GameManager_CS.GM.GetData().GetUpgradeClass(UpgradeIndex);
        //Title
        UpgradeTitle.text = Title;
        //Current Upgrade Point
        UpgradeAmountText.text = upgradeBase.CurrentLevel + "/" + upgradeBase.MaxLevel;
        //calculates price
        upgradePrice = upgradeBase.baseValue + ((upgradeBase.baseValue * 0.1f) * upgradeBase.CurrentLevel);
        //price text
        PriceText.text = "£" + upgradePrice;
    }
	
}
