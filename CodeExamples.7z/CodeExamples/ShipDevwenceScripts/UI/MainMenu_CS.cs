﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu_CS : MonoBehaviour {

    public GameObject[] Pages;
    [Space]
    public GameObject[] OptionsPages;
    [Space]
    public Transform[] SaveSlots;
    [Space]
    public GameObject SavePrefab;

    private int lastSceen = 0;

	void Start () {
        createSaveSlots();
        SetPageVisable(0);
        SetOptionsPageVisible(0);
    }
	

    public void Back() {
        SetPageVisable(lastSceen);
    }

    public void SetPageVisable(int p) {
        for (int i = 0; i < Pages.Length; i++) {
            if (Pages[i].activeSelf) {
                lastSceen = i;
            }
            Pages[i].SetActive(p == i);
        }
        
    }

    public void SetOptionsPageVisible(int p) {
        for (int i = 0; i < OptionsPages.Length; i++) {
            OptionsPages[i].SetActive(p == i);
        }
    }

    private void createSaveSlots() {
        for (int i = 0; i < 4; i++) {
            GameObject g = Instantiate(SavePrefab, SaveSlots[i]);
            g.GetComponent<SaveTab_CS>().SetSaveNumber(i);
        }
    }

    public void SetNewSceen(int i) {
        SceneManager.LoadScene(i);
    }

}
