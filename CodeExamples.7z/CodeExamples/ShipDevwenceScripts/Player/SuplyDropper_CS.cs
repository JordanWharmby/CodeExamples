﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SuplyDropper_CS : MonoBehaviour {

    //items to drop
    public GameObject[] Drops;
    //speed
    public float Speed;
    //rate of drops
    public float DropRate;

    private float dropDelta = 0;
    private float radious;
    private bool onScreen = false;

    void Start () {
        //gets the radious
        radious = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        //calculates its position
        while (true) {
            transform.position = calculatePosition();
            transform.up = new Vector3((transform.position.x), (transform.position.y * -1), 0) - transform.position;
            if (WaveSpawner_CS.WaveSpawner.CheckPosition(transform.position,GetComponent<CircleCollider2D>().radius * transform.localScale.x)) {
                break;
            }
        }
        
        //sets the speed
        GetComponent<Rigidbody2D>().velocity = (new Vector3((transform.position.x), (transform.position.y * -1), 0) - transform.position) * (Speed * Time.deltaTime);
    }
	
    //calculates a position
    private Vector3 calculatePosition() {
        //generats a random number
        float f = Mathf.Round(Random.Range(0, 11));
        print(f);
        //top of the screen
        if (f % 2 == 0) {
            return new Vector3(Random.Range(-GameManager_CS.GM.GetScreenSize().x + (radious * 1.5f), GameManager_CS.GM.GetScreenSize().x - (radious * 1.5f)), GameManager_CS.GM.GetScreenSize().y + (radious * 1.5f), 0);
        }
        //bottom of the screen
        else {
            return new Vector3(Random.Range(-GameManager_CS.GM.GetScreenSize().x + (radious * 1.5f), GameManager_CS.GM.GetScreenSize().x - (radious * 1.5f)), -GameManager_CS.GM.GetScreenSize().y - (radious * 1.5f), 0);
        }
    }

	void Update () {
        //destroys the gameobject
        //if it is off screen
        if (!onScreen) {
            onScreen = !offScreen();
        }
        if (onScreen && offScreen()) {
            WaveSpawner_CS.WaveSpawner.RemoveEnemy(this.gameObject);
            Destroy(this.gameObject);
        }
        //supply drop delay
        dropDelta += Time.deltaTime;
        if(dropDelta >= DropRate) {
            //rested timer
            dropDelta = 0;
            //selects an item to drop
            int dropNumber = Mathf.RoundToInt(Random.Range(0, Drops.Length));
            //spawns an item
            Instantiate(Drops[dropNumber], transform.position, Quaternion.identity);
        }

	}
    
    //if the object is off screen
    private bool offScreen() {
        return (transform.position.y < -GameManager_CS.GM.GetScreenSize().y * 0.8f - (radious * 3) ||
            transform.position.y > +GameManager_CS.GM.GetScreenSize().y * 0.8f + (radious * 3) ||
            transform.position.x < -GameManager_CS.GM.GetScreenSize().x * 0.8f - (radious * 3) ||
            transform.position.x > +GameManager_CS.GM.GetScreenSize().x * 0.8f + (radious * 3));
    }

}