﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class Player_Controler_CS: MonoBehaviour {

    [Header("Player Stats")]
    public float PlayerSpeed;
    public float PlayerHelthMax;

    public GameObject Helthbar;
    private GameObject helthBar;

    private float money;
    private float tempMoney;
    private GameObject MoneyText;

    [Space]
    public Node_CS[] BuldNodes;
    private Rigidbody2D rigi;
    private Vector2 shipSize;
    private float currentHelth;
    private bool isDead = false;
    private bool dethAnimation = false;

    void Start() {
        rigi = GetComponent<Rigidbody2D>();
        shipSize = GetComponent<CapsuleCollider2D>().size;
        //sets veriables
        PlayerHelthMax = GameManager_CS.GM.GetData().GetHelth();
        PlayerSpeed = GameManager_CS.GM.GetData().GetSpeed();
        //sets the current helth
        currentHelth = PlayerHelthMax;
        if (GameManager_CS.GM.InGame) {
            Transform tr = GameObject.Find("PlayerHelth_Background").transform;
            helthBar = Instantiate(Helthbar, tr);
            helthBar.GetComponent<PlayerHelth_CS>().Init(PlayerHelthMax);
            MoneyText = GameObject.Find("MoneyAmount");
            money = GameManager_CS.GM.GetData().Money;

        }
    }

    void Update() {
        if (!GameManager_CS.GM.InGame) return;
        //if the player has no helth
        if (!isDead) {
            //moves the player
            movePlayer();
        }
    }

    public void AddMoney(float f) {
        tempMoney += f;
        MoneyText.GetComponent<Text>().text = "£" + (money + tempMoney);
    }

    public float GetMoney() {
        return tempMoney + money;
    }

    public void DisableColision() {
        GetComponent<CapsuleCollider2D>().enabled = false;
    }

    //moves the player
    private void movePlayer() {
        float velX = 0, velY = 0;
        //moving left or right
        if (Input.GetButton("Horizontal") && canMove(true)) {
            if (Input.GetAxis("Horizontal") > 0 || Input.GetAxis("Horizontal") < 0) {
                velX = ((PlayerSpeed * 100) * Input.GetAxis("Horizontal")) * Time.deltaTime;
            }
        }
        //moves the player up and down
        if (Input.GetButton("Vertical") && canMove(false)) {
            if (Input.GetAxis("Vertical") > 0 || Input.GetAxis("Vertical") < 0) {
                velY = ((PlayerSpeed * 100) * Input.GetAxis("Vertical")) * Time.deltaTime;
            }
        }
        //moves the player to the new position
        rigi.velocity = new Vector2(velX, velY);
    }
    
    private bool canMove(bool b) {
        if (b) {
            return ((transform.position.x <= GameManager_CS.GM.GetScreenSize().x && Input.GetAxis("Horizontal") >= 0) || (transform.position.x >= -GameManager_CS.GM.GetScreenSize().x && Input.GetAxis("Horizontal") <= 0)); 
        }
        else {
            return ((transform.position.y <= GameManager_CS.GM.GetScreenSize().y && Input.GetAxis("Vertical") >= 0) || (transform.position.y >= -GameManager_CS.GM.GetScreenSize().y && Input.GetAxis("Vertical") <= 0));
        }
    }
    
    public void TakeDamage(float f) {
        if (isDead) return;
        currentHelth -= f;
        currentHelth = Mathf.Clamp(currentHelth, 0, PlayerHelthMax);
        helthBar.GetComponent<PlayerHelth_CS>().SetBarLenght(currentHelth);
        if(currentHelth <= 0) {
            isDead = true;
            StartCoroutine(playerIsDead());
            rigi.velocity = Vector2.zero;
        }
    }

    void OnTriggerEnter2D(Collider2D other) {
        //hittling a suply prop
        if (other.gameObject.tag == "Supply") {
            Supply_CS s = other.transform.GetComponent<Supply_CS>();
            addSuplys(s.Helth);
            Destroy(other.gameObject);
        }
    }

    private void addSuplys(float h) {
        //adds helth
        currentHelth += h;
        //caps at max
        if(currentHelth > PlayerHelthMax) {
            currentHelth = PlayerHelthMax;
        }
    }

    private IEnumerator playerIsDead() {
        if (!dethAnimation) {
            dethAnimation = true;
            WaveSpawner_CS.WaveSpawner.HideEnemys();
            //waits a short time
            yield return new WaitForSeconds(0.2f);
            //Destruction animation for turets
            for (int i = 0; i < BuldNodes.Length; i++) {
                if(BuldNodes[i].currentTuret != null) {
                    BuldNodes[i].currentTuret.GetComponent<Turret_CS>().DestroyTurret();
                    yield return new WaitForSeconds(1);
                }
            }
        }
    }

    public bool IsDead() { return isDead; }

}
