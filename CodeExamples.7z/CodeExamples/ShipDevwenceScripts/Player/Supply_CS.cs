﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Supply_CS : MonoBehaviour {

    public float Helth;
    public float Armmor;
    public float Money;

}
