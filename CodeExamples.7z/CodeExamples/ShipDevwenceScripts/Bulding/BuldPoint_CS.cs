﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuldPoint_CS : MonoBehaviour {

    //veriables
    public bool SpotInUse;

    public GameObject Turret;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
