﻿using UnityEngine;
using UnityEngine.EventSystems;

public class Node_CS : MonoBehaviour {

    public Color NormalColour;
    public Color HoverColour;

    private SpriteRenderer rend;
    public GameObject currentTuret;
    private BuldManager_CS buldManager;

    private int nodeNum;

    void Start () {
        rend = GetComponent<SpriteRenderer>();
        rend.color = NormalColour;
        buldManager = BuldManager_CS.instance;
	}

    void OnMouseEnter() {
        if (buldManager.BuldMode) {
            if (EventSystem.current.IsPointerOverGameObject()) return;
            if (buldManager.CanBuld) rend.color = HoverColour;
        }
    }
    
    void OnMouseExit() {
        rend.color = NormalColour;
    }

    void OnMouseDown() {
        if (!buldManager.CanBuld || buldManager.Bulding) return;
        //if a turet is on the spot
        buldManager.Node = this;
        if (currentTuret != null) {
            buldManager.Bulding = true;

            buldManager.SetTurretToBuld(currentTuret.GetComponent<Turret_CS>().TurretIndex, currentTuret.GetComponent<Turret_CS>().TurretLevel, currentTuret.GetComponent<Turret_CS>().TurretLevel < currentTuret.GetComponent<Turret_CS>().MaxLevel);
            FindObjectOfType<ShopManager_CS>().SetButton(1);
            FindObjectOfType<ShopManager_CS>().SetPage(2);
            FindObjectOfType<ShopManager_CS>().SetUpgradeButton(currentTuret.GetComponent<Turret_CS>().TurretLevel < currentTuret.GetComponent<Turret_CS>().MaxLevel);
            return;
        }
        else {
            buldManager.Bulding = true;
            FindObjectOfType<ShopManager_CS>().SetPage(1);
        }
        buldManager.BuldTuretOn(this);
    }

    public Vector3 GetBuldPosition() {
        return transform.position;
    }
	
    public int NodeNumber {
        get { return nodeNum; }
        set { nodeNum = value; }
    }

}
