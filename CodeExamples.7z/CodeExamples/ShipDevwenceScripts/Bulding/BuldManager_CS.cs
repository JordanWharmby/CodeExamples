﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuldManager_CS: MonoBehaviour {
    public static BuldManager_CS instance;
    public GameObject[] Ships;
    public Turret_Class[] Turrets;
    // Use this for initialization
    public Turret_Class TurretToBuld;

    private GameObject TuretObject;

    public Node_CS Node;

    private bool inBuldMode = true;
    private bool bulding;

    void Awake() {
        if (instance == null) {
            instance = this;
        }
        else if (instance != this) {
            Destroy(this);
        }
        DontDestroyOnLoad(this);
    }

    public void SetTurretToBuld(int i, int j, bool b) {
        TurretToBuld = Turrets[i];
        TuretObject = TurretToBuld.Prefabs[j];

        if (b) {
            GameObject to = TurretToBuld.Prefabs[j + 1];
            FindObjectOfType<TuretInfomationPage_CS>().SetBarLengths(TuretObject.GetComponent<Turret_CS>(), to.GetComponent<Turret_CS>(), TurretToBuld.Cost[j + 1]);
        }
        else {
            FindObjectOfType<TuretInfomationPage_CS>().SetBarLengths(TurretToBuld.Prefabs[j].GetComponent<Turret_CS>(), TurretToBuld.Cost[j]);
        }
    }

    public void BuldTuretOn(Node_CS node) {

    }

    public void SetBulding(bool b) {
        bulding = b;
    }

    public bool Bulding {
        get { return bulding; }
        set { bulding = value; }
    }

    public bool BuldMode {
        get { return inBuldMode; }
        set { inBuldMode = value; }
    }
    
    public bool CanBuld {
        get { return true; /*TurretToBuld != null;*/ }
    }

    public void SetTuretTobuld(Turret_Class turet) {
        TurretToBuld = turet;
    }

    public void AddTuret() {
        if (Node.currentTuret != null) return;
        Node.currentTuret = Instantiate(TuretObject, Node.transform);
        Node.currentTuret.transform.localPosition = Vector3.zero;
    }

    public void CreatPlayer() {
        //Gets the data
        PlayerData data = GameManager_CS.GM.GetData();
        //creates the ship
        GameObject ship = Instantiate(Ships[data.ShipIndex]);
        //Gets player controler
        Player_Controler_CS PC = ship.GetComponent<Player_Controler_CS>();

        //places turrets on the ship
        for (int i = 0; i < PC.BuldNodes.Length; i++) {
            Node_CS node = PC.BuldNodes[i];
            node.NodeNumber = i;
            int j = data.GetCurrentTurret(i);
            if (j != -1) {
                node.currentTuret = Instantiate(Turrets[j].Prefabs[data.GetCurrentTurretLevel(i)], node.transform);
                node.currentTuret.transform.localPosition = Vector3.zero;
            }
        }
    }
}
