﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile_CS: MonoBehaviour {

    public Projectile Base;

    private Rigidbody2D rigi;

    private float radious;

    private float detDelta;

    public void Init(Projectile p) {
        rigi = GetComponent<Rigidbody2D>();
        Base = p;
        gameObject.AddComponent<CircleCollider2D>();
        //sets the sprite
        GetComponent<SpriteRenderer>().sprite = Base.Sprite;
        //gets the radious
        radious = transform.localScale.x * 0.1f;
    }

    void Update() {
        if (offScreen()) {
            Destroy(gameObject);
        }
        if (Base.UseFuse) {
            detDelta += Time.deltaTime;
            if (detDelta >= Base.Fuse) {
                detonate();
                Destroy(gameObject);
            }
        }
    }

    //method for setting the velocoty
    public void SetVelocoty(bool b) {
        if (b) {
            rigi.velocity = transform.right * (Base.Velocoty * Time.deltaTime);
        }
        else {
            rigi.velocity = Vector2.up * (Base.Velocoty * Time.deltaTime);
        }
    }

    public void SetVelocoty(Vector2 v) {
        rigi.velocity = v;
    }

    private bool offScreen() {
        return (transform.position.y < -GameManager_CS.GM.GetScreenSize().y - radious ||
            transform.position.y > GameManager_CS.GM.GetScreenSize().y + radious ||
            transform.position.x < -GameManager_CS.GM.GetScreenSize().x - radious ||
            transform.position.x > GameManager_CS.GM.GetScreenSize().x + radious);
    }

    void OnCollisionEnter2D(Collision2D coll) {
        if(coll.transform.tag == "Player" || coll.transform.tag == "Enemy") {
            coll.gameObject.SendMessage("TakeDamage", Base.Damage);
            Destroy(this.gameObject);
        }
    }

    private void detonate() {
        Vector2 pos = new Vector2(transform.position.x, transform.position.y);
        Collider2D[] collider = Physics2D.OverlapCircleAll(pos, Base.EffectArea);
        //loops throue the array and only dameges the enemys
        foreach (Collider2D coll in collider) {
            string s = coll.tag;
            if (coll.tag == "Enemy" || coll.tag == "Player") {
                coll.gameObject.SendMessage("TakeDamage", Base.Damage);
            }
        }
    }

}
