﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Projectile", menuName = "My Objects/Projectile")]
public class Projectile : ScriptableObject {

    [Header("Projectile Veriables")]
    public float Damage;
    public bool UseEffectArea;
    public float EffectArea;
    public bool UseFuse;
    public float Fuse;
    public float Velocoty;
    [Space]
    [Header("Projectile Aperances")]
    public Sprite Sprite;
}
