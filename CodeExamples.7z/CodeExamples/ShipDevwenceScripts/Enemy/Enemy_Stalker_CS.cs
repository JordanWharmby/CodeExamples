﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Stalker_CS : MonoBehaviour {

    public Enemy Base;

    public Transform FirePoint;

    public bool CanHit;
    public bool UseHelthBar = true;
    private HelthBar_CS helthBar;

    public GameObject BaseProjectile;
    public Projectile Projectile;

    private Vector3 tempPos;

    private float buletDelta;

    private float radious;

    private Rigidbody2D rigi;

    private bool fiering = false;

    void Start() {
        Base = Instantiate(Base);
        //gess the circle radious
        radious = GetComponent<CircleCollider2D>().radius;
        rigi = GetComponent<Rigidbody2D>();
        //sets the position
        while (true) {
            transform.position = Base.SetPosition(0, radious);
            if (WaveSpawner_CS.WaveSpawner.CheckPosition(transform.position, radious)) {
                break;
            }
        }
        tempPos = transform.position;
        //sets the speed
        buletDelta = Base.FierRate;
        Base.SetHelth(Base.Helth);
        Base.IsDead = false;
        //helth bar
        if (UseHelthBar) {
            helthBar = GetComponentInChildren<HelthBar_CS>();
            helthBar.Init(Base.Helth);
        }
    }

    public void TakeDamage(float f) {
        this.Base.TakeDamage(f);
        if (UseHelthBar) {
            this.helthBar.NewHelth(Base.GetHelth());
        }
    }

    // Update is called once per frame
    void Update () {
        if (!FindObjectOfType<Player_Controler_CS>().IsDead()) {
            Vector3 newPos = FindObjectOfType<Player_Controler_CS>().transform.localPosition;
            transform.position = Vector3.MoveTowards(transform.position, newPos, Base.Speed * Time.deltaTime);
            transform.up = FindObjectOfType<Player_Controler_CS>().transform.position - transform.position;
        }

        if (Base.IsDead) {
            FindObjectOfType<Player_Controler_CS>().AddMoney(Base.MoneyDrop);
            WaveSpawner_CS.WaveSpawner.RemoveEnemy(this.gameObject);
            Destroy(this.gameObject);
        }

        if (!fiering) {
            buletDelta += Time.deltaTime;
            if (buletDelta >= Base.FierRate) {
                StartCoroutine(fireBulet());
                buletDelta = 0;
            }
        }
    }

    private IEnumerator fireBulet() {
        if (!fiering) {
            fiering = true;
            for (int i = 0; i < 3; i++) {
                yield return new WaitForSeconds(0.05f);
                GameObject p = Instantiate(BaseProjectile, FirePoint.position, transform.rotation);
                p.transform.position = FirePoint.transform.position;
                p.transform.right = FindObjectOfType<Player_Controler_CS>().transform.position - transform.position;
                p.GetComponent<Projectile_CS>().Init(Projectile);
                p.GetComponent<Projectile_CS>().SetVelocoty(true);
            }
            fiering = false;
        }
    }

}
