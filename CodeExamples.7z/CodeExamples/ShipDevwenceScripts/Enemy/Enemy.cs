﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Enemy", menuName = "My Objects/Enemy")]
public class Enemy : ScriptableObject {
    [Header("Enemy Veriables")]
    public string EnemyName;
    public float Helth;
    private float tHelth;
    private bool isDead = false;
    public float Speed;
    public float MoneyDrop;
    [Space]
    [Header("Bulet Veriables")]
    public float FierRate;

    public void TakeDamage(float f) {
        tHelth -= f;
        if (tHelth <= 0) {
            tHelth = 0;
            isDead = true;
        }
    }

    public bool IsDead {
        get { return isDead; }
        set { isDead = value; }
    }

    public void SetHelth(float f) {
        tHelth = f;
    }

    public float GetHelth() {
        return tHelth;
    }

    public Vector3 SetPosition(int i, float radious) {
        switch (i) {
            case (0):
                return new Vector3(Random.Range(-GameManager_CS.GM.GetScreenSize().x + (radious * 1.5f), GameManager_CS.GM.GetScreenSize().x - (radious * 1.5f)), GameManager_CS.GM.GetScreenSize().y + (radious * 1.5f), 0);
            case (1):
                float f = Random.Range(0, 1);
                if (f > 0.5f) {
                    return new Vector3(Random.Range(-GameManager_CS.GM.GetScreenSize().x + (radious * 1.5f), GameManager_CS.GM.GetScreenSize().x - (radious * 1.5f)), GameManager_CS.GM.GetScreenSize().y + (radious * 1.5f), 0);
                }
                else {
                    return new Vector3(Random.Range(-GameManager_CS.GM.GetScreenSize().x + (radious * 1.5f), GameManager_CS.GM.GetScreenSize().x - (radious * 1.5f)), -GameManager_CS.GM.GetScreenSize().y - (radious * 1.5f), 0);
                }
            case (2):
                bool tos;
                float x, y;
                tos = (Mathf.Round(Random.Range(1, 10)) % 2 == 0);
                //is it comming from the top or the side
                if (tos) {
                    //calcultes a x pos
                    x = Random.Range(-GameManager_CS.GM.GetScreenSize().x + radious, GameManager_CS.GM.GetScreenSize().x - (radious * 1.5f));
                    bool t = (Mathf.Round(Random.Range(1, 10)) % 2 == 0);
                    //top
                    if (t) {
                        y = GameManager_CS.GM.GetScreenSize().y + (radious * 1.5f);
                    }
                    //bottom
                    else {
                        y = -GameManager_CS.GM.GetScreenSize().y - (radious * 1.5f);
                    }
                }
                else {
                    //calcultes a y pos
                    y = Random.Range(-GameManager_CS.GM.GetScreenSize().y + radious, GameManager_CS.GM.GetScreenSize().y - (radious * 1.5f));
                    bool l = (Mathf.Round(Random.Range(1, 10)) % 2 == 0);
                    //left
                    if (l) {
                        x = -GameManager_CS.GM.GetScreenSize().x - (radious * 1.5f);
                    }
                    //right
                    else {
                        x = GameManager_CS.GM.GetScreenSize().x + (radious * 1.5f);
                    }
                }
                return new Vector3(x, y, 0);
                break;
            default:
                return Vector3.zero;
        }
    }
}
