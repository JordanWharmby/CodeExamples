﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Lancher_CS : MonoBehaviour {

    public Enemy Base;

    public Transform FirePoint;

    public bool CanHit;
    public bool UseHelthBar = true;
    private HelthBar_CS helthBar;

    public GameObject BaseProjectile;
    public Projectile Projectile;

    private Vector3 tempPos;
    private float buletDelta;
    private float radious;
    private Rigidbody2D rigi;
    private bool onScreen = false;
    private int state = 0;
    private float delay = 7;
    private float dTime = 0;

    void Start() {
        Base = Instantiate(Base);
        //gess the circle radious
        radious = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        rigi = GetComponent<Rigidbody2D>();
        //sets the position
        while (true) {
            transform.position = Base.SetPosition(1, radious);
            transform.up = new Vector3((transform.position.x * -1) * 2, (transform.position.y * -1) * 2, 0) - transform.position;
            if (WaveSpawner_CS.WaveSpawner.CheckPosition(transform.position, radious)) {
                break;
            }
        }
       
        //sets the speed
        rigi.velocity = (new Vector3((transform.position.x * -1) * 2, (transform.position.y * -1) * 2, 0) - transform.position) * (Base.Speed * Time.deltaTime);
        buletDelta = Base.FierRate;
        Base.SetHelth(Base.Helth);
        Base.IsDead = false;
        //helth bar
        if (UseHelthBar) {
            helthBar = GetComponentInChildren<HelthBar_CS>();
            helthBar.Init(Base.Helth);
        }
    }

    public void TakeDamage(float f) {
        this.Base.TakeDamage(f);
        if (UseHelthBar) {
            this.helthBar.NewHelth(Base.GetHelth());
        }
    }

    void Update() {
        switch (state) {
            case (0):
            onScreen = !isOnScreen();
            if (onScreen) {
                rigi.velocity *= 0.01f;
                state = 1;
                tempPos = transform.position; 
            }
            break;
            case (1):
            //sets the position
            transform.position = tempPos;
            //Fiers Bulit
            buletDelta += Time.deltaTime;
            if (buletDelta >= Base.FierRate) {
                FireBulet();
                buletDelta = 0;
            }
            dTime += Time.deltaTime;
            if(dTime > delay) {
                state = 2;
                dTime = 0;
                rigi.velocity = (new Vector3((transform.position.x * -1) * 2, (transform.position.y * -1) * 2, 0) - transform.position) * ((Base.Speed * 6) * Time.deltaTime);
            }
            break;
            case (2):
            if (offScreen()) {
                transform.position = Base.SetPosition(1, radious);
                transform.up = new Vector3((transform.position.x * -1) * 2, (transform.position.y * -1) * 2, 0) - transform.position;
                //sets the speed
                rigi.velocity = (new Vector3((transform.position.x * -1) * 2, (transform.position.y * -1) * 2, 0) - transform.position) * (Base.Speed * Time.deltaTime);
                state = 0;
            }
            break;
            default:
            break;
        }
        //if the enemy is dead
        if (Base.IsDead) {
            FindObjectOfType<Player_Controler_CS>().AddMoney(Base.MoneyDrop);
            WaveSpawner_CS.WaveSpawner.RemoveEnemy(this.gameObject);
            Destroy(this.gameObject);
        }
        
    }

    //if the enemy is off wcreen
    private bool isOnScreen() {
        return (transform.position.y < (-GameManager_CS.GM.GetScreenSize().y + (GameManager_CS.GM.GetScreenSize().y * 0.4f)) + (radious * 3) ||
            transform.position.y > GameManager_CS.GM.GetScreenSize().y - (radious * 3) ||
            transform.position.x < -GameManager_CS.GM.GetScreenSize().x + (radious * 3) ||
            transform.position.x > GameManager_CS.GM.GetScreenSize().x - (radious * 3));
    }

    private bool offScreen() {
        return (transform.position.y > GameManager_CS.GM.GetScreenSize().y + (radious) ||
            transform.position.y < (-GameManager_CS.GM.GetScreenSize().y + (GameManager_CS.GM.GetScreenSize().y * 0.4f)) - (radious) ||
            transform.position.x > GameManager_CS.GM.GetScreenSize().x + (radious) ||
            transform.position.x < -GameManager_CS.GM.GetScreenSize().x - (radious));
    }

    private void FireBulet() {
        GameObject p = Instantiate(BaseProjectile, FirePoint.position, transform.rotation);
        p.transform.position = FirePoint.transform.position;
        p.transform.right = new Vector3(transform.position.x + rigi.velocity.x, transform.position.y + rigi.velocity.y, 0) - transform.position;
        p.GetComponent<Projectile_CS>().Init(Projectile);
        p.GetComponent<Projectile_CS>().SetVelocoty(true);
    }
}