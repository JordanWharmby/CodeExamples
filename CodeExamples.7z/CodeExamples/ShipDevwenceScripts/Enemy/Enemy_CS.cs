﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_CS: MonoBehaviour {

    public Enemy Base;

    public Transform FirePoint;

    public bool CanHit;
    public bool UseHelthBar = true;
    private HelthBar_CS helthBar;

    public GameObject BaseProjectile;
    public Projectile Projectile;

    public GameObject MoneyIcon;

    private Vector3 tempPos;
    private float buletDelta;
    private float radious;
    private Rigidbody2D rigi;
    private bool onScreen = false;

    void Start() {
        Base = Instantiate(Base);
        //gess the circle radious
        radious = GetComponent<CircleCollider2D>().radius * transform.localScale.x;
        rigi = GetComponent<Rigidbody2D>();
        //sets the position
        while (true) {
            transform.position = Base.SetPosition(1, radious);
            transform.up = new Vector3((transform.position.x * -1) * 2, (transform.position.y * -1) * 2, 0) - transform.position;
            if (WaveSpawner_CS.WaveSpawner.CheckPosition(transform.position, radious)) {
                break;
            }
        }
        //sets the speed
        rigi.velocity = (new Vector3((transform.position.x * -1) * 2, (transform.position.y * -1) * 2, 0) - transform.position) * (Base.Speed * Time.deltaTime);
        buletDelta = Base.FierRate;
        Base.SetHelth(Base.Helth);
        Base.IsDead = false;
        //helth bar
        if (UseHelthBar) {
            helthBar = GetComponentInChildren<HelthBar_CS>();
            helthBar.Init(Base.Helth);
        }
    }

    public void TakeDamage(float f) {
        this.Base.TakeDamage(f);
        if (UseHelthBar) {
            this.helthBar.NewHelth(Base.GetHelth());
        }
    }

    void Update() {
        if (!onScreen) {
            onScreen = !offScreen();
        }
        if (Base.IsDead || (onScreen && offScreen())) {
            if (Base.IsDead) {
                GameObject g = Instantiate(MoneyIcon, transform.position, Quaternion.identity);
                g.GetComponent<MoneyIcon_CS>().SetText(Base.MoneyDrop);
                FindObjectOfType<Player_Controler_CS>().AddMoney(Base.MoneyDrop);
            }
            WaveSpawner_CS.WaveSpawner.RemoveEnemy(this.gameObject);
            Destroy(this.gameObject);
        }

        buletDelta += Time.deltaTime;
        if (buletDelta >= Base.FierRate) {
            FireBulet();
            buletDelta = 0;
        }
    }

    //if the enemy is off wcreen
    private bool offScreen() {
        return (transform.position.y < -GameManager_CS.GM.GetScreenSize().y - (radious * 3) ||
            transform.position.y > +GameManager_CS.GM.GetScreenSize().y + (radious * 3) ||
            transform.position.x < -GameManager_CS.GM.GetScreenSize().x - (radious * 3) ||
            transform.position.x > +GameManager_CS.GM.GetScreenSize().x + (radious * 3));
    }

    private void FireBulet() {
        GameObject p = Instantiate(BaseProjectile, FirePoint.position, transform.rotation);
        p.transform.position = FirePoint.transform.position;
        p.transform.right = new Vector3(transform.position.x + rigi.velocity.x, transform.position.y + rigi.velocity.y, 0) - transform.position;
        p.GetComponent<Projectile_CS>().Init(Projectile);
        p.GetComponent<Projectile_CS>().SetVelocoty(true);
    }

}
