﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Turret_Class  {

    public int Index;
    public string Name;
    public GameObject[] Prefabs;
    public float[] Cost;
    
}
