﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TurretCooldownUI_CS : MonoBehaviour {

    public Text TurretName;
    public Image CooldownBar;

    private bool flag = false;

    private Turret_CS turret;

    void Start() {
        GetComponent<Button>().onClick.AddListener(turret.ToggleFireTuret);
    }

    public void init(Turret_CS t) {
        turret = t;

        flag = true;
    }

	// Update is called once per frame
	void Update () {
        if (!flag) return;
        float f = turret.CurrentHeat / turret.MaxHeatcapacaty;
        CooldownBar.transform.localScale = new Vector3(f, 1, 1);

    }
}
