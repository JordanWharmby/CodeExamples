﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret_CS: MonoBehaviour {

    [Header("Atibutes")]
    //fier rate
    public float FireRate = 1f;
    //bulit speed
    public float BulitVelocoty;
    //Bulit power
    public float BulitPower;
    //Effect area of the bullit
    public float BulitEffectArea;
    //Heat per Bulit
    public float HeatPerBulit;
    //cooldowns
    public float CooldownRateNormal;
    public float CooldownRateSlow;
    public float MaxHeatcapacaty;
    //Turet Level
    public int TurretIndex;
    public int TurretLevel;
    public int MaxLevel;
    //privet fields
    private float bullitDelta;
    private float currentHeat = 0;
    
    private bool coolingDown;

    private bool fireTurret = true;
    
    [Header("Unity Fields")]
    //position to fier bulets from
    public Transform FirePoint;
    //bulet prefab
    public GameObject BaseProjectile;
    public Projectile Projectile;

    public GameObject TurretUI;

    public GameObject Exsplosion;

    private float fireCountDown = 0f;

    private Vector2 mousePos;
    private Vector3 screenPos;
    // Use this for initialization
    void Start() {
        bullitDelta = FireRate;
        if (!BuldManager_CS.instance.BuldMode) {
            Transform tr = GameObject.Find("TurretConstraint").transform;
            GameObject t = Instantiate(TurretUI, tr);
            t.GetComponent<TurretCooldownUI_CS>().init(this);
        }
    }

    public void ToggleFireTuret() {
        fireTurret = !fireTurret;
    }

    void Update() {
        Vector3 pos = Camera.main.WorldToScreenPoint(transform.position);
        Vector3 dir = Input.mousePosition - pos;
        float angle = Mathf.Atan2(dir.y, dir.x) * Mathf.Rad2Deg;
        transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        if (!GameManager_CS.GM.InGame) return;

        if (Input.GetButton("Fire1") && !coolingDown && fireTurret) {
            bullitDelta += Time.deltaTime;
            //if the player can fire
            if (bullitDelta >= FireRate) {
                Fire();
                bullitDelta = 0;
            }
        }
        else {
            coolDown();
        }
    }

    private void coolDown() {
        if (coolingDown) {
            currentHeat -= CooldownRateSlow;
            if (currentHeat <= 0) {
                currentHeat = 0;
                coolingDown = false;
            }
        }
        else {
            currentHeat -= CooldownRateNormal;
            if (currentHeat <= 0) {
                currentHeat = 0;
            }
        }
    }

    public float CurrentHeat {
        get { return currentHeat; }
    }

    private void Fire() {
        GameObject p = Instantiate(BaseProjectile, FirePoint.position, transform.rotation);
        p.transform.position = FirePoint.transform.position;
        p.transform.rotation = transform.rotation;
        p.GetComponent<Projectile_CS>().Init(Projectile);
        p.GetComponent<Projectile_CS>().SetVelocoty(true);
        currentHeat += HeatPerBulit;
        if (currentHeat > MaxHeatcapacaty) {
            currentHeat = MaxHeatcapacaty;
            coolingDown = true;

        }
    }

    public void DestroyTurret() {
        Instantiate(Exsplosion, transform.position, Quaternion.identity);
        gameObject.SetActive(false);
    }

}
