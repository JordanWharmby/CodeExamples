﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TurretTab_CS : MonoBehaviour {

    public Text Name;
    public Image TurretImage;

    public int Index;
    
    public void SetTurretToBuld() {
        BuldManager_CS.instance.SetTurretToBuld(Index, 0, false);
        FindObjectOfType<ShopManager_CS>().SetButton(0);
        FindObjectOfType<ShopManager_CS>().SetPage(2);
    }

}
