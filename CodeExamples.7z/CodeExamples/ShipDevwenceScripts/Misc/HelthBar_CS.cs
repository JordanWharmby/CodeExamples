﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HelthBar_CS : MonoBehaviour {

    public Image HelthBar;

    private float maxHelth, currentHelth;
    private bool barOnShow = false;
    
    public void Init(float helth) {
        maxHelth = helth;
        currentHelth = helth;
        setBarLendth();
    }

    public void NewHelth(float f) {
        currentHelth = f;
        setBarLendth();
    }

    private void setBarLendth() {
        //calculates the size of the helthbat
        float f = currentHelth / maxHelth;
        //restrains the length
        if(f < 0) {
            f = 0;
        }
        //sets the bar length
        HelthBar.transform.localScale = new Vector3(1, f, 1);
    }
}
