﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ShopManager_CS : MonoBehaviour {
    [Header("Pages")]
    public GameObject[] Pages;
    [Space]
    public ButtonSwitch_CS ButtonSwitch;
    [Header("Stats Text")]
    public Text HelthText;
    public Text ArmorText;
    public Text SpeedText;

    public void SetButton(int i) {
        ButtonSwitch.SetVisibleButton(i);
    }

    public void SetUpgradeButton(bool b) {
        ButtonSwitch.CanUpgrade(b);
    }

    // Use this for initialization
    void Start () {
        GameManager_CS.GM.InGame = false;
        BuldManager_CS.instance.BuldMode = true;
        BuldManager_CS.instance.CreatPlayer();
        BuldManager_CS.instance.SetBulding(true);
        SetStatsText();
        SetPage(0);
    }
    
    public void SetPage(int p) {
        for (int i = 0; i < Pages.Length; i++) {
            Pages[i].SetActive(i == p);
        }
    }

    public void SaveChanges() {
        //gets the nodes on the ship and the save data
        Node_CS[] n = FindObjectOfType<Player_Controler_CS>().BuldNodes;
        PlayerData data = GameManager_CS.GM.GetData();
        //gets the data that is saved
        int[] ti = data.TurretIndex;
        int[] tl = data.TurretLevel;
        //changes the data
        for (int i = 0; i < n.Length; i++) {
            if (n[i].currentTuret != null) {
                ti[i] = n[i].currentTuret.GetComponent<Turret_CS>().TurretIndex;
                tl[i] = n[i].currentTuret.GetComponent<Turret_CS>().TurretLevel;
            }
            else {
                ti[i] = -1;
                tl[i] = 0;
            }
        }
        //sets the data
        data.TurretIndex = ti;
        data.TurretLevel = tl;
        //saves the data
        GameManager_CS.GM.SaveData(data);
    }
    
    //loads the main menu
    public void BackToMainMenu() {
        SceneManager.LoadScene(0);
    }

    public void SetStatsText() {
        PlayerData pd = GameManager_CS.GM.GetData();
        //sets the text
        HelthText.text = "Helth: " + pd.GetHelth();
        ArmorText.text = "Armor: " + pd.GetHelth();
        SpeedText.text = "Speed: " + pd.GetSpeed();
}

}
