﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Round_Class {
    
    public enum Round {
        Normal,
        Random,
        Supply,
        Boss
    }

    public Round RoundType;

    public int EnemysToSpawn;

    public List<int> EnemyToSpawn = new List<int>();
    [Space]

    public float RoundDelay;

}
