﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ValyeBar_CS : MonoBehaviour {

    public GameObject Bar;
    public GameObject SecondBar;
    public float Value;
    public float SecondValue;
    public float MaxValue;
	
    public void SetBarValue(float f) {
        //taxes in the value
        Value = f;
        //constrains the value
        if(f > MaxValue) {
            f = MaxValue;
        }
        //gest the percent
        float val = f / MaxValue;
        //changes the value of the bar
        Bar.transform.localScale = new Vector3(val, 1, 1);
        SecondBar.transform.localScale = new Vector3(0, 1, 1);
    }

    public void SetBarValue(float f, float ft) {
        //taxes in the value
        Value = f;
        SecondValue = ft;
        //constrains the value
        if (f > MaxValue) {
            f = MaxValue;
        }
        if (ft > MaxValue) {
            ft = MaxValue;
        }
        //gest the percent
        float val = f / MaxValue;
        float valt = ft / MaxValue;
        //changes the value of the bar
        Bar.transform.localScale = new Vector3(val, 1, 1);
        SecondBar.transform.localScale = new Vector3(valt, 1, 1);
    }

}
