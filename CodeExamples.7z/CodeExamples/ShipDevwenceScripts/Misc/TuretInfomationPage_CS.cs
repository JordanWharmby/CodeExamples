﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TuretInfomationPage_CS : MonoBehaviour {

    public Text TurretName;
    public Text Price;
    public ValyeBar_CS[] Bars;
    
    public void SetBarLengths(Turret_CS t, float f) {
        //sets bar length
        Bars[0].SetBarValue(t.BulitPower);
        Bars[1].SetBarValue(t.FireRate);
        Bars[2].SetBarValue(t.CooldownRateNormal);
        Bars[3].SetBarValue(t.MaxHeatcapacaty);
        //sets price tag
        Price.text = "Price: " + f.ToString();
    }

    public void SetBarLengths(Turret_CS t0, Turret_CS tt, float f) {
        //sets bar length
        Bars[0].SetBarValue(t0.BulitPower, tt.BulitPower);
        Bars[1].SetBarValue(t0.FireRate, tt.FireRate);
        Bars[2].SetBarValue(t0.CooldownRateNormal, tt.CooldownRateNormal);
        Bars[3].SetBarValue(t0.MaxHeatcapacaty, tt.MaxHeatcapacaty);
        //sets price tag
        Price.text = "Price: " + f.ToString();
    }

}
