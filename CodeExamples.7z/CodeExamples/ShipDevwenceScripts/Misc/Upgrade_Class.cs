﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Upgrade_Class {
    private int currentLevel, maxLevel;
    private int upgradeValue;
    public float baseValue;

    public Upgrade_Class(int i, int j, int k, float l) {
        currentLevel = i;
        maxLevel = j;
        upgradeValue = k;
        baseValue = k;
    }

    public bool IsAtMax() {
        return currentLevel < maxLevel;
    }

    public int CurrentLevel {
        get { return currentLevel; }
        set { currentLevel = value; }
    }

    public int MaxLevel {
        get { return maxLevel; }
        set { maxLevel = value; }
    }

    public int UpgradeValue {
        get { return upgradeValue; }
        set { upgradeValue = value; }
    }

}
