﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class WaveSpawner_CS : MonoBehaviour {

    public static WaveSpawner_CS WaveSpawner;
    [Header("Rounds")]
    public List<Round_Class> Rounds;
    [Space]
    [Header("List of Entitys")]
    public GameObject[] Enemys;
    public GameObject[] Bosses;
    public GameObject[] Supplys;
    [Space]
    public ParticleSystem EndGameEffect;

    //list of the enemys in the game
    private List<GameObject> enemysInGame = new List<GameObject>();
    private int roundNumber = 0;
    //tracks time betwean the rounds
    private float spawnDelta = 0;
    private bool roundsCompleted = false;

    //positions and radius of enemys
    private List<Vector2> possitions = new List<Vector2>();
    private List<float> radius = new List<float>();

    private bool end = false;

    void Awake() {
        WaveSpawner = this;
        BuldManager_CS.instance.BuldMode = false;
        BuldManager_CS.instance.Bulding = false;
        BuldManager_CS.instance.CreatPlayer();
        GameManager_CS.GM.InGame = true;
    }

	void Update () {
        //if the round is over and there is another one
        if (enemysInGame.Count <= 0 && roundNumber < Rounds.Count) {
            //increases the time
            spawnDelta += Time.deltaTime;
            //if it is time to spwan in the next wave
            if (spawnDelta >= Rounds[roundNumber].RoundDelay) {
                switch (Rounds[roundNumber].RoundType) {
                    //normal wave
                    case (Round_Class.Round.Normal):
                        SpawnEntitys(Enemys);
                        spawnDelta = 0;
                        roundNumber++;
                        break;
                    //supply round
                    case (Round_Class.Round.Supply):
                        SpawnEntitys(Supplys);
                        spawnDelta = 0;
                        roundNumber++;
                        break;
                    //Random
                    case (Round_Class.Round.Random):
                        RandomEnemys();
                        spawnDelta = 0;
                        roundNumber++;
                        break;
                    //boss wave
                    case (Round_Class.Round.Boss):
                        break;
                    default:
                        break;
                }

            }
        }
        //if there are no more rounds
        else if (enemysInGame.Count <= 0 && roundNumber >= Rounds.Count && !FindObjectOfType<Player_Controler_CS>().IsDead()) {
            if (!roundsCompleted) {
                roundsCompleted = true;
                FindObjectOfType<Player_Controler_CS>().DisableColision();
                StartCoroutine(endGame());
            }
        }
    }

    //Removes an enemy from the list
    public void RemoveEnemy(GameObject g) {
        //if the enemys in the list
        //remove it 
        if (enemysInGame.Contains(g)) {
            enemysInGame.Remove(g);
        }
    }

    private void RandomEnemys() {
        //clears the list
        ClearPositionList();
        //spwans enemys
        for (int i = 0; i < Rounds[roundNumber].EnemysToSpawn; i++) {
            //Selects an enemy at random
            int randomNum = Mathf.RoundToInt(Random.Range(0, Enemys.Length));
            GameObject g = Instantiate(Enemys[randomNum]);
            //adds the enemy to the list
            enemysInGame.Add(g);
        }
    }

    //spawns enemys
    private void SpawnEntitys(GameObject[] list) {
        //clears the current enemy list
        ClearPositionList();
        //loops through the enemys to spawn
        for (int i = 0;  i < Rounds[roundNumber].EnemyToSpawn.Count; i++) {
            //spawns the enemy
            int j = Rounds[roundNumber].EnemyToSpawn[i];
            //clamps the value
            j = Mathf.Clamp(j, 0, list.Length);
            //spawns the object
            GameObject g = Instantiate(list[j]);
            //adds the enemy to the list
            enemysInGame.Add(g);
        }
        
    }

    //Hides all of the enemys currentl still in the game
    public void HideEnemys() {
        foreach (GameObject g in enemysInGame) {
            g.SetActive(false);
        }
        //removes all of the bulets
        GameObject[] bull = GameObject.FindGameObjectsWithTag("Bulit");
        foreach (GameObject g in bull) {
            g.SetActive(false);
        }
    }

    public void ClearPositionList() {
        possitions.Clear();
        radius.Clear();
    }

    public bool CheckPosition(Vector2 v, float r) {
        //loops throu the list
        for (int i = 0; i < possitions.Count; i++) {
            if(Vector2.Distance(possitions[i],v) < radius[i] + r) {
                return false;
            }
        }
        possitions.Add(v);
        radius.Add(r);
        return true;
    }

    private IEnumerator endGame() {
        if (!end) {
            end = true;
            Vector3 pos;
            //spawns effects
            pos = new Vector3(GameManager_CS.GM.GetScreenSize().x / 2, GameManager_CS.GM.GetScreenSize().y / 2, 0);
            Instantiate(EndGameEffect, pos, Quaternion.identity);
            pos = new Vector3(-GameManager_CS.GM.GetScreenSize().x / 2, GameManager_CS.GM.GetScreenSize().y / 2, 0);
            Instantiate(EndGameEffect, pos, Quaternion.identity);
            pos = new Vector3(-GameManager_CS.GM.GetScreenSize().x / 2, (-GameManager_CS.GM.GetScreenSize().y + (GameManager_CS.GM.GetScreenSize().y * 0.8f)) / 2, 0);
            Instantiate(EndGameEffect, pos, Quaternion.identity);
            pos = new Vector3(GameManager_CS.GM.GetScreenSize().x / 2, (-GameManager_CS.GM.GetScreenSize().y + (GameManager_CS.GM.GetScreenSize().y * 0.8f)) / 2, 0);
            Instantiate(EndGameEffect, pos, Quaternion.identity);
            //waits
            yield return new WaitForSeconds(5);
            //sets money
            PlayerData data = GameManager_CS.GM.GetData();
            data.Money = (int)FindObjectOfType<Player_Controler_CS>().GetMoney();
            GameManager_CS.GM.SaveData(data);
            //changes the sceen
            SceneManager.LoadScene(2);
        }
        
    }

}
