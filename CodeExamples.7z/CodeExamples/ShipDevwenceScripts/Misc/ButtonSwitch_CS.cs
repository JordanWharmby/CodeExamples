﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonSwitch_CS : MonoBehaviour {

    public GameObject[] Buttons;
	
    public void CanUpgrade(bool b) {
        if (b) {
            Buttons[1].GetComponent<Button>().interactable = b;
            Buttons[1].GetComponentInChildren<Text>().text = "Upgrade";
        }
        else {
            Buttons[1].GetComponent<Button>().interactable = b;
            Buttons[1].GetComponentInChildren<Text>().text = "No Upgrade";
        }
    }

    public void SetVisibleButton(int b) {
        for (int i = 0; i < Buttons.Length; i++) {
            Buttons[i].SetActive(i == b);
        }
    }

}
