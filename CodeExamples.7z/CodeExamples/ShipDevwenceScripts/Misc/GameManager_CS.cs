﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class GameManager_CS: MonoBehaviour {

    public static GameManager_CS GM;

    private Vector3 ScreenSize;

    private bool inGame = true;

    private int currentSave = 0;
    // Use this for initialization
    void Awake() {
        if(GM == null) {
            GM = this;
        }
        else if(GM != this) {
            Destroy(this);
        }
        DontDestroyOnLoad(this);
        ScreenSize = Camera.main.ScreenToWorldPoint(new Vector3(Screen.width, Screen.height * 0.8f, 0));
        createSaveData();
    }

    public int CurrentSave {
        get { return currentSave; }
        set { currentSave = value; }
    }

    public bool InGame {
        get { return inGame; }
        set { inGame = value; }
    }

    public Vector3 GetScreenSize() { return ScreenSize; }

    //creats the save data
    void createSaveData() {
        PlayerData data;
        BinaryFormatter bf = new BinaryFormatter();
        for (int i = 0; i < 4; i++) {
            if (!File.Exists(Application.persistentDataPath + "/PlayerSaveData" + i + ".dat")) {
                FileStream file = File.Create(Application.persistentDataPath + "/PlayerSaveData" + i + ".dat");
                data = new PlayerData();
                data.init(0);
                bf.Serialize(file, data);
                file.Close();
            }
           
        }
    }

    public PlayerData GetData() {
        PlayerData data;
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Open(Application.persistentDataPath + "/PlayerSaveData" + currentSave + ".dat", FileMode.Open);
        data = (PlayerData)bf.Deserialize(file);
        file.Close();
        return data;
    }

    public void SaveData(PlayerData pd) {
        File.Delete(Application.persistentDataPath + "/PlayerSaveData" + currentSave + ".dat");
        BinaryFormatter bf = new BinaryFormatter();
        FileStream file = File.Create(Application.persistentDataPath + "/PlayerSaveData" + currentSave + ".dat");
        PlayerData data = pd;
        bf.Serialize(file, data);
        file.Close();
    }

}

[Serializable]
public class PlayerData {

    bool fileInUse;
    //turet veribles
    private int shipIndex;
    private int numberOfTurrets;
    private int[] turretIndex;
    private int[] turretLevel;

    //ship Veriables
    private float helth;
    private float speed;

    private List<Upgrade_Class> upgrdeValues = new List<Upgrade_Class>();

    private int money;

    public void init(int ShipIndex) {
        //sets the file to not be in use
        fileInUse = false;
        //sets the ship index
        shipIndex = ShipIndex;
        //gets the infomation about the number of turets
        TurretInfomation TI = new TurretInfomation();
        TI.init();
        //gets the amount of turrets for the ship
        numberOfTurrets = TI.GetAmountOfTurrets(shipIndex);
        //sets the data for the int arrays
        turretIndex = new int[numberOfTurrets];
        turretLevel = new int[numberOfTurrets];
        //turret data
        money = 250;
        setTurretData();
        //ship upgrade values
        UpgradeInfomation UI = new UpgradeInfomation();
        UI.init();
        upgrdeValues = UI.GetUpgradeBase(shipIndex);
        helth = upgrdeValues[0].baseValue;
        speed = upgrdeValues[1].baseValue;
    }

    private void setTurretData() {
        //sets the default data
        for (int i = 0; i < numberOfTurrets; i++) {
            turretIndex[i] = -1;
            turretLevel[i] = 0;
        }
        turretIndex[turretIndex.Length / 2] = 0;
    }
    
    public int Money {
        get { return money; }
        set { money = value; }
    }

    //the index of the ship
    public int ShipIndex {
        get { return shipIndex; }
        set { shipIndex = value; }
    }

    public int NumberOfTurrets {
        get { return numberOfTurrets; }
        set { numberOfTurrets = value; }
    }

    //iuf the file is in use
    public bool FileInUse {
        get { return fileInUse; }
        set { fileInUse = value; }
    }

    public int[] TurretIndex {
        get { return turretIndex; }
        set { turretIndex = value; }
    }

    public int[] TurretLevel {
        get { return turretLevel; }
        set { turretLevel = value; }
    }

    //sets infomation about one of the turets
    public void SetCurrentTuret(int i, int j) {
        turretIndex[i] = j;
    }

    //Gets infomation about one of the turets
    public int GetCurrentTurret(int i) {
        return turretIndex[i];
    }
    //Sets infomation about one of the turets
    public void SetCurrentTuretLevel(int i, int j) {
        turretLevel[i] = j;
    }

    //Gets infomation about one of the turets
    public int GetCurrentTurretLevel(int i) {
        return turretLevel[i];
    }

    public float GetHelth() {
        return helth;
    }

    public float GetSpeed() {
        return speed;
    }

    public Upgrade_Class GetUpgradeClass(int i) {
        return upgrdeValues[i];
    }

}

class UpgradeInfomation {
    //helth
    List<Upgrade_Class> helthUpgrades = new List<Upgrade_Class>();
    //speed
    List<Upgrade_Class> speedUpgrades = new List<Upgrade_Class>();

    public void init() {
        //helth
        helthUpgrades.Add(new Upgrade_Class(0, 10, 10, 100));
        helthUpgrades.Add(new Upgrade_Class(0, 10, 10, 100));
        helthUpgrades.Add(new Upgrade_Class(0, 10, 10, 100));
        helthUpgrades.Add(new Upgrade_Class(0, 10, 10, 100));
        //speed
        speedUpgrades.Add(new Upgrade_Class(0, 5, 2, 10));
        speedUpgrades.Add(new Upgrade_Class(0, 5, 2, 10));
        speedUpgrades.Add(new Upgrade_Class(0, 5, 2, 10));
        speedUpgrades.Add(new Upgrade_Class(0, 5, 2, 10));
    }

    //returns a list of the upgrades related to the ship
    public List<Upgrade_Class> GetUpgradeBase(int i) {
        //creates a temp list
        List<Upgrade_Class> tList = new List<Upgrade_Class>();
        //gets the upgrade class list related to the ship
        tList.Add(helthUpgrades[i]);
        tList.Add(speedUpgrades[i]);
        //returns the list
        return tList;
    }

}

class TurretInfomation {
    //amount of turets
    List<int> amountOfTurrets = new List<int>();

    public void init() {
        //Turrets
        amountOfTurrets.Add(3);
        amountOfTurrets.Add(3);
        amountOfTurrets.Add(3);
        amountOfTurrets.Add(3);
    }

    public int GetAmountOfTurrets(int i) {
        return amountOfTurrets[i];
    }

}