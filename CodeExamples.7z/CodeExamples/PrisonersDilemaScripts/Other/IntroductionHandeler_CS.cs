﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class IntroductionHandeler_CS : MonoBehaviour {

    public Image introImage;

    private float opacity = 0;
    private float time = 0;
    private float delay = 1f;

	// Use this for initialization
	void Start () {
        introImage.color = new Color(225, 225, 225, opacity);
	}

    void Update() {
        time += Time.deltaTime;
        if (time > delay && opacity <= 1) {
            opacity += 0.01f;
            opacity = Mathf.Clamp(opacity, 0, 1.1f);
            introImage.color = new Color(225, 225, 225, opacity);
            delay = 0;
            if (opacity >= 1) {
                opacity++;
                GetComponent<AudioSource>().Play();
            }
        }
        else if (time > 6 && time < 6.1) {
            introImage.color = new Color(225, 225, 225, 0);
        }
        else if (time > 7) {
            SceneManager.LoadScene("MainMenu");
        }
    }
}
