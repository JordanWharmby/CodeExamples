﻿using UnityEngine;
using System.Collections;

public class ArtificialInteligencePersonalityHandeler_CS : MonoBehaviour {

    private bool[] useCustomAI = new bool[4];

    private bool[] aiIsRandom = new bool[4];
    private bool[] aiIsFerm = new bool[4];
    private bool[] aiReset = new bool[4];

    private int[] aiOneStats = new int[4];
    private int[] aiTwoStats = new int[4];
    private int[] aiThreeStats = new int[4];
    private int[] aiFourStats = new int[4];

    // Use this for initialization
    void Start () {
        for (int i = 0; i < 4; i++) {
            aiIsRandom[i] = false;
            useCustomAI[i] = false;
            aiIsFerm[i] = false;
            aiOneStats[i] = 0;
            aiTwoStats[i] = 0;
            aiThreeStats[i] = 0;
            aiFourStats[i] = 0;
        }
	}

    public void SetPlayerStats(int player, int i, int j, int k, int l, bool random, bool ferm, bool reset, bool custom) {

        aiIsRandom[player] = random;
        aiIsFerm[player] = ferm;
        aiReset[player] = reset;
        useCustomAI[player] = custom;

        if (player == 0) {
            aiOneStats[0] = i;
            aiOneStats[1] = j;
            aiOneStats[2] = k;
            aiOneStats[3] = l;
        }
        else if (player == 1) {
            aiTwoStats[0] = i;
            aiTwoStats[1] = j;
            aiTwoStats[2] = k;
            aiTwoStats[3] = l;
        }
        else if (player == 2) {
            aiThreeStats[0] = i;
            aiThreeStats[1] = j;
            aiThreeStats[2] = k;
            aiThreeStats[3] = l;
        }
        else if (player == 3) {
            aiFourStats[0] = i;
            aiFourStats[1] = j;
            aiFourStats[2] = k;
            aiFourStats[3] = l;
        }
    }

    public int[] GetStats(int i) {
        if(i == 0) {
            return aiOneStats;
        }
        else if (i == 1) {
            return aiTwoStats;
        }
        else if (i == 2) {
            return aiThreeStats;
        }
        else if (i == 3) {
            return aiFourStats;
        }
        return null;
    }

    public bool GetIsCustom(int i) {
        return useCustomAI[i];
    }
    public bool GetAIISRandom(int i) {
        return aiIsRandom[i];
    }
    public bool GetAIISFerm(int i) {
        return aiIsFerm[i];
    }
    public bool GetAIIReset(int i) {
        return aiReset[i];
    }
}
