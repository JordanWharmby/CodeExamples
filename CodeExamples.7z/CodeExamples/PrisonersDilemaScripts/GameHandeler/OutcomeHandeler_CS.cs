﻿using System.Collections;
using UnityEngine;

public class OutcomeHandeler_CS : MonoBehaviour {

    private bool outcomeHasBeenCalled;
    
    private ApplicationManager AM;
    private GameHandeler_CS GH;

    private float delay;
    
	// Use this for initialization
	void Start () {
        outcomeHasBeenCalled = false;
        GH = GetComponent<GameHandeler_CS>();
        AM = FindObjectOfType<ApplicationManager>();
    }

    void FixedUpdate() {
        if (outcomeHasBeenCalled && AM.GetCurrentState() == 2) {
            delay += Time.deltaTime;
            if(delay > 4) {
                ResetGame(GH.GetPlayers());
                outcomeHasBeenCalled = false;
                delay = 0;
            }
        }
    }

    

    //sets the amount of coins that the player can get
    private int SetCoinOutcome(string s) {
        char chioce = s[0];
        string[] split = s.Split('-');
        char[] others = split[0].ToCharArray();
        char[] dec = split[1].ToCharArray();
        //if the player shaires
        if (chioce == '0') {
            int temp = 0;
            int defended = 0;
            int shared = 1;
            //checks the other players decisions
            for (int i = 1; i < others.Length; i++) {
                if (others[i] == '1') {
                    if(dec[0] == 't') {
                        return 0;
                    }
                    else {
                        for (int j = 1; j < others.Length; j++) {
                            if (others[j] == '0' && dec[j] != 't') {
                                shared++;
                            }
                            else if(others[j] == '2') {
                                defended++;
                            }
                        }
                        if(defended > 0) {
                            return GH.GetCoinsOnOffer() / (10 * shared);
                        }
                        else {
                            return 0;
                        }
                    }
                }
                else if (others[i] == '2') {
                    temp++;
                }
            }
            if (temp == 0 && s.Length > 2) {
                return GH.GetCoinsOnOffer() / others.Length;
            }
            else {
                return GH.GetCoinsOnOffer() / (others.Length - temp);
            }
        }
        //if the player steel
        else if (chioce == '1') {
            for (int i = 1; i < others.Length; i++) {
                if (others[i] != '0') {
                    return 0;
                }
            }
            return GH.GetCoinsOnOffer();
        }
        //if the player defend
        else if (chioce == '2') {
            int tempSteel = 0;
            int tempDefend = 1;
            int tempShare = 0;
            int toShare = 0;
            for (int i = 1; i < others.Length; i++) {
                if (others[i] == '1') {
                    tempSteel++;
                }
                else if(others[i] == '2') {
                    tempDefend++;
                }
                else {
                    tempShare++;
                }
            }
            if(tempSteel <= 0 && tempShare > 0) {
                return 0;
            }
            else if(tempShare < 1 && tempSteel < 1) {
                print(GH.GetCoinsOnOffer() / tempDefend);
                return GH.GetCoinsOnOffer() / tempDefend;
            }
            else if(tempSteel + tempDefend != GH.numberOfPlayersStillIn()) {
                for (int i = 1; i < others.Length; i++) {
                    if(others[i] == '0' && dec[i] != 't') {
                        toShare++;
                    }
                    
                }
                if(toShare == 0) {
                    return GH.GetCoinsOnOffer() / tempDefend;
                }
                else {
                    return ((GH.GetCoinsOnOffer() / tempDefend) - (GH.GetCoinsOnOffer() / (toShare * 10) * toShare));
                }
            }
            else {
                return GH.GetCoinsOnOffer() / tempDefend;
            }
        }
        return 0;
    }

    public void SetPlayerOutcome(ArrayList players) {
        if (!outcomeHasBeenCalled && AM.GetCurrentState() == 2) {
            foreach (GameObject g in players) {
                string Outcome;
                string hasStolen = "";
                int playerNum = 0;
                if ((g.GetComponent<PlayerHandeler_CS>().GetPlayerStillIn())) {
                    Outcome = g.GetComponent<PlayerHandeler_CS>().GetPlayerChoice().ToString();
                    if (g.GetComponent<PlayerHandeler_CS>().GetPlayerHasStolen()) {
                        hasStolen += "t";
                    }
                    else {
                        hasStolen += "f";
                    }
                    foreach (GameObject gt in players) {
                        if ((g.GetComponent<PlayerHandeler_CS>().GetPlayerNumber() != gt.GetComponent<PlayerHandeler_CS>().GetPlayerNumber()) && gt.GetComponent<PlayerHandeler_CS>().GetPlayerChoice() != -1) {
                            Outcome += gt.GetComponent<PlayerHandeler_CS>().GetPlayerChoice().ToString();
                            if (gt.GetComponent<PlayerHandeler_CS>().GetPlayerHasStolen()) {
                                hasStolen += "t";
                            }
                            else {
                                hasStolen += "f";
                            }
                        }
                    }
                    int currentCoins = g.GetComponent<PlayerHandeler_CS>().GetCoins();
                    Outcome += "-" + hasStolen;
                    g.GetComponent<ArtificialInteligence_CS>().SetAltruisum(currentCoins < g.GetComponent<PlayerHandeler_CS>().GetCoins());
                    g.GetComponent<ArtificialInteligence_CS>().SetForgivness(currentCoins < g.GetComponent<PlayerHandeler_CS>().GetCoins());
                    g.GetComponent<PlayerHandeler_CS>().AddCoins(SetCoinOutcome(Outcome));
                    g.GetComponent<PlayerHandeler_CS>().SetCoinPouchAnimation("IsFilling", currentCoins < g.GetComponent<PlayerHandeler_CS>().GetCoins());
                    g.GetComponent<PlayerHandeler_CS>().SetSpriteAnimation("IsAngery", currentCoins >= g.GetComponent<PlayerHandeler_CS>().GetCoins());
                    playerNum++;
                    if(AM.GetUseMaxCoins() && g.GetComponent<PlayerHandeler_CS>().GetCoins() >= AM.GetMaxCoins()){
                        GH.SetPlayerHasRechedMax(true);
                    }
                }
            }
        }
        
        outcomeHasBeenCalled = true;
    }

    public void ResetGame(ArrayList players) {
        foreach (GameObject g in players) {
            if (g.GetComponent<PlayerHandeler_CS>().GetCoins() == 0) {
                g.GetComponent<PlayerHandeler_CS>().SetPlayerStillIn(false);
                g.SetActive(false);
            }
        }
        print("GH: " + GH.GetRound() + " AM: " + AM.GetRounds());
        if (GH.numberOfPlayersStillIn() > 1 && GH.GetRound() != AM.GetRounds() && !GH.GetPlayerHasRechedMax()) {
            GH.IncrimentRound();
            GH.ResetRound();
        }
        else {
            foreach (GameObject g in players) {
                g.SetActive(false);
            }
            AM.SetCurrentState(3);
        }
    }

    IEnumerator GameOutcome(ArrayList players) {
        yield return new WaitForSeconds(4);
    }

    public void SetOutcomeFlag(bool b) { outcomeHasBeenCalled = b; }
    public bool GetOutcomeHasBeenCalled() { return outcomeHasBeenCalled; }

}
