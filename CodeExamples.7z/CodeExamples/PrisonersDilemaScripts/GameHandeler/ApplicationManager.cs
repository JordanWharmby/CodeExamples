﻿using UnityEngine;
using System.Collections;
using System;

public class ApplicationManager : MonoBehaviour {

    private ArtificialInteligencePersonalityHandeler_CS AIPH;

    private short numberOfPlayers;

    public bool[] PlayerIsAI;

    private short curtentState;
    /*
     * -1 = main menu
     * 0 = tutorial
     * 1 = betting
     * 2 = playing
     * 3 = leaderboard
     */
    [SerializeField]
    private string[] plauerKeysChar_One;
    [SerializeField]
    private string[] plauerKeysChar_Two;
    [SerializeField]
    private string[] plauerKeysChar_Three;
    [SerializeField]
    private string[] plauerKeysChar_Four;

    public GameObject[] PlayerKeyBindings;

    private KeyCode[] playerKeys_One;
    private KeyCode[] playerKeys_Two;
    private KeyCode[] playerKeys_Three;
    private KeyCode[] playerKeys_Four;

    public GameObject[] PlayerSprites;

    public Sprite[] PlayerSpriteImage;

    public int[] PlayerSpriteNumber;

    private int numberOfRounds;
    private int numberOfCoins;
    private int numberOfCards;

    private bool enableBetting;

    private bool useMaxCoins;
    private int maxCoins;

    private int minimumBet;

    // Use this for initialization
    void Start () {
        AIPH = GetComponent<ArtificialInteligencePersonalityHandeler_CS>();

        DontDestroyOnLoad(this);
        curtentState = -1;
        playerKeys_One = new KeyCode[3];
        playerKeys_Two = new KeyCode[3];
        playerKeys_Three = new KeyCode[3];
        playerKeys_Four = new KeyCode[3];

        PlayerIsAI = new bool[4];

        PlayerSpriteNumber = new int[4];

        for (int i = 0; i < 4; i++) {
            PlayerIsAI[i] = false;
            PlayerSpriteNumber[i] = i;
        }

        enableBetting = false;

        numberOfRounds = 0;
        numberOfCoins = 0;
        numberOfCards = 0;

        SetNewKeys(playerKeys_One, plauerKeysChar_One);
        SetNewKeys(playerKeys_Two, plauerKeysChar_Two);
        SetNewKeys(playerKeys_Three, plauerKeysChar_Three);
        SetNewKeys(playerKeys_Four, plauerKeysChar_Four);
    }
	
    public int GetMinnBet() {
        return minimumBet;
    }

    public void SetMinBet(int i) {
        minimumBet = i;
    }

    public bool GetUseMaxCoins() {
        return useMaxCoins;
    }

    public void SetUseMaxCoins(bool b) {
        useMaxCoins = b;
    }

    public int GetMaxCoins() {
        return maxCoins;
    }

    public void SetMaxCoins(int i) {
        maxCoins = i;
    }

    public int GetRounds() {
        return numberOfRounds;
    }
    public void SetRounds(int i) {
        numberOfRounds = i;
    }

    public int GetCoins() {
        return numberOfCoins;
    }
    public void SetCoins(int i) {
        numberOfCoins = i;
    }

    public int GetCards() {
        return numberOfCards;
    }
    public void SetCards(int i) {
        numberOfCards = i;
    }

    public short GetNumberOfPlayers() {
        return numberOfPlayers;
    }

    public void SetNumberOfPlayers(short s) {
        numberOfPlayers = s;
    }

    public short GetCurrentState() {
        return curtentState;
    }

    public void SetCurrentState(short s) {
        curtentState = s;
    }

    public bool GetCanBet() {
        return enableBetting;
    }
    public void SetCanBet(bool b) {
        enableBetting = b;
    }

    private void SetNewKeys(KeyCode[] keys, string[] newKeys) {
        for(int i = 0; i < keys.Length; i++) {
            keys[i] = (KeyCode)System.Enum.Parse(typeof(KeyCode), newKeys[i]);
        }
    }

    //Returns the keys of any player
    public KeyCode[] GetPlayersKeys(int i) {
        if(i == 0) {
            return playerKeys_One;
        }
        else if (i == 1) {
            return playerKeys_Two;
        }
        else if (i == 2) {
            return playerKeys_Three;
        }
        else {
            return playerKeys_Four;
        }
    }

    

    internal void RestartTheGame() {
        throw new NotImplementedException();
    }
}
