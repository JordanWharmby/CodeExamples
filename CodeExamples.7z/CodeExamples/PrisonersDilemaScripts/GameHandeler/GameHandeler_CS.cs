﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class GameHandeler_CS : MonoBehaviour {

    //positions of the players
    public Transform[] PlayerPositions;
    //UI items
    public GameObject[] MainUserInterface;
    //positions of the crad centers
    public Vector3[] CardPositions;
    //positions of the map centers
    public Vector3[] MapPositions;
    //center of the map
    public Transform MapCenter;
    //prefab of the player
    public GameObject playerPrefab;
    //objects to hide
    public GameObject[] ObjectsToDisable;
    //End Screen
    public GameObject EndScreen;

    //coin pouch
    public GameObject CoinPouch;
    //round Text
    public Text RoundText;

    //coins on offer
    private int CoinsOnOffer;
    //text for the amount of coins on offer
    public Text CoinsOnOfferText;

    //aray list that stors the players in the game
    private ArrayList Players;
    //curent state of the game
    private short gameState;

    private GameObject pEndScreen;

    private int currentPlayerBetting;

    private ApplicationManager AM;
    private OutcomeHandeler_CS OH;
    private ArtificialInteligencePersonalityHandeler_CS AIPH;

    private int currentRound;

    private bool Reveale;

    private bool endScreenOn;

    private bool incRound;

    private float heigh = Screen.height;
    private float heighRatio;
    private float width = Screen.width;
    private float widthRatio;

    private float totle;

    public GameObject PauseMenu;
    private GameObject pm;

    private bool PlayerHasReachedMax;

    // Use this for initialization
    void Start () {
        AIPH = GetComponent<ArtificialInteligencePersonalityHandeler_CS>();
        endScreenOn = false;
        currentPlayerBetting = 0;
        gameState = 0;
        CoinsOnOffer = 0;

        Reveale = false;

        if(gameState != 0) {
            gameState = 0;
        }
        //Aplication Manager
        AM = FindObjectOfType<ApplicationManager>();
        OH = GetComponent<OutcomeHandeler_CS>();
        //Aray list of the players
        Players = new ArrayList();

        currentRound = 1;
        SetCurrentRound(currentRound);

        AM.SetCurrentState(1);

        heigh = Screen.height;
        width = Screen.width;

        totle = width + heigh;

        heighRatio = (heigh / totle) * 10;
        widthRatio = (width / totle) * 10;

        heighRatio = Mathf.Floor(heighRatio);
        widthRatio = Mathf.Floor(widthRatio);

        PlayerHasReachedMax = false;

        //if(AM.GetNumberOfPlayers() == 2) {
        //    PlayerPositions[0].position = new Vector3(widthRatio * 1 * -1, heighRatio * (1 + 0.6f), 0.0f);
        //    PlayerPositions[1].position = new Vector3(widthRatio * 1, heighRatio * (1 + 0.6f), 0.0f);
        //}
        //else if(AM.GetNumberOfPlayers() == 3) {
        //    PlayerPositions[0].position = new Vector3(widthRatio * 1.1f * -1, 0.0f, 0.0f);
        //    PlayerPositions[1].position = new Vector3(0.0f, heighRatio * (1 + 0.6f), 0.0f);
        //    PlayerPositions[2].position = new Vector3(widthRatio * 1.1f, 0.0f, 0.0f);
        //}
        //else {
        PlayerPositions[0].position = new Vector3(widthRatio * 1 * -1, heighRatio * (1 + 0.5f), 0.0f);
        PlayerPositions[1].position = new Vector3(widthRatio * 1 * -1, heighRatio * (1 - 1.6f), 0.0f);
        PlayerPositions[2].position = new Vector3(widthRatio * 1, heighRatio * (1 + 0.5f), 0.0f);
        PlayerPositions[3].position = new Vector3(widthRatio * 1, heighRatio * (1 - 1.6f), 0.0f);
        //}
        
        for (int i = 0; i < AM.GetNumberOfPlayers(); i++) {
            GameObject player = (GameObject)Instantiate(playerPrefab,PlayerPositions[i].transform);
            //sets the peramiters of the player
            player.GetComponent<PlayerHandeler_CS>().SetStats((short)i, AM.PlayerSprites[AM.PlayerSpriteNumber[i]], AM.GetPlayersKeys(i), AM.PlayerKeyBindings[i], CardPositions[i], MapPositions[i], MapCenter, new Quaternion(0, 0, 0, 1),AM.PlayerIsAI[i]);
            player.transform.position = PlayerPositions[i].transform.position;
            Players.Add(player);
        }
    }

    //if the player has stolen
    public bool PlayerHasStolen(bool lastRound) {
        foreach (GameObject g in Players) {
            if (g.GetComponent<PlayerHandeler_CS>().GetPlayerStillIn()) {
                if (g.GetComponent<PlayerHandeler_CS>().GetPlayerHasStolen() && !lastRound) {
                    return true;
                }
                else if (g.GetComponent<PlayerHandeler_CS>().GetLastDecision() == 1 && lastRound) {
                    return true;
                }
            }
        }
        return false;
    }

    void Update() {
        if (getPlayersBetting() && AM.GetCanBet()) {
            AM.SetCurrentState(1);
            placeBets();
        }
        else if (!AM.GetCanBet() && AM.GetCurrentState() == 1) {
            AM.SetCurrentState(2);
            AddCoins(10);
            foreach (GameObject g in Players) {
                g.GetComponent<PlayerHandeler_CS>().SetPlayerBetting(false);
            }
        }
        else if (GetGetPlayersReady()) {
            OH.SetPlayerOutcome(Players);
        }
        else if (getPlayersReady()) {
            AM.SetCurrentState(3);
        }
        else {
            CoinPouch.GetComponent<AnimationHandeler_CS>().SetCurrentAnimatorState("IsFilling", false);
            if (AM.GetCurrentState() == 1 && !getPlayersBetting() && GetCoinsOnOffer() != 0) {
                AddCoins(CoinsOnOffer / numberOfPlayersStillIn());
            }
            AM.SetCurrentState(2);
        }

        if (Input.GetKeyDown(KeyCode.Escape) && pEndScreen == null) {
            if (Time.timeScale == 1) {
                Time.timeScale = 0;
                pm = (GameObject)Instantiate(PauseMenu);
            }
            else {
                Time.timeScale = 1;
                Destroy(pm);
            }
        }

        if (AM.GetCurrentState() == 3) {
            if (pEndScreen == null) {

                ArrayList winners;
                winners = new ArrayList();
                int currentWinTotle = 0;

                int NoOfWinners = 0;

                foreach (GameObject g in Players) {
                    PlayerHandeler_CS PHS = g.GetComponent<PlayerHandeler_CS>();
                    //if there is not curently a winer and the player has more than 0 coind
                    if (currentWinTotle == 0 && PHS.GetCoins() > 0) {
                        PHS.SetPlayerHasWon(true);
                        currentWinTotle = PHS.GetCoins();
                        NoOfWinners++;
                    }
                    //if the current player has the same amout of coins as the current winner
                    else if (currentWinTotle == PHS.GetCoins() && currentWinTotle > 0) {
                        PHS.SetPlayerHasWon(true);
                        NoOfWinners++;
                    }
                    else if (PHS.GetCoins() > currentWinTotle) {
                        NoOfWinners = 0;
                        foreach (GameObject GT in Players) {
                            PlayerHandeler_CS PHSTT = GT.GetComponent<PlayerHandeler_CS>();
                            PHSTT.SetPlayerHasWon(false);
                        }
                        PHS.SetPlayerHasWon(true);
                        currentWinTotle = PHS.GetCoins();
                        NoOfWinners++;
                    }
                    else {
                        PHS.SetPlayerHasWon(false);
                    }
                }

                foreach (GameObject GT in Players) {
                    winners.Add(GT.GetComponent<PlayerHandeler_CS>().GetPlayerHasWon());
                }

                pEndScreen = (GameObject)Instantiate(EndScreen);
                pEndScreen.GetComponent<EndGameHandeler_CS>().NewEndGameScreen(NoOfWinners, winners, numberOfPlayers());
            }
        }
    }

    public bool GetReveale() {
        return Reveale;
    }
    public void SetReveale(bool b) {
        Reveale = b;
    }

    public int GetWinners() {
        int temp = 0;
        foreach(GameObject g in Players) {
            PlayerHandeler_CS TPH = g.GetComponent<PlayerHandeler_CS>();
            if (TPH.GetPlayerHasWon()) {
                temp++;
            }
        }
        return temp;
    }

    private void placeBets() {
        GameObject g = (GameObject)Players[currentPlayerBetting];
        PlayerHandeler_CS temp = g.GetComponent<PlayerHandeler_CS>();
        if (!getPlayersBetting()) {
            AddCoins(CoinsOnOffer / numberOfPlayers());
            return;
        }
        if (temp.GetPlayerBetting()) {
            temp.SetBetInput();
            return;
        }
        else {
            currentPlayerBetting++;
        }
    }

    public bool getPlayersBetting() {
        bool flag = false;
        foreach (GameObject g in Players) {
            if (g.GetComponent<PlayerHandeler_CS>().GetPlayerBetting()) {
                flag = true;
            }
        }
        return flag;
    }

    public bool GetGetPlayersReady() {
        bool flag = true;
        foreach (GameObject g in Players) {
            if (!(g.GetComponent<MoveHandeler_CS>().GetPlaterIsReady())) {
                flag = false;
            }
        }
        return flag;
    }

    //checks if every player has selected a card
	public bool AllPlayersSelected() {
        bool flag = true;
        foreach(GameObject g in Players) {
            if (!(g.GetComponent<PlayerHandeler_CS>().GetCardsTogether())) {
                flag = false;
            }
        }
        return flag;
    }

    public bool allPlayerInTheCenter() {
        bool flag = true;
        foreach (GameObject g in Players) {
            if (!(g.GetComponent<PlayerHandeler_CS>().GetCardsInCenter())) {
                flag = false;
            }
        }
        return flag;
    }

    public bool getPlayersReady() {
        bool flag = false;
        foreach (GameObject g in Players) {
            if (g.GetComponent<PlayerHandeler_CS>().GetPlayerIsReady()) {
                flag = true;
            }
        }
        return flag;
    }

    //returns the number of players that are still in
    public short numberOfPlayersStillIn() {
        short temp = 0;
        foreach (GameObject g in Players) {
            if ((g.GetComponent<PlayerHandeler_CS>().GetPlayerStillIn()) || g.GetComponent<PlayerHandeler_CS>().GetCoins() > 0) {
                temp++;
            }
        }
        return temp;
    }

    public void BetAll() {
        GameObject g = (GameObject)Players[currentPlayerBetting];
        PlayerHandeler_CS temp = g.GetComponent<PlayerHandeler_CS>();
        CoinPouch.GetComponent<AnimationHandeler_CS>().SetCurrentAnimatorState("IsFilling", true);
        GetComponent<AudioSource>().Play();
        int amount = temp.GetCoins();
        AddCoins(amount);
        temp.SetCoins(0);
        temp.SetPlayerBetting(false);
        Destroy(temp.gerBI());
    }
    
    public void PlaceBet(bool useText, int i) {
        GameObject g = (GameObject)Players[currentPlayerBetting];
        PlayerHandeler_CS temp = g.GetComponent<PlayerHandeler_CS>();
        try {
            int amount;
            if (useText) {
                amount = int.Parse(temp.gerBI().GetComponent<BetHandeler_CS>().BetInputText.text);
            }
            else {
                amount = i;
            }
            
            if (temp.GetCoins() >= amount && amount >= AM.GetMinnBet()) {
                CoinPouch.GetComponent<AnimationHandeler_CS>().SetCurrentAnimatorState("IsFilling", true);
                
                AddCoins(amount);
                temp.AddCoins(amount * -1);
                temp.SetPlayerBetting(false);
                Destroy(temp.gerBI());
            }
        }
        catch {

        }
    }

    public void ResetRound() {
        if (pm != null) {
            Time.timeScale = 1;
            Destroy(pm);
        }
        Destroy(pEndScreen);
        Reveale = false;
        foreach (GameObject g in Players) {
            PlayerHandeler_CS pg = g.GetComponent<PlayerHandeler_CS>();
            MoveHandeler_CS Mg = g.GetComponent<MoveHandeler_CS>();
            g.GetComponent<Player_Decision_Colour_CS>().SetNewColour(pg.GetAmountOfCoices(1), pg.GetAmountOfCoices(0), pg.GetAmountOfCoices(2));
            pg.SetLastRoundText(pg.GetPlayerChoice());
            pg.SetPlayerChoice(-1);
            print(pg.GetPlayerStillIn());
            if (pg.GetPlayerStillIn()) {
                pg.SetCoinPouchAnimation("IsFilling", false);
                Mg.ResetCards();
                pg.SetPlayerBetting(true);
                pg.SetPlayerIsReady(false);
                pg.SetCardsTogether(false);
                pg.SetCardsInCenter(false);
            }
            OH.SetOutcomeFlag(false);
            gameState = 4;
            endScreenOn = false;
            currentPlayerBetting = 0;
            AM.SetCurrentState(1);
            SetCoinsOnOffer(0);
        }
    }

    public void RestartGame() {
        if (pm != null) {
            Time.timeScale = 1;
            Destroy(pm);
        }
        Destroy(pEndScreen);
        foreach (GameObject g in Players) {
            PlayerHandeler_CS pg = g.GetComponent<PlayerHandeler_CS>();
            MoveHandeler_CS Mg = g.GetComponent<MoveHandeler_CS>();
            g.GetComponent<Player_Decision_Colour_CS>().SetNewColour(0, 0, 0);
            pg.ResetDecisions();
            pg.SetCoinPouchAnimation("IsFilling", false);
            Mg.ResetCards();
            pg.SetPlayerStillIn(true);
            pg.SetPlayerBetting(true);
            pg.SetPlayerIsReady(false);
            pg.SetCardsTogether(false);
            pg.SetCardsInCenter(false);
            pg.SetPlayerChoice(-1);
            pg.SetCoins(AM.GetCoins());
            g.SetActive(true);
            pg.SetPlayerHasStolen(false);
            pg.SetLastRoundText(-1);
        }
        OH.SetOutcomeFlag(false);
        gameState = 4;
        endScreenOn = false;
        currentPlayerBetting = 0;
        SetCurrentRound(1);
        AM.SetCurrentState(1);

        PlayerHasReachedMax = false;

        SetCoinsOnOffer(0);
    }

    private short GetWinner() {
        foreach(GameObject g in Players) {
            if (g.GetComponent<PlayerHandeler_CS>().GetPlayerStillIn()) {
                return g.GetComponent<PlayerHandeler_CS>().GetPlayerNumber();
            }
        }
        return -1;
    }

    private short numberOfPlayers() {
        short s = 0;
        foreach (GameObject g in Players) {
            s++;
        }
        return s;
    }

    private void SetObejectsToDisable(bool b) {
        foreach(GameObject g in ObjectsToDisable) {
            g.SetActive(b);
        }
    }

    private void SetCoinsOnOfferText(int i) {
        CoinsOnOfferText.text = i.ToString();
    }

    public void AddCoins(int i) {
        CoinsOnOffer += i;
        SetCoinsOnOfferText(CoinsOnOffer);
        GetComponent<AudioSource>().Play();
    }

    public void SetCoinsOnOffer(int i) {
        CoinsOnOffer = i;
        SetCoinsOnOfferText(CoinsOnOffer);
    }

    public int GetCoinsOnOffer() {
        return CoinsOnOffer;
    }

    public int GetRound() {
        return currentRound;
    }

    public void IncrimentRound() {
        currentRound++;
        setRoundText();
    }

    public void SetCurrentRound(int i) {
        currentRound = i;
        setRoundText();
    }

    public ArrayList GetPlayers() {
        return Players;
    }

    public bool GetPlayerHasRechedMax() {
        return PlayerHasReachedMax;
    }

    public void SetPlayerHasRechedMax(bool b) {
        PlayerHasReachedMax = b;
    }

    public GameObject GetPlayer(int i) {
        return (GameObject)Players[i];
    }

    private void setRoundText() {
        RoundText.text = "Round: " + currentRound;
    }

}
