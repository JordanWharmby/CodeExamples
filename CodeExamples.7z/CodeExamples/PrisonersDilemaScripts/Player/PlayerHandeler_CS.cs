﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerHandeler_CS: MonoBehaviour {

    //the players cards
    public GameObject[] PlayerCards;
    //bet input
    public GameObject BetInput;
    //coin pouch for the player
    public GameObject CoinPouch;
    //sprite for the player position
    public Transform PlayerSpritePosition;
    //card centere
    public Transform PlayerCardCenter;
    //map center;
    public Transform PlayerMapCenter;
    //coin text
    public Text CoinAmountText;

    public Text PlayerText;

    public AudioClip[] CardSounds;

    private bool PlayerCanThinck;

    //private veriables

    //is the card together
    private bool cradsTogethrt;
    //is the card in the center
    private bool cardInCenter;
    //redy for outcome
    private bool readyForOutcome;

    //players input
    private KeyCode[] playerInput = new KeyCode[3];
    //bet inpput
    private GameObject bi;
    //is the player betting
    private bool playerBetting;
    //lastRoundText
    public Text LastRoundText;
    //the players number
    private short playerNumber;
    //the players choice
    private short playerChoice;
    //is the player still in the game
    private bool playerStillIn;
    //current state of the player
    private short state;
    //players sprite
    public GameObject playerSprite;
    //amount of coins
    private int coins;
    //players keys
    private GameObject playerKeys;
    //animation handelres

    private float[] decisions;

    //if the player has won
    private bool PlayerHasWon;

    //player
    private AnimationHandeler_CS playerAnimations;
    //coin pouch
    private AnimationHandeler_CS coinPouchAnimations;

    private ArtificialInteligencePersonalityHandeler_CS AIPH;

    private ApplicationManager AM;
    private ArtificialInteligencePersonalityHandeler_CS TO;
    private GameHandeler_CS GH;

    //Original positions of the 
    private Vector3[] originalCardPositions = new Vector3[3];

    private bool playerHasStolen;

    private bool IsAI;

    private float delay;
    private float wait;

    private int lastRoundDec;

    [SerializeField]
    private ArtificialInteligence_CS playerAI;

    // Use this for initialization
    void Start() {

        AM = FindObjectOfType<ApplicationManager>();
        GH = FindObjectOfType<GameHandeler_CS>();
        AIPH = FindObjectOfType<ArtificialInteligencePersonalityHandeler_CS>();

        playerAI = GetComponent<ArtificialInteligence_CS>();
        

        PlayerCanThinck = false;

        delay = 0;
        wait = Random.Range(2, 5);

        playerKeys.transform.localPosition = new Vector3(0f, -1.5f, -0.1f);
        playerKeys.transform.localScale = new Vector3(1.4f, 1.4f, 1f);

        playerKeys.SetActive(!IsAI);

        cradsTogethrt = false;
        cardInCenter = false;
        playerBetting = true;
        //sets the player to still being in the game
        playerStillIn = true;
        //sets the current state to nutrel
        state = 0;
        //sets the curent chios to non of the cards
        playerChoice = -1;
        //gets the animation conpontent of the coin pouch
        coinPouchAnimations = CoinPouch.GetComponent<AnimationHandeler_CS>();
        //sets the coins to 10
        AddCoins(AM.GetCoins());
        if(AM.GetCards() == 2) {
            PlayerCards[2].SetActive(false);
            PlayerCards[0].transform.localPosition = new Vector3(-1.5f, 0, 0);
            PlayerCards[1].transform.localPosition = new Vector3(1.5f, 0, 0);
            PlayerCards[2].transform.localPosition = new Vector3(0, 0, 0);

        }

        PlayerHasWon = false;

        LastRoundText.text = "";

        playerHasStolen = false;

        //sets the origional position of the cards
        for (int i = 0; i < originalCardPositions.Length; i++) {
            originalCardPositions[i] = PlayerCards[i].transform.position;
        }

        decisions = new float[3] { 0, 0, 0 };
    }

    public void ResetDecisions() {
        for (int i = 0; i < decisions.Length; i++) {
            decisions[i] = 0;
        }
    }

    public float GetAmountOfCoices(int i) {
        return decisions[i];
    }

    public void SetPlayerHasWon(bool b) {
        PlayerHasWon = b;
    }

    public bool GetPlayerHasWon() {
        return PlayerHasWon;
    }

    public void SetKeys(bool b) {
        playerKeys.SetActive(b);
    }

    public void playSound(int clip) {
        GetComponent<AudioSource>().clip = CardSounds[clip];
        GetComponent<AudioSource>().Play();
    }

    public void SetLastRoundText(short lrChoice) {
        lastRoundDec = lrChoice;
        if(lrChoice == -1) {
            LastRoundText.text = "";
        }
        else if (lrChoice == 0) {
            LastRoundText.text = "Last Round: Share";
        }
        else if (lrChoice == 1) {
            LastRoundText.text = "Last Round: Steal";
        }
        else if (lrChoice == 2) {
            LastRoundText.text = "Last Round: Defend";
        }
    }

    public int GetLastDecision() {
        return lastRoundDec;
    }

    public string GetMostUsedMove() {
        if(decisions[0] == decisions[1] && decisions[1] == decisions[2]) {
            return "All";
        }
        if (decisions[0] == decisions[1] && decisions[1] > decisions[2]) {
            return "Share/Steal";
        }
        if (decisions[1] == decisions[2] && decisions[1] > decisions[0]) {
            return "Steal/Defend";
        }
        if (decisions[0] == decisions[2] && decisions[0] > decisions[1]) {
            return "Defend/Share";
        }
        if (decisions[0] > decisions[1] && decisions[0] > decisions[2]){
            return "Share";
        }
        if (decisions[1] > decisions[0] && decisions[1] > decisions[2]) {
            return "Steal";
        }
        if (decisions[2] > decisions[0] && decisions[2] > decisions[1]) {
            return "Defend";
        }
        return "";
    }

    public void SetPlayerHasStolen(bool b) {
        playerHasStolen = b;
    }

    public bool GetPlayerHasStolen() {
        return playerHasStolen;
    }

    //sets the stats for the player
    public void SetStats(short num, GameObject sprite, KeyCode[] inputs, GameObject keyInputSprites, Vector3 CardCenter, Vector3 MapCenterCards, Transform MapCenter, Quaternion rot, bool ai) {
        //sets the playerNumber
        playerNumber = num;
        //sets the sprite
        playerSprite = sprite;
        playerSprite.transform.localScale = new Vector3(2.3f, 2.3f, 2.3f);
        //sets the possition of the sprite
        if (sprite != null) {
            //gets the players sprite
            GameObject tempsprite = (GameObject)Instantiate(playerSprite, PlayerSpritePosition);
            //sets the local position
            tempsprite.transform.localPosition = new Vector3(0, 0, 0);
            //gets the animation script
            playerAnimations = tempsprite.GetComponent<AnimationHandeler_CS>();
        }
        //sets the keys for the player
        playerKeys = (GameObject)Instantiate(keyInputSprites, this.transform);

        //sets the inputs for the players
        playerInput = inputs;
        //sets the position and rotation
        transform.rotation = rot;
        //sets the name of the prefab
        transform.name = "Player" + playerNumber;
        //sets the positions the cards can go
        PlayerCardCenter.position = transform.position;
        PlayerMapCenter.SetParent(MapCenter);
        PlayerMapCenter.position = MapCenterCards;

        IsAI = ai;
        
       

        if (ai) {
            PlayerText.text = "Player " + (playerNumber + 1) + "(A.I)";
            TO = FindObjectOfType<ArtificialInteligencePersonalityHandeler_CS>();
            if (TO.GetIsCustom(playerNumber)) {
                ArtificialInteligence_CS PAI = GetComponent<ArtificialInteligence_CS>();
                PAI.SetStats(TO.GetAIISRandom(playerNumber), TO.GetAIISFerm(playerNumber), TO.GetAIIReset(playerNumber), TO.GetStats(playerNumber));
            }
        }
        else {
            PlayerText.text = "Player " + (playerNumber + 1);
        }
    }

    public void SetSpriteAnimation(string s, bool b) {
        playerAnimations.SetCurrentAnimatorState(s, b);
    }

    public void SetCoinPouchAnimation(string s, bool b) {
        coinPouchAnimations.SetCurrentAnimatorState(s, b);
    }

    public void SetCatdAnimation(string s, bool b, bool all) {
        if (all) {
            foreach (GameObject g in PlayerCards) {
                g.GetComponent<AnimationHandeler_CS>().SetCurrentAnimatorState(s, b);
            }
        }
        else if(playerChoice > -1 && playerChoice < 3){
            PlayerCards[playerChoice].GetComponent<AnimationHandeler_CS>().SetCurrentAnimatorState(s, b);
        }

    }

    //gets and sets wether the player is still in
    public bool GetPlayerStillIn() { return playerStillIn; }
    public void SetPlayerStillIn(bool b) { playerStillIn = b; }

    public bool GetPlayerBetting() { return playerBetting; }
    public void SetPlayerBetting(bool b) { playerBetting = b; }

    public bool GetCardsTogether() { return cradsTogethrt; }
    public void SetCardsTogether(bool b) { cradsTogethrt = b; }

    public bool GetCardsInCenter() { return cardInCenter; }
    public void SetCardsInCenter(bool b) { cardInCenter = b; }

    public bool GetPlayerIsReady() { return readyForOutcome; }
    public void SetPlayerIsReady(bool b){ readyForOutcome = b; }

    public short GetPlayerState() { return state; }
    public void SetPlayerState(short s) { state = s; }

    public void SetPlayerChoice(short s) { playerChoice = s; }
    public short GetPlayerChoice() { return playerChoice; }

    public short GetPlayerNumber() { return playerNumber; }

    public GameObject GetPlayerSprite() { return playerSprite; }

    public GameObject gerBI() {
        return bi;
    }

    public void AddCoins(int i) {
        coins += i;
        if(i > 0) {
            playSound(2);
        }
        if(coins <= 0) {
            coins = 0;
        }
        CoinAmountText.text = coins.ToString();
    }
    public void SetCoins(int i) {
        coins = i;
        CoinAmountText.text = coins.ToString();
    }
    public int GetCoins() { return coins; }

    //moves the cards to a new position
    private bool MoveObjects(GameObject objectToMove, Vector3 newPos, float speed) {
        if(Vector3.Distance(objectToMove.transform.position, newPos) < 0.1) {
            return true;
        }
        //sets the new position of the object
        Vector3 direction = newPos - objectToMove.transform.position;
        objectToMove.transform.Translate(direction.normalized * speed * Time.deltaTime, Space.World);
        //checks if it is in the right position
        return (Vector3.Distance(objectToMove.transform.position, newPos) < 0.1);
    }

    public void SetBetInput() {
        if(bi == null && AM.GetCurrentState() == 1)  {
            bi = (GameObject)Instantiate(BetInput);
            bi.GetComponent<BetHandeler_CS>().SetBetHandelet(playerNumber);
            if (IsAI && playerBetting && AM.GetCurrentState() == 1) {
                int i = playerAI.PlaceBet();
                if(i == -1) {
                    GH.BetAll();
                }
                else {
                    int temp = (GetCoins() - (Mathf.RoundToInt(Random.Range(AM.GetMinnBet(), GetCoins()))));
                    bi.GetComponent<BetHandeler_CS>().BetInputText.text = temp.ToString();
                    GH.PlaceBet(false, i);
                }
                
            }
        }
    }

    public void resetCardPositions() {
        for (int i = 0; i < PlayerCards.Length; i++) {
            PlayerCards[i].transform.position = originalCardPositions[i];
        }
    }

    void Update() {

        if (AM.GetCurrentState() != 1 && GH.GetCoinsOnOffer() > 0) {
            SetPlayerBetting(false);
            print(AM.GetCurrentState());
        }
        else if(GH.GetCoinsOnOffer() == 0){
            SetPlayerBetting(true);
        }
        
        if (playerChoice != -1) {
            return;
        }
        if (!IsAI) {
            if (playerChoice == -1 && AM.GetCurrentState() == 2) {
                //shair
                if (Input.GetKey(playerInput[0])) {
                    playerChoice = 0;
                    playerAnimations.SetCurrentAnimatorState("IsConfused", true);
                    playerKeys.SetActive(false);
                    playSound(0);
                    decisions[0]++;
                }
                //steel
                if (Input.GetKey(playerInput[1])) {
                    playerChoice = 1;
                    playerAnimations.SetCurrentAnimatorState("IsConfused", true);
                    playerKeys.SetActive(false);
                    playSound(0);
                    playerHasStolen = true;
                    decisions[1]++;
                }
                //defend
                if (Input.GetKey(playerInput[2])) {
                    playerChoice = 2;
                    playerAnimations.SetCurrentAnimatorState("IsConfused", true);
                    playerKeys.SetActive(false);
                    playSound(0);
                    decisions[2]++;
                }
            }
        }
        else {
            if(!playerBetting && playerChoice == -1) {
                PlayerCanThinck = true;
            }
            if (PlayerCanThinck) {
                delay += Time.deltaTime;
            }
            if(delay > wait) {
                PlayerCanThinck = false;
                delay = 0;
                int decision = playerAI.Decision();
                if (decision == 0 && AM.GetCurrentState() == 2) {
                    playerChoice = 0;
                    playerAnimations.SetCurrentAnimatorState("IsConfused", true);
                    playerKeys.SetActive(false);
                    playSound(0);
                    decisions[0]++;
                }
                //steel
                if (decision == 1 && AM.GetCurrentState() == 2) {
                    playerChoice = 1;
                    playerAnimations.SetCurrentAnimatorState("IsConfused", true);
                    playerKeys.SetActive(false);
                    playSound(0);
                    playerHasStolen = true;
                    decisions[1]++;
                }
                //defend
                if (decision == 2 && AM.GetCurrentState() == 2) {
                    playerChoice = 2;
                    playerAnimations.SetCurrentAnimatorState("IsConfused", true);
                    playerKeys.SetActive(false);
                    playSound(0);
                    decisions[2]++;
                }
            }
            
            
        }
    }

    public bool IsPlayerAI() {
        return IsAI;
    }

    //resets the players state
    public void RoundReset() {
        delay = 0;
        playerChoice = -1;
        wait = Random.Range(2, 5);
        state = 0;
        cardInCenter = false;
        cradsTogethrt = false;
        playerBetting = true;
        foreach (GameObject g in PlayerCards) {
            g.GetComponent<AnimationHandeler_CS>().SetCurrentAnimatorState("IsFaceUp", false);
        }
        resetCardPositions();
        PlayerCanThinck = true;
    }

    public void RoundGame() {
        for (int i = 0; i < decisions.Length; i++) {
            decisions[i] = 0;
        }
        delay = 0;
        wait = Random.Range(2, 5);
        playerChoice = -1;
        state = 0;
        coins = 10;
        playerStillIn = true;
        resetCardPositions();
        cardInCenter = false;
        cradsTogethrt = false;
        playerBetting = true;
        foreach (GameObject g in PlayerCards) {
            g.GetComponent<AnimationHandeler_CS>().SetCurrentAnimatorState("IsFaceUp", true);
        }
        PlayerCanThinck = true;
    }
}
