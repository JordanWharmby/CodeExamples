﻿using UnityEngine;
using System.Collections;

public class MoveHandeler_CS : MonoBehaviour {

    private float cardMoveSpeed;

    private float Delay;

    private PlayerHandeler_CS PH;
    private GameHandeler_CS GH;
    private OutcomeHandeler_CS OH;

    private bool allSatges;
    private bool getOutcome;
    bool audiPlayed;

	// Use this for initialization
	void Start () {
        PH = GetComponent<PlayerHandeler_CS>();
        GH = FindObjectOfType<GameHandeler_CS>();
        OH = FindObjectOfType<OutcomeHandeler_CS>();

        cardMoveSpeed = 6f;
        Delay = 0;
        allSatges = false;
        getOutcome = false;
        audiPlayed = false;
    }

    

    //moves the cards to a new position
    private bool MoveObjects(GameObject objectToMove, Vector3 newPos, float speed, float tol) {
        if (Vector3.Distance(objectToMove.transform.position, newPos) < tol) {
            objectToMove.transform.position = newPos;
            return true;
        }
        //sets the new position of the object
        Vector3 direction = newPos - objectToMove.transform.position;
        objectToMove.transform.Translate(direction.normalized * speed * Time.deltaTime, Space.World);
        //checks if it is in the right position
        return false;
    }

    public void ResetCards() {
        PH.SetCatdAnimation("IsFaceUp", true, true);

        PH.SetSpriteAnimation("IsConfused", false);
        PH.SetSpriteAnimation("IsAngery", false);

        PH.SetKeys(!PH.IsPlayerAI());

        allSatges = false;
        getOutcome = true;
        getOutcome = false;
        audiPlayed = false;

        Delay = 0;

        PH.resetCardPositions();
    }

    // Update is called once per frame
    void FixedUpdate() {
        
        if (!PH.GetPlayerBetting() && PH.GetPlayerChoice() != -1 && !GH.AllPlayersSelected()) {
            PH.SetKeys(false);
            PH.SetSpriteAnimation("IsConfused", true);
            PH.SetSpriteAnimation("IsAngery", false);
            PH.SetCardsTogether(MoveObjects(PH.PlayerCards[0], PH.PlayerCardCenter.position, cardMoveSpeed, 0.05f) && MoveObjects(PH.PlayerCards[1], PH.PlayerCardCenter.position, cardMoveSpeed, 0.05f) && MoveObjects(PH.PlayerCards[2], PH.PlayerCardCenter.position, cardMoveSpeed, 0.05f));
            if (PH.GetCardsTogether()) {
                PH.SetCatdAnimation("IsFaceUp", false, true);
            }
        }
        //if all the players have selected
        else if (GH.AllPlayersSelected() && !GH.allPlayerInTheCenter()) {
            PH.SetSpriteAnimation("IsConfused", false);
            Delay += Time.deltaTime;
            if (Delay >= 4) {
                if (!audiPlayed) {
                    PH.playSound(1);
                    audiPlayed = true;
                }
                //moves the cards into the center
                PH.SetCardsInCenter(MoveObjects(PH.PlayerCards[PH.GetPlayerChoice()], PH.PlayerMapCenter.position, cardMoveSpeed, 0.1f));
                if (PH.GetCardsInCenter()) {
                    audiPlayed = false;
                    Delay = 0;
                }
            }
        }
        //if all the cards are in the center
        else if(GH.allPlayerInTheCenter() && !allSatges) {
            Delay += Time.deltaTime;
            if (Delay >= 4) {
                if (!audiPlayed) {
                    PH.playSound(1);
                    audiPlayed = true;
                }
                PH.SetCatdAnimation("IsFaceUp", true, false);
                Delay = 0;
                allSatges = true;
            }
        }
        //if the cards have been revealed
        else if (allSatges && !OH.GetOutcomeHasBeenCalled()) {
            Delay += Time.deltaTime;
            if (Delay >= 4) {
                getOutcome = true;
                Delay = 0;
                allSatges = false;
            }
        }
        
	}

    public bool GetPlaterIsReady() { return getOutcome; }

}
