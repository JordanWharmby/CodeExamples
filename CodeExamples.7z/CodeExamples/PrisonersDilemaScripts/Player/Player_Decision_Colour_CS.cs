﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Player_Decision_Colour_CS : MonoBehaviour {

    public Image PlayerDecisionImage;

    private float amountSteal;
    private float amountShare;
    private float amountDefend;

	// Use this for initialization
	void Start () {
        amountSteal = 0;
        amountShare = 0;
        amountShare = 0;
    }

    public void SetNewColour(float R, float G, float B) {
        float temp = R + G + B;
        if(R > 0) {
            amountSteal = (float)((R / temp) * 225);
        }
        if(G > 0) {
            amountShare = (float)((G / temp) * 225);
        }
        if(B > 0) {
            amountDefend = (float)((B / temp) * 225);
        }

        print(amountSteal + " " + amountShare + " " + amountDefend);

        PlayerDecisionImage.color = new Color(amountSteal, amountShare, amountDefend);
    }
}
