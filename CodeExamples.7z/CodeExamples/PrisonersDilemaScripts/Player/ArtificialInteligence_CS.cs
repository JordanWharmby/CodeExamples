﻿using UnityEngine;
using System.Collections;


public class ArtificialInteligence_CS:MonoBehaviour{

    private bool random;

    private bool ferm;

    private float altruisum;
    private float forgivnes;
    private float nerve;

    private int memory;

    private bool reset;

    private float bA, bF, bN;
    private int baseMemory;

    private ApplicationManager AM;
    private GameHandeler_CS GH;

    private PlayerHandeler_CS PH;

    void Start() {

        AM = FindObjectOfType<ApplicationManager>();
        GH = FindObjectOfType<GameHandeler_CS>();
        PH = GetComponent<PlayerHandeler_CS>();

        //1 in 3 chanse the AI will be random
        random = (Mathf.RoundToInt(Random.Range(0, 30)) % 3 == 0);
        //if it is not random
        //set the ither peramiters
        if (!random) {
            altruisum = Mathf.RoundToInt(Random.Range(0, 10));
            forgivnes = Mathf.RoundToInt(Random.Range(0, 10));
            memory = Mathf.RoundToInt(Random.Range(0, 2) * (forgivnes / 2));
            baseMemory = memory;
            nerve = Random.Range(1, 10);
            //decides wether the AI will change over time;
            ferm = (Mathf.RoundToInt(Random.Range(0, 10)) % 2 == 0);
            //if the AI is nor ferm
            if (!ferm) {
                //will the AI reset after the game
                reset = (Mathf.RoundToInt(Random.Range(0, 30)) % 3 == 0);

                bA = altruisum;
                bF = forgivnes;
                bN = nerve;
            }
            else {
                reset = false;
            }
        }
        else {
            ferm = false;
            reset = false;
        }
    }

    public void SetStats(bool rand, bool isFerm, bool willReset, int[] stats) {
        if (rand) {
            random = true;
        }
        else {
            altruisum = stats[0];
            forgivnes = stats[1];
            nerve = stats[2];
            memory = stats[3];

            bA = altruisum;
            bF = forgivnes;
            bN = nerve;

            ferm = isFerm;

            if (!isFerm) {
                reset = willReset;
            }
            else {
                reset = false;
            }
        } 
    }

    public int Decision() {
        //if the AI is random
        if (random) {
            return Mathf.RoundToInt(Random.Range(0, AM.GetCards() - 1));
        }
        //If an AI stole last round
        if(GH.PlayerHasStolen(forgivnes < 5) && GH.GetRound() > 1) {
            if (memory > 0) {
                memory--;
                if(AM.GetCards() == 2) {
                    return 1;
                }
                else {
                    if(PH.GetLastDecision() == 1) {
                        return 2;
                    }
                    else {
                        return 1;
                    }
                }
            }
            else {
                memory = baseMemory;
            }
        }
        
        //if the AI is alrrtuistic
        if(altruisum > 6) {
            return 0;
        }
        //if the AI is selfish
        else if(altruisum < 4) {
            return 1;
        }
        //if it is in the middle
        else {
            if(AM.GetCards() == 3) {
                return 2;
            }
            else {
                int x = Mathf.RoundToInt(Random.Range(0, 1f));
                return x;
            }
        }

    }

    public int PlaceBet() {
        if(PH.GetCoins() < AM.GetMinnBet()) {
            return -1;
        }
        else {
            int i = Mathf.RoundToInt(Random.Range(AM.GetMinnBet(), PH.GetCoins() * (nerve / 10)));
            i = Mathf.Clamp(i, AM.GetMinnBet(), PH.GetCoins());
            return i;
        }
    }

    public void Reset() {
        if (reset) {
            altruisum = bA;
            forgivnes = bF;
            nerve = bN;
            memory = baseMemory;
        }
    }

    public void SetAltruisum(bool b) {
        if (b) {
            altruisum++;
        }
        else {
            altruisum--;
        }
        altruisum = Mathf.Clamp(altruisum, 0, 10);
    }

    public void SetForgivness(bool b) {
        if (b) {
            forgivnes++;
        }
        else {
            forgivnes--;
        }
        forgivnes = Mathf.Clamp(forgivnes, 0, 10);
    }

}
