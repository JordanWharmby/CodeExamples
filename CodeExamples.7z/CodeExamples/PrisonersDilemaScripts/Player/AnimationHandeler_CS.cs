﻿using UnityEngine;
using System.Collections;

public class AnimationHandeler_CS : MonoBehaviour {

    //animatro for the coin poch
    private Animator animator;

    // Use this for initialization
    void Start() {
        animator = GetComponent<Animator>();
    }

    //sets the starte of any bol animation
    public void SetCurrentAnimatorState(string State, bool b) {
        try {
            animator.SetBool(State, b);
        }
        catch {
            print("ERROR " + State + " " + b);
        }
        
    }
}
