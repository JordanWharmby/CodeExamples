﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CustomizationHandeler_CS : MonoBehaviour {

    [Header("Limitless Peramiters")]
    public Toggle Limitless;
    private bool useMaxRounds;
    public GameObject MaxRoundsObject;
    public Text MaxRoundText;
    private int MaxRounds = 1;

    [Header("Betting Peramiters")]
    public Text CoinsPerPlayerText;
    private int coinsPerPlayer = 10;
    public Text MinimumBetText;
    private int minimumBet = 1;

    [Header("Outcome Peramiters")]
    public Toggle UseMaxCoinsToggle;
    private bool useMaxCoins;
    public GameObject MaxCoins;
    public Text MimimumCoinsText;
    private int minimumCoins = 1;

    private ApplicationManager AM;

    void Start() {
        AM = FindObjectOfType<ApplicationManager>();

        //limitess and max round
        Limitless.isOn = true;
        IsLimitless();

        SetCoinsPerPlayes(0);
        SetMinimumBet(0);

        useMaxCoins = false;
        UseMaxCoins();
    }

    public void IsLimitless() {
        useMaxRounds = Limitless.isOn;
        MaxRoundsObject.SetActive(!useMaxRounds);
    }
    public void SetNewMaxRound(int i) {
        MaxRounds += i;
        if(MaxRounds < 0) {
            MaxRounds = 0;
        }
        MaxRoundText.text = MaxRounds.ToString();
    }

    public void SetCoinsPerPlayes(int i) {
        coinsPerPlayer += i;
        if (coinsPerPlayer < 1) {
            coinsPerPlayer = 1;
        }
        CoinsPerPlayerText.text = coinsPerPlayer.ToString();
    }
    public void SetMinimumBet(int i) {
        minimumBet += i;
        if (minimumBet < 1) {
            minimumBet = 1;
        }
        MinimumBetText.text = minimumBet.ToString();
    }

    public void UseMaxCoins() {
        useMaxCoins = UseMaxCoinsToggle.isOn;
        MaxCoins.SetActive(useMaxCoins);
    }

    public void SetMaxCoins(int i) {
        minimumCoins += i;
        if (minimumCoins < 0) {
            minimumCoins = 0;
        }
        MimimumCoinsText.text = minimumCoins.ToString();
    }

    public void SetNewStats() {
        if (!useMaxRounds) {
            AM.SetRounds(MaxRounds);
        }

        AM.SetCoins(coinsPerPlayer);
        AM.SetMinBet(minimumBet);

        if (useMaxCoins) {
            AM.SetMaxCoins(minimumCoins);
        }
    }
    
}
