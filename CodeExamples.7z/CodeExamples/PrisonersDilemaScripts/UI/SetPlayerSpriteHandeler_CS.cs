﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SetPlayerSpriteHandeler_CS : MonoBehaviour {

    public int SpriteImage;

    public int PlayerNumber;

    public Button Next;
    public Button Previous;

    public Image Sprite;

    private ApplicationManager AM;
    private MainMenuHandeler_CS MMH;

    private float time = 0;
    private float delay = 1;
    private bool show = true;

	// Use this for initialization
	void Start () {
        AM = FindObjectOfType<ApplicationManager>();
        MMH = FindObjectOfType<MainMenuHandeler_CS>();

        Next.onClick.AddListener(NextImage);
        Previous.onClick.AddListener(PriviousImage);

        Sprite.sprite = AM.PlayerSpriteImage[SpriteImage];
    }

    void Update() {
        time += Time.deltaTime;
        if(time > delay && show) {
            SetNewImage();
            show = false;
        }
    }

    public void NextImage() {
        SpriteImage++;
        if(SpriteImage >= AM.PlayerSpriteImage.Length) {
            SpriteImage = 0;
        }
        MMH.PlayAudio(1);
        SetNewImage();
    }

    public void PriviousImage() {
        SpriteImage--;
        if (SpriteImage < 0) {
            SpriteImage = AM.PlayerSpriteImage.Length - 1;
        }
        MMH.PlayAudio(1);
        SetNewImage();
    }

    private void SetNewImage() {
        if(SpriteImage == AM.PlayerSpriteImage.Length - 1) {
            Sprite.sprite = AM.PlayerSpriteImage[SpriteImage];
            int x = (int)Mathf.Round(Random.Range(0, AM.PlayerSprites.Length - 1));
            AM.PlayerSpriteNumber[PlayerNumber] = x;
        }
        else {
            Sprite.sprite = AM.PlayerSpriteImage[SpriteImage];
            AM.PlayerSpriteNumber[PlayerNumber] = SpriteImage;
        }
        
    }

}
