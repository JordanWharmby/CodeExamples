﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PauseMenuHandeler_CS : MonoBehaviour {

    public Button RestartButton;
    public Button ExitButton;

    private GameHandeler_CS GH;

	// Use this for initialization
	void Start () {
        GH = FindObjectOfType<GameHandeler_CS>();
        //GetComponent<Canvas>().worldCamera = Camera.main;

        RestartButton.onClick.AddListener(GH.RestartGame);
        ExitButton.onClick.AddListener(OnExitTheGame);
    }

    public void OnExitTheGame() {
        Time.timeScale = 1;
        LoadingScreenManager.LoadScene(1);
    }

}
