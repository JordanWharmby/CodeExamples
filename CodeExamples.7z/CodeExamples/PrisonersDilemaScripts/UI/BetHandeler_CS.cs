﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;


public class BetHandeler_CS : MonoBehaviour {

    public Text PlayerText;
    public Text BetInputText;

    public Button EnterButton;
    public Button BetAllButton;

    public InputField InputField;

    public Text MinimumBetText;

    private GameHandeler_CS GH;
    private ApplicationManager AM;

	// Use this for initialization
	void Start () {
        GH = FindObjectOfType<GameHandeler_CS>();
        AM = FindObjectOfType<ApplicationManager>();

        EnterButton.onClick.AddListener(PlaceABet);
        BetAllButton.onClick.AddListener(GH.BetAll);

        InputField.Select();
        InputField.ActivateInputField();
        MinimumBetText.text = "Minimum Bet: " + AM.GetMinnBet();
    }
	
    public void SetBetHandelet(short num) {
        PlayerText.text = "Player " + (num + 1);
        
    }

    private void PlaceABet() {
        GH.PlaceBet(true, 0);
    }

    void Update() {
        if (Input.GetKey(KeyCode.Return)) {
            PlaceABet();
        }
    }

}
