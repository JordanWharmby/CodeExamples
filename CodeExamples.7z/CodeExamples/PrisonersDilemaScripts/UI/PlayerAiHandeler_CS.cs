﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class PlayerAiHandeler_CS : MonoBehaviour {

    public GameObject CustomizeButton;

    private bool playerIsAi;

	// Use this for initialization
	void Start () {
        playerIsAi = true;
        SetPlsyerIsAI();
    }
	
	public void SetPlsyerIsAI() {
        playerIsAi = !playerIsAi;
        if (playerIsAi) {
            GetComponentInChildren<Text>().text = "AI";
            CustomizeButton.SetActive(true);
        }
        else {
            GetComponentInChildren<Text>().text = "Player";
            CustomizeButton.SetActive(false);
        }
    }

    public bool GetPlayerIsAI() {
        return playerIsAi;
    }

}
