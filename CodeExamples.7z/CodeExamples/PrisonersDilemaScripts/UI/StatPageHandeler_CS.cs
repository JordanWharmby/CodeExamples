﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class StatPageHandeler_CS : MonoBehaviour {

    public Text PlayerNumber;
    public Text Outcome;
    public Text Coins;
    public Text Profit;
    public Text FaverteMove;

    public Image PlayerSprite;
    
    public void SetInfomation(Sprite ps, string pn, string po, string pc, string pp, string pfm) {
        PlayerSprite.sprite = ps;
        PlayerNumber.text = pn;
        Outcome.text = po;
        Coins.text = pc;
        Profit.text = pp;

        if(int.Parse(pp) > 0) {
            Profit.color = new Color(0, 1, 0, 1);
        }
        else if (int.Parse(pp) < 0) {
            Profit.color = new Color(1, 0, 0, 1);
        }

        FaverteMove.text = pfm;
    }
}
