﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CustomizeAIHandeler_CS : MonoBehaviour {

    private int[] stats = new int[4];

    private bool useCustom;
    private bool random;
    private bool ferm;
    private bool reset;

    private ArtificialInteligencePersonalityHandeler_CS AIPH;

    // Use this for initialization
    void Start () {
	    for(int i = 0; i < 4; i++) {
            stats[i] = 0;
        }
        useCustom = false;
        random = false;
        ferm = false;
        reset = false;
    }

}
