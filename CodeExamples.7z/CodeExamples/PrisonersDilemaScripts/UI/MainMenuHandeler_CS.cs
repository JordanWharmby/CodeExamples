﻿using UnityEngine;
using UnityEngine.UI;

public class MainMenuHandeler_CS : MonoBehaviour {

    public GameObject[] MainMenuPages;
    public GameObject[] HelpMenuPages;
    public GameObject[] TutorialPages;
    public GameObject[] CustomizePage;

    public GameObject[] Cards;
    public GameObject[] ToggleButtons;
    public GameObject[] ToggleCustomize;

    public GameObject[] ToogleButtonsTwoPlayers;
    public GameObject[] ToggleCustomizeTwoPlayers;

    private int currentTPlage;

    public Text NumberOfAI;

    public Toggle AIToggle;

    public Text[] PlaresButtonText;
    private ApplicationManager AM;

    public GameObject Pages;

    public GameObject CustomAI;
    private GameObject tempCustomAI;

    private short numberOfPlayers;

    public Text InfomationText;

    public AudioClip[] AC;
    private AudioSource AS;

	// Use this for initialization
	void Start () {
        currentTPlage = 0;
        AM = FindObjectOfType<ApplicationManager>();
        AS = FindObjectOfType<AudioSource>();
        SetMainMenuePage(0);
        SetHelpMenuePage(0);
        setHelpTutorialPage(0);
        SetCustomizePage(0);
        numberOfPlayers = 2;
        AM.SetNumberOfPlayers(numberOfPlayers);
        SetCardsVisible(2);
        SetButtonTextColour(0);

        InfomationText.text = "";
    }

    public void SetInfomationText(int i) {
        if(i == 0) {
            InfomationText.text = "Clasic \n One round, Two players";
        }
        else if(i == 1) {
            InfomationText.text = "Iterative \n Ten round, Two players";
        }
        else if (i == 2) {
            InfomationText.text = "Iterative++ \n Customizable Gamemode, Up to four players";
        }
        else {
            InfomationText.text = "";
        }
    }

    public void PlayAudio(int i) {
        AS.clip = AC[i];
        AS.Play();
    }

    public void SetPagesVisible(bool b) {
        Pages.SetActive(b);
        if(b == true) {
            if(tempCustomAI != null) {
                Destroy(tempCustomAI);
            }
        }
    }

    public void CustomizeAI(int i) {
        tempCustomAI = (GameObject)Instantiate(CustomAI, this.transform);
        tempCustomAI.transform.localPosition = new Vector3(0, 0, 0);
        tempCustomAI.transform.localScale = new Vector3(1, 1, 1);
        tempCustomAI.GetComponent<CustomAIandeler_CS>().SetStats(i);
    }

    public void SetCardsVisible(int s) {
        numberOfPlayers = (short)s;
        AM.SetNumberOfPlayers(numberOfPlayers);
        for (int i = 0; i < Cards.Length; i++) {
            Cards[i].SetActive(s > i);
            ToggleButtons[i].SetActive(s > i);
            ToggleCustomize[i].SetActive(s > i);
        }
    }

    public void SetIsThePlayerAIClasitIterative() {
        for (int i = 0; i < ToogleButtonsTwoPlayers.Length; i++) {
            PlayerAiHandeler_CS t = ToogleButtonsTwoPlayers[i].GetComponent<PlayerAiHandeler_CS>();
            AM.PlayerIsAI[i] = t.GetPlayerIsAI();
        }
    }

    public void SetIsThePlayerAnAI() {
        for (int i = 0; i < ToggleButtons.Length; i++) {
            PlayerAiHandeler_CS t = ToggleButtons[i].GetComponent<PlayerAiHandeler_CS>();
            AM.PlayerIsAI[i] = t.GetPlayerIsAI();
        }
    }

    public void SetGameStats(int i) {
        if(i == 1) {
            AM.SetCards(2);
            AM.SetCoins(0);
            AM.SetRounds(1);
            AM.SetCanBet(false);
            AM.SetUseMaxCoins(false);
            AM.SetMinBet(1);
        }
        else if (i == 2) {
            AM.SetCards(2);
            AM.SetCoins(5);
            AM.SetRounds(10);
            AM.SetCanBet(false);
            AM.SetUseMaxCoins(false);
            AM.SetMinBet(1);
        }
        else if (i == 3) {
            AM.SetCards(3);
            AM.SetCoins(10);
            AM.SetRounds(-1);
            AM.SetCanBet(true);
            AM.SetUseMaxCoins(false);
            AM.SetMinBet(1);
        }
    }

    public void SetCustomizePage(int p) {
        for (int i = 0; i < CustomizePage.Length; i++) {
            CustomizePage[i].SetActive(i == p);
        }
    }

    public void SetButtonTextColour(int i) {
        for (int j = 0; j < PlaresButtonText.Length; j++) {
            if (i == j) {
                PlaresButtonText[j].color = new Color(171, 160, 0, 1);
            }
            else {
                PlaresButtonText[j].color = new Color(0, 0, 0, 1);
            }
        }
    }

	public void SetMainMenuePage(int p) {
        for(int i = 0; i < MainMenuPages.Length; i++) {
            MainMenuPages[i].SetActive(i == p);
        }
    }

    public void SetHelpMenuePage(int p) {
        for (int i = 0; i < HelpMenuPages.Length; i++) {
            HelpMenuPages[i].SetActive(i == p);
        }
    }

    public void SetNewTutorialPage(int p) {
        currentTPlage += p;
        currentTPlage = Mathf.Clamp(currentTPlage, 0, TutorialPages.Length - 1);
        setHelpTutorialPage(currentTPlage);
    }

    private void setHelpTutorialPage(int p) {
        for (int i = 0; i < TutorialPages.Length; i++) {
            TutorialPages[i].SetActive(i == p);
        }
    }

    public void SetPlayerNumber(int i) {
        AM.SetNumberOfPlayers((short)i);
        if (AM.GetNumberOfPlayers() == 1) {
            SetPlayersIsAI(1);
        }
        StartGame();
    }

    public void OnlySetNumberOfPlayers(int i) {
        AM.SetNumberOfPlayers((short)i);
    }

    public void PublicStartStart() {
        StartGame();
    }

    private void StartGame() {
        AM.SetCurrentState(1);
        LoadingScreenManager.LoadScene(3);
    }

    public void resetAIPlayers() {
        for (int i = 0; i < AM.PlayerIsAI.Length; i++) {
            AM.PlayerIsAI[i] = false;
        }
    }

    public void SetPlayersIsAI(int a) {
        if(a == -1) {
            a = AM.GetNumberOfPlayers() - 1;
        }
        for (int i = 0 + a; i < AM.PlayerIsAI.Length; i++) {
            AM.PlayerIsAI[i] = true;
        }
    }

    public void CheckText() {
        if(NumberOfAI.text != "") {
            if(AM.GetNumberOfPlayers() + int.Parse(NumberOfAI.text) <= 4 && AM.GetNumberOfPlayers() > 0 && int.Parse(NumberOfAI.text) > 0) {
                SetPlayersIsAI(AM.GetNumberOfPlayers());
            }
            else {
                NumberOfAI.text.Remove(0);
            }
        }
    }

    public void UseAI() {
        if (AIToggle.isOn && NumberOfAI.text != "") {
            if(int.Parse(NumberOfAI.text) + AM.GetNumberOfPlayers() <= 4) {
                SetPlayersIsAI(AM.GetNumberOfPlayers());
                AM.SetNumberOfPlayers((short)(int.Parse(NumberOfAI.text) + AM.GetNumberOfPlayers()));
            }
        }
        else if(AM.GetNumberOfPlayers() < 2) {
            SetPlayersIsAI(1);
            AM.SetNumberOfPlayers(2);
        }
    }

    public void QuitGame() {
        Application.Quit();
    }

}
