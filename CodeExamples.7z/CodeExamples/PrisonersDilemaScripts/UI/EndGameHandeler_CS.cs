﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class EndGameHandeler_CS : MonoBehaviour {

    public GameObject WinnerObject;
    public GameObject LooserObject;

    public Text WinnerText;
    public Text LooserText;

    public Transform[] WinnersPositions;
    public Transform[] LooserPositions;

    public GameObject[] MainPages;

    public Button RestartButton;

    [SerializeField]
    private Vector3[] positions_FourPlayers;
    [SerializeField]
    private Vector3[] positions_ThreePlayers;
    [SerializeField]
    private Vector3[] positions_TwoPlayers;
    [SerializeField]
    private Vector3[] positions_OnePlayers;
    [SerializeField]
    private Vector3 position_Winner;

    public GameObject StatsPagePrefab;
    public Transform PagePerent;

    public Transform WinnerLooserPage;

    private GameHandeler_CS GH;
    private ApplicationManager AM;

    private GameObject[] sprites;

    private GameObject[] playerStatsArray;
    private int currentStatsPage;

    // Use this for initialization
    void Start () {
        GH = FindObjectOfType<GameHandeler_CS>();
        AM = FindObjectOfType<ApplicationManager>();

        sprites = new GameObject[AM.GetNumberOfPlayers()];
        for (int i = 0; i < AM.GetNumberOfPlayers(); i++) {
            sprites[i] = AM.PlayerSprites[AM.PlayerSpriteNumber[i]];
        }

        GetComponent<Canvas>().worldCamera = Camera.main;
        RestartButton.onClick.AddListener(GH.RestartGame);
        SetMainPage(0);
        currentStatsPage = 0;

        playerStatsArray = new GameObject[AM.GetNumberOfPlayers()];
        for (int i = 0; i < AM.GetNumberOfPlayers(); i++) {
            GameObject PlayerStats = (GameObject)Instantiate(StatsPagePrefab, PagePerent);
            StatPageHandeler_CS PSP = PlayerStats.GetComponent<StatPageHandeler_CS>();

            GameObject TempPlayer = GH.GetPlayer(i);
            PlayerHandeler_CS TPH = TempPlayer.GetComponent<PlayerHandeler_CS>();

            string tS;
            if (TPH.GetPlayerHasWon() && AM.GetNumberOfPlayers() - GH.GetWinners() != 0) {
                tS = "winner";
            }
            else if (!TPH.GetPlayerHasWon() && GH.GetWinners() > 0) {
                tS = "loser";
            }
            else {
                tS = "Draw";
            }
            print(TPH.GetCoins());
            PSP.SetInfomation(sprites[i].GetComponent<SpriteRenderer>().sprite, "Player " + (TPH.GetPlayerNumber() + 1), tS, TPH.GetCoins().ToString(), (TPH.GetCoins() - AM.GetCoins()).ToString(), TPH.GetMostUsedMove());
            PlayerStats.transform.localScale = new Vector3(1, 1, 1);
            PlayerStats.transform.localPosition = new Vector3(0, 0, 0);
            PlayerStats.SetActive(false);
            playerStatsArray[i] = PlayerStats;
        }
        //SetStatsPage(currentStatsPage);
    }

    void Update() {
        if (Input.GetKey(KeyCode.Return)) {
            OnClickRestart();
        }
        else if (Input.GetKey(KeyCode.Escape)) {
            OnExitTheGame();
        }
    }

    private void SetPositions(Vector3[] vTA, int pos, Transform[] inPos) {
        int temp = 0;
        for(int i = 0; i < 4; i++) {
            vTA[i][1] = pos;
            inPos[temp].localPosition = vTA[i];
            temp++;
        }
    }

    public void SetMainPage(int p) {
        for(int i = 0; i < MainPages.Length; i++) {
            MainPages[i].SetActive(p == i);
        }
        SetStatsPage(currentStatsPage);
    }

    public void SetNewStatsPage(int p) {
        currentStatsPage += p;
        currentStatsPage = Mathf.Clamp(currentStatsPage, 0, playerStatsArray.Length - 1);
        SetStatsPage(currentStatsPage);
    }

    private void SetStatsPage(int p) {
        if(playerStatsArray != null) {
            for(int i = 0; i < playerStatsArray.Length; i++) {
                playerStatsArray[i].SetActive(i == p);
            }
        }
        
    }

    public void NewEndGameScreen(int winner, ArrayList winners, short noOfPlayers) {

        WinnerObject.SetActive(true);
        LooserObject.SetActive(true);

        if (winner == 0) {
            LooserText.text = "Losers";
            LooserObject.transform.localPosition = new Vector3(0, 40, 0);
            if (noOfPlayers == 2) {
                SetPositions(positions_TwoPlayers, -20, LooserPositions);
                WinnerObject.SetActive(false);
                LooserObject.SetActive(true);
            }
            else if(noOfPlayers == 3) {
                SetPositions(positions_ThreePlayers, -20, LooserPositions);
                WinnerObject.SetActive(false);
                LooserObject.SetActive(true);
            }
            else {
                SetPositions(positions_FourPlayers, -20, LooserPositions);
                WinnerObject.SetActive(false);
                LooserObject.SetActive(true);
            }
            
        }
        else {
            if (noOfPlayers - winner == 0) {
                WinnerText.text = "Draw";
                LooserObject.SetActive(false);
                WinnerObject.transform.localPosition = new Vector3(0, 40, 0);
                if (noOfPlayers == 4) {
                    SetPositions(positions_FourPlayers, -20, WinnersPositions);
                }
                else if(noOfPlayers == 3) {
                    SetPositions(positions_ThreePlayers, -20, WinnersPositions);
                }
                else if (noOfPlayers == 2) {
                    SetPositions(positions_TwoPlayers, -20, WinnersPositions);
                }
            }
            else if (noOfPlayers - winner == 1) {
                WinnerText.text = "Winner";
                if (noOfPlayers == 4) {
                    LooserText.text = "Loser";
                    SetPositions(positions_ThreePlayers, 62, WinnersPositions);
                    SetPositions(positions_OnePlayers, -62, LooserPositions);
                }
                else if (noOfPlayers == 3) {
                    LooserText.text = "Loser";
                    SetPositions(positions_TwoPlayers, 62, WinnersPositions);
                    SetPositions(positions_OnePlayers, -62, LooserPositions);
                }
                else if (noOfPlayers == 2) {
                    LooserText.text = "Loser";
                    SetPositions(positions_OnePlayers, 62, WinnersPositions);
                    SetPositions(positions_OnePlayers, -62, LooserPositions);
                }
                
            }
            else if (noOfPlayers - winner == 2) {
                WinnerText.text = "Winners";
                if (noOfPlayers == 4) {

                    LooserText.text = "Loosers";
                    SetPositions(positions_TwoPlayers, 62, WinnersPositions);
                    SetPositions(positions_TwoPlayers, -62, LooserPositions);
                }
                else if (noOfPlayers == 3) {
                    LooserText.text = "Loosers";
                    SetPositions(positions_OnePlayers, 62, WinnersPositions);
                    SetPositions(positions_TwoPlayers, -62, LooserPositions);
                }
                
            }
            else if (noOfPlayers - winner == 3) {
                WinnerText.text = "Winner";
                LooserText.text = "Loosers";
                SetPositions(positions_OnePlayers, 62, WinnersPositions);
                SetPositions(positions_ThreePlayers, -62, LooserPositions);
            }
        }
        StartCoroutine(SetStates(noOfPlayers, winners));
    }

	IEnumerator SetStates(short players, ArrayList winners) {
        int size = 100;
        yield return new WaitForSeconds(0);
        int temp = 0;
        int tempTwo = 0;
        for (int i = 0; i < players; i++) {
            GameObject g = sprites[i];
            if ((bool)winners[i]) {
                //gets the players sprite
                GameObject tempsprite = (GameObject)Instantiate(sprites[i],WinnerLooserPage);
                tempsprite.transform.position = WinnersPositions[tempTwo].position;
                tempsprite.transform.localScale = new Vector3(size, size, size);
                tempTwo++;
            }
            else {
                //gets the players sprite
                GameObject tempsprite = (GameObject)Instantiate(sprites[i], WinnerLooserPage);
                tempsprite.GetComponent<Animator>().SetBool("IsAngery", true);
                tempsprite.transform.position = LooserPositions[temp].position;
                tempsprite.transform.localScale = new Vector3(size, size, size);
                temp++;
            }
        }
    }

    public void OnClickRestart() {
        GH.RestartGame();
    }

    public void OnExitTheGame() {
        LoadingScreenManager.LoadScene(1);
    }
}
