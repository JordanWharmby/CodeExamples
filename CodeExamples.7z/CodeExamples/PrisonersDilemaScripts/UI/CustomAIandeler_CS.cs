﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CustomAIandeler_CS : MonoBehaviour {

    private int[] stats = new int[4];

    private int player;

    public GameObject CustomizePage;

    public Toggle RandomToggle;
    public Toggle FermToggle;
    public Toggle ResetToggle;

    public Text AltruisumText;
    public Text ForgivnesText;
    public Text NerveText;
    public Text MemeoryText;

    private bool useCustom;
    private bool random;
    private bool ferm;
    private bool reset;

    private ArtificialInteligencePersonalityHandeler_CS AIPH;
    private MainMenuHandeler_CS MMH;

    // Use this for initialization
    void Start() {
        AIPH = FindObjectOfType<ArtificialInteligencePersonalityHandeler_CS>();
        MMH = FindObjectOfType<MainMenuHandeler_CS>();
    }

    public void SetStats(int i) {
        player = i;
        ArtificialInteligencePersonalityHandeler_CS TO = FindObjectOfType<ArtificialInteligencePersonalityHandeler_CS>();

        stats = TO.GetStats(i);
        useCustom = TO.GetIsCustom(i);
        random = TO.GetAIISRandom(i);
        ferm = TO.GetAIISFerm(i);
        reset = TO.GetAIISFerm(i);

        AltruisumText.text = stats[0].ToString();
        ForgivnesText.text = stats[1].ToString();
        NerveText.text = stats[2].ToString();
        MemeoryText.text = stats[3].ToString();

        RandomToggle.isOn = random;
        ShowPages();
        FermToggle.isOn = ferm;
        ResetToggle.isOn = reset;
    }

    public void ShowPages() {
        random = RandomToggle.isOn;
        CustomizePage.SetActive(!random);
    }

    public void IsFerm() {
        ferm = FermToggle.isOn;
        if (ferm) {
            ResetToggle.enabled = false;
        }
        else {
            ResetToggle.enabled = true;
        }
    }

    public void ResetAfterRound() {
        reset = ResetToggle.isOn;
    }

    public void SetAltruisum(int i) {
        stats[0] += i;
        stats[0] = Mathf.Clamp(stats[0], 0, 10);
        AltruisumText.text = stats[0].ToString();
    }

    public void SetForgivnes(int i) {
        stats[1] += i;
        stats[1] = Mathf.Clamp(stats[1], 0, 10);
        ForgivnesText.text = stats[1].ToString();
    }

    public void SetNerve(int i) {
        stats[2] += i;
        stats[2] = Mathf.Clamp(stats[2], 0, 10);
        NerveText.text = stats[2].ToString();
    }

    public void SetMemeory(int i) {
        stats[3] += i;
        stats[3] = Mathf.Clamp(stats[3], 0, 10);
        MemeoryText.text = stats[3].ToString();
    }

    public void BackToPages() {
        MMH.PlayAudio(1);
        MMH.SetPagesVisible(true);
    }

    public void SetNewStats() {
        AIPH.SetPlayerStats(player, stats[0], stats[1], stats[2], stats[3], random, ferm, reset, true);
        MMH.PlayAudio(1);
        MMH.SetPagesVisible(true);
    }

}
