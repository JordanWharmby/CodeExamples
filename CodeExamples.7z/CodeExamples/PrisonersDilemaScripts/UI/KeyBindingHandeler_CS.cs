﻿using UnityEngine;
using System.Collections;

public class KeyBindingHandeler_CS : MonoBehaviour {

    public GameObject[] Keys;

    private ApplicationManager AM;

	// Use this for initialization
	void Start () {
        AM = FindObjectOfType<ApplicationManager>();
        if(AM.GetCards() == 2) {
            Keys[2].SetActive(false);
            Keys[0].transform.localPosition = new Vector3(-1.48f, 0, 0);
            Keys[1].transform.localPosition = new Vector3(0.59f, 0, 0);
        }
	}
	
    public void SetKeyPos(int i, Vector3 vt) {
        Keys[i].transform.localPosition = vt;
    }

}
